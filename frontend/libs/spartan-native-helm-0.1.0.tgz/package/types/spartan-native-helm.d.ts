import * as i0 from "@angular/core";
/**
 * The desktop selection model, as pure functions.
 *
 * It follows how Explorer, Finder and Nautilus behave:
 *  - click selects one item and sets the anchor
 *  - Ctrl-click (⌘-click on macOS) toggles one item and moves the anchor
 *  - Shift-click selects the range from the anchor; with Ctrl/⌘ it adds the range
 *  - arrows / Home / End move the active item and select it; with Shift they extend
 *    the range from the anchor; with Ctrl they move the focus without selecting
 *  - Ctrl/⌘+A selects all, Esc clears
 *
 * No Angular and no DOM here: the directives in selectable.ts feed events in.
 */
export interface SelectionState<K> {
  /** Selected keys, always in item order. */
  readonly selected: readonly K[];
  /** Where a Shift range starts. */
  readonly anchor: K | null;
  /** The keyboard cursor (focused row). */
  readonly active: K | null;
}
export interface SelectionModifiers {
  /** Shift is held. */
  readonly range?: boolean;
  /** Ctrl (Windows, Linux) or ⌘ (macOS) is held. */
  readonly toggle?: boolean;
}
export declare const EMPTY_SELECTION: SelectionState<never>;
/** The state after a pointer click on `key`. */
export declare function selectionClick<K>(state: SelectionState<K>, keys: readonly K[], key: K, mods?: SelectionModifiers, multiple?: boolean): SelectionState<K>;
/** The state after the keyboard moves the active item to `index` (clamped). */
export declare function selectionMoveTo<K>(state: SelectionState<K>, keys: readonly K[], index: number, mods?: SelectionModifiers, multiple?: boolean): SelectionState<K>;
/** Move the active item by `delta` rows. With nothing active, Down starts at the top and Up at the bottom. */
export declare function selectionMoveBy<K>(state: SelectionState<K>, keys: readonly K[], delta: number, mods?: SelectionModifiers, multiple?: boolean): SelectionState<K>;
/** Space: select the active item, or toggle it with Ctrl/⌘. */
export declare function selectionToggleActive<K>(state: SelectionState<K>, keys: readonly K[], mods?: SelectionModifiers, multiple?: boolean): SelectionState<K>;
export declare function selectionAll<K>(state: SelectionState<K>, keys: readonly K[], multiple?: boolean): SelectionState<K>;
export declare function selectionClear<K>(state: SelectionState<K>): SelectionState<K>;
/** Drop keys that no longer exist (items removed), keeping order. */
export declare function selectionSync<K>(state: SelectionState<K>, keys: readonly K[]): SelectionState<K>;
/**
 * Type-ahead: the index of the next item whose label starts with `query`.
 * A repeated single letter cycles through matches, like Explorer and Finder.
 */
export declare function typeaheadIndex(labels: readonly string[], query: string, fromIndex: number): number;
/** listbox: a list of options · grid: table rows */
export type SelectableRole = 'listbox' | 'grid';
interface SelectableParent<K> {
  readonly role: () => SelectableRole;
  isSelected(key: K): boolean;
  isActive(key: K): boolean;
  click(key: K, event: MouseEvent): void;
  activate(key: K): void;
}
/**
 * One selectable row: an option in a list, or a `<tr>` in a table.
 *
 * ```html
 * <div snSelectableItem [value]="file.id">{{ file.name }}</div>
 * ```
 */
export declare class SnSelectableItem<K = unknown> {
  protected readonly parent: SelectableParent<K>;
  readonly element: HTMLElement;
  /**
   * The key this row stands for (required in practice). Declared optional because the
   * list reads its rows while Angular is still binding them.
   */
  readonly value: import("@angular/core").InputSignal<K>;
  /** Text used for type-ahead; defaults to the row's text. */
  readonly label: import("@angular/core").InputSignal<string | undefined>;
  readonly id: string;
  readonly selected: import("@angular/core").Signal<boolean>;
  readonly active: import("@angular/core").Signal<boolean>;
  typeaheadLabel(): string;
  protected onMouseDown(event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnSelectableItem<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnSelectableItem<any>, "[snSelectableItem]", ["snSelectableItem"], {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "snSelectableLabel";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A list or table with the desktop selection model.
 *
 * ```html
 * <div snSelectable [(selection)]="selected" (activated)="open($event)">
 *   @for (f of files; track f.id) {
 *     <div snSelectableItem [value]="f.id">{{ f.name }}</div>
 *   }
 * </div>
 *
 * <table hlmTable snSelectable="grid" [(selection)]="selected">…<tr hlmTr snSelectableItem [value]="row.id">…</table>
 * ```
 *
 * Mouse: click, Ctrl/⌘-click, Shift-click, double-click to activate.
 * Keyboard: ↑ ↓ Home End PageUp PageDown (Shift extends, Ctrl moves focus only),
 * Space (Ctrl+Space toggles), Ctrl/⌘+A, Esc clears, Enter activates, type-ahead.
 * On macOS ⌘ replaces Ctrl, and ⌘↑ / ⌘↓ jump to the first / last row.
 */
export declare class SnSelectable<K = unknown> implements SelectableParent<K> {
  private readonly doc;
  private readonly skin;
  /** `snSelectable` or `snSelectable="listbox"` for lists, `snSelectable="grid"` for tables. */
  readonly role: import("@angular/core").InputSignalWithTransform<SelectableRole, "" | SelectableRole>;
  /** Allow more than one selected row. */
  readonly multiple: import("@angular/core").InputSignal<boolean>;
  /** The selected keys, in row order. Two-way bindable. */
  readonly selection: import("@angular/core").ModelSignal<readonly K[]>;
  /** Enter or double-click on a row. */
  readonly activated: import("@angular/core").OutputEmitterRef<K>;
  private readonly items;
  private readonly keys;
  private readonly cursor;
  private readonly selectedSet;
  protected readonly activeId: import("@angular/core").Signal<string | null>;
  private typeahead;
  private typeaheadTimer;
  constructor();
  isSelected(key: K): boolean;
  isActive(key: K): boolean;
  click(key: K, event: MouseEvent): void;
  activate(key: K): void;
  protected onFocus(): void;
  protected onKeydown(event: KeyboardEvent): void;
  private onTypeahead;
  private state;
  private apply;
  /** ⌘ toggles on macOS, Ctrl everywhere else (Ctrl-click is the context menu on macOS). */
  private modifiers;
  private isMac;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnSelectable<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnSelectable<any>, "[snSelectable]", ["snSelectable"], {
    "role": {
      "alias": "snSelectable";
      "required": false;
      "isSignal": true;
    };
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "selection": {
      "alias": "selection";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selection": "selectionChange";
    "activated": "activated";
  }, ["items"], never, true, never>;
}
export declare const SnSelectableImports: readonly [typeof SnSelectable, typeof SnSelectableItem];
/**
 * Marks a custom area for snDefaultAction / snCancelAction (dialogs and forms are scopes already).
 *
 * ```html
 * <section snActionScope>…</section>
 * ```
 */
export declare class SnActionScope {
  static ɵfac: i0.ɵɵFactoryDeclaration<SnActionScope, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnActionScope, "[snActionScope]", never, {}, {}, never, never, true, never>;
}
/**
 * The default button: Enter anywhere in its dialog or form presses it,
 * the way every desktop OS behaves. Fields that use Enter themselves
 * (multi-line text, other buttons, lists) keep it.
 *
 * ```html
 * <button hlmBtn snDefaultAction (click)="save()">Save</button>
 * ```
 */
export declare class SnDefaultAction {
  private readonly button;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<SnDefaultAction, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnDefaultAction, "button[snDefaultAction]", never, {}, {}, never, never, true, never>;
}
/**
 * The cancel button: Esc anywhere in its dialog or form presses it.
 *
 * ```html
 * <button hlmBtn variant="outline" snCancelAction (click)="close()">Cancel</button>
 * ```
 */
export declare class SnCancelAction {
  private readonly button;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<SnCancelAction, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnCancelAction, "button[snCancelAction]", never, {}, {}, never, never, true, never>;
}
/**
 * A row of dialog buttons, put in the order of the current OS (docs/05, Q5): the
 * snDefaultAction, the snCancelAction and every other button. Write them in any order;
 * the skin decides where each goes. spartan's hlm-dialog-footer and hlm-alert-dialog-footer
 * get the same treatment without this directive. It sets an attribute, not `data-slot`, so it
 * can sit on another component's host (`<div hlmCardFooter snDialogButtons>`).
 *
 * | Skin | Order |
 * | --- | --- |
 * | Windows, KDE | default · other · cancel |
 * | macOS | other ‹gap› cancel · default |
 * | GNOME | cancel · other · default |
 * | ChromeOS, web | other · cancel · default |
 *
 * ```html
 * <div snDialogButtons>
 *   <button hlmBtn snDefaultAction>Save</button>
 *   <button hlmBtn variant="outline">Don't save</button>
 *   <button hlmBtn variant="outline" snCancelAction>Cancel</button>
 * </div>
 * ```
 */
export declare class SnDialogButtons {
  static ɵfac: i0.ɵɵFactoryDeclaration<SnDialogButtons, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnDialogButtons, "[snDialogButtons]", never, {}, {}, never, never, true, never>;
}
export declare const SnDialogActionsImports: readonly [typeof SnActionScope, typeof SnDefaultAction, typeof SnCancelAction, typeof SnDialogButtons];
export {};