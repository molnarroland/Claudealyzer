import { DOCUMENT } from "@angular/common";
import * as i0 from "@angular/core";
import { DestroyRef, Directive, ElementRef, InjectionToken, afterNextRender, computed, contentChildren, effect, forwardRef, inject, input, model, output, signal, untracked } from "@angular/core";
import { injectSkin } from "@spartan-native/theme";
const EMPTY_SELECTION = {
	selected: [],
	anchor: null,
	active: null
};
function ordered(keys, selected) {
	const set = new Set(selected);
	return keys.filter((k) => set.has(k));
}
function range(keys, from, to) {
	const a = from === null ? -1 : keys.indexOf(from);
	const b = keys.indexOf(to);
	if (a < 0) return [to];
	return keys.slice(Math.min(a, b), Math.max(a, b) + 1);
}
function selectionClick(state, keys, key, mods = {}, multiple = true) {
	if (!keys.includes(key)) return state;
	if (!multiple) return {
		selected: [key],
		anchor: key,
		active: key
	};
	if (mods.range) {
		const span = range(keys, state.anchor, key);
		return {
			selected: mods.toggle ? ordered(keys, [...state.selected, ...span]) : span,
			anchor: state.anchor ?? key,
			active: key
		};
	}
	if (mods.toggle) return {
		selected: state.selected.includes(key) ? state.selected.filter((k) => k !== key) : ordered(keys, [...state.selected, key]),
		anchor: key,
		active: key
	};
	return {
		selected: [key],
		anchor: key,
		active: key
	};
}
function selectionMoveTo(state, keys, index, mods = {}, multiple = true) {
	if (keys.length === 0) return state;
	const target = keys[Math.max(0, Math.min(keys.length - 1, index))];
	if (!multiple) return {
		selected: [target],
		anchor: target,
		active: target
	};
	if (mods.range) {
		const span = range(keys, state.anchor ?? state.active, target);
		return {
			selected: mods.toggle ? ordered(keys, [...state.selected, ...span]) : span,
			anchor: state.anchor ?? state.active ?? target,
			active: target
		};
	}
	if (mods.toggle) return {
		...state,
		active: target
	};
	return {
		selected: [target],
		anchor: target,
		active: target
	};
}
function selectionMoveBy(state, keys, delta, mods = {}, multiple = true) {
	const current = state.active === null ? -1 : keys.indexOf(state.active);
	return selectionMoveTo(state, keys, (current < 0 ? delta > 0 ? -1 : keys.length : current) + delta, mods, multiple);
}
function selectionToggleActive(state, keys, mods = {}, multiple = true) {
	if (state.active === null) return state;
	return selectionClick(state, keys, state.active, { toggle: mods.toggle }, multiple);
}
function selectionAll(state, keys, multiple = true) {
	if (!multiple) return state;
	return {
		selected: [...keys],
		anchor: keys[0] ?? null,
		active: state.active ?? keys[0] ?? null
	};
}
function selectionClear(state) {
	return {
		...state,
		selected: []
	};
}
function selectionSync(state, keys) {
	const has = (k) => k !== null && keys.includes(k);
	return {
		selected: ordered(keys, state.selected),
		anchor: has(state.anchor) ? state.anchor : null,
		active: has(state.active) ? state.active : null
	};
}
function typeaheadIndex(labels, query, fromIndex) {
	if (!query || labels.length === 0) return -1;
	const q = query.toLocaleLowerCase();
	const cycling = [...q].every((c) => c === q[0]);
	const needle = cycling ? q[0] : q;
	const start = cycling ? fromIndex + 1 : Math.max(0, fromIndex);
	for (let i = 0; i < labels.length; i++) {
		const idx = (start + i) % labels.length;
		if (labels[idx].toLocaleLowerCase().startsWith(needle)) return idx;
	}
	return -1;
}
const PAGE = 10;
const TYPEAHEAD_RESET_MS = 600;
let nextId = 0;
const SN_SELECTABLE = new InjectionToken("SN_SELECTABLE");
var SnSelectableItem = class SnSelectableItem {
	parent = inject(SN_SELECTABLE);
	element = inject(ElementRef).nativeElement;
	value = input(void 0, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	label = input(void 0, {
		...ngDevMode ? { debugName: "label" } : /* istanbul ignore next */ {},
		alias: "snSelectableLabel"
	});
	id = `sn-selectable-item-${nextId++}`;
	selected = computed(() => this.parent.isSelected(this.value()), ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	active = computed(() => this.parent.isActive(this.value()), ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	typeaheadLabel() {
		return (this.label() ?? this.element.textContent ?? "").trim();
	}
	onMouseDown(event) {
		if (event.shiftKey) event.preventDefault();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnSelectableItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnSelectableItem,
		isStandalone: true,
		selector: "[snSelectableItem]",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "snSelectableLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "sn-selectable-item" },
			listeners: {
				"mousedown": "onMouseDown($event)",
				"click": "parent.click(value(), $event)",
				"dblclick": "parent.activate(value())"
			},
			properties: {
				"id": "id",
				"attr.role": "parent.role() === 'grid' ? 'row' : 'option'",
				"attr.aria-selected": "selected()",
				"attr.data-selected": "selected() ? '' : null",
				"attr.data-active": "active() ? '' : null"
			}
		},
		exportAs: ["snSelectableItem"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnSelectableItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[snSelectableItem]",
			exportAs: "snSelectableItem",
			host: {
				"data-slot": "sn-selectable-item",
				"[id]": "id",
				"[attr.role]": "parent.role() === 'grid' ? 'row' : 'option'",
				"[attr.aria-selected]": "selected()",
				"[attr.data-selected]": "selected() ? '' : null",
				"[attr.data-active]": "active() ? '' : null",
				"(mousedown)": "onMouseDown($event)",
				"(click)": "parent.click(value(), $event)",
				"(dblclick)": "parent.activate(value())"
			}
		}]
	}],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "snSelectableLabel",
				required: false
			}]
		}]
	}
});
var SnSelectable = class SnSelectable {
	doc = inject(DOCUMENT);
	skin = injectSkin();
	role = input("listbox", {
		...ngDevMode ? { debugName: "role" } : /* istanbul ignore next */ {},
		alias: "snSelectable",
		transform: (v) => v === "grid" ? "grid" : "listbox"
	});
	multiple = input(true, ...ngDevMode ? [{ debugName: "multiple" }] : /* istanbul ignore next */ []);
	selection = model([], ...ngDevMode ? [{ debugName: "selection" }] : /* istanbul ignore next */ []);
	activated = output();
	items = contentChildren(SnSelectableItem, {
		...ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {},
		descendants: true
	});
	keys = computed(() => this.items().map((i) => i.value()), ...ngDevMode ? [{ debugName: "keys" }] : /* istanbul ignore next */ []);
	cursor = signal({
		anchor: null,
		active: null
	}, ...ngDevMode ? [{ debugName: "cursor" }] : /* istanbul ignore next */ []);
	selectedSet = computed(() => new Set(this.selection()), ...ngDevMode ? [{ debugName: "selectedSet" }] : /* istanbul ignore next */ []);
	activeId = computed(() => {
		const active = this.cursor().active;
		return this.items().find((i) => i.value() === active)?.id ?? null;
	}, ...ngDevMode ? [{ debugName: "activeId" }] : /* istanbul ignore next */ []);
	typeahead = "";
	typeaheadTimer;
	constructor() {
		effect(() => {
			const keys = this.keys();
			if (keys.some((k) => k == null)) return;
			untracked(() => {
				const synced = selectionSync(this.state(), keys);
				if (synced.selected.length !== this.selection().length) this.selection.set(synced.selected);
				this.cursor.set({
					anchor: synced.anchor,
					active: synced.active
				});
			});
		});
		effect(() => {
			const id = this.activeId();
			if (id) untracked(() => this.doc.getElementById(id)?.scrollIntoView?.({ block: "nearest" }));
		});
	}
	isSelected(key) {
		return this.selectedSet().has(key);
	}
	isActive(key) {
		return this.cursor().active === key;
	}
	click(key, event) {
		this.apply(selectionClick(this.state(), this.keys(), key, this.modifiers(event), this.multiple()));
	}
	activate(key) {
		this.activated.emit(key);
	}
	onFocus() {
		if (this.cursor().active === null) {
			const first = this.selection()[0] ?? this.keys()[0] ?? null;
			this.cursor.update((c) => ({
				...c,
				active: first
			}));
		}
	}
	onKeydown(event) {
		if (isEditable(event.target, event.currentTarget)) return;
		const keys = this.keys();
		const mods = this.modifiers(event);
		const multiple = this.multiple();
		const state = this.state();
		const mac = this.isMac();
		let next = null;
		switch (event.key) {
			case "ArrowDown":
				next = mac && event.metaKey ? selectionMoveTo(state, keys, keys.length - 1, { range: mods.range }, multiple) : selectionMoveBy(state, keys, 1, mods, multiple);
				break;
			case "ArrowUp":
				next = mac && event.metaKey ? selectionMoveTo(state, keys, 0, { range: mods.range }, multiple) : selectionMoveBy(state, keys, -1, mods, multiple);
				break;
			case "Home":
				next = selectionMoveTo(state, keys, 0, mods, multiple);
				break;
			case "End":
				next = selectionMoveTo(state, keys, keys.length - 1, mods, multiple);
				break;
			case "PageDown":
				next = selectionMoveBy(state, keys, PAGE, mods, multiple);
				break;
			case "PageUp":
				next = selectionMoveBy(state, keys, -10, mods, multiple);
				break;
			case " ":
				if (this.typeahead) return this.onTypeahead(event);
				next = selectionToggleActive(state, keys, mods, multiple);
				break;
			case "Enter":
				if (state.active !== null) {
					event.preventDefault();
					this.activated.emit(state.active);
				}
				return;
			case "Escape":
				if (state.selected.length === 0) return;
				next = selectionClear(state);
				break;
			default:
				if (mods.toggle && event.key.toLowerCase() === "a") {
					next = selectionAll(state, keys, multiple);
					break;
				}
				return this.onTypeahead(event);
		}
		event.preventDefault();
		this.apply(next);
	}
	onTypeahead(event) {
		if (event.key.length !== 1 || event.ctrlKey || event.metaKey || event.altKey) return;
		event.preventDefault();
		clearTimeout(this.typeaheadTimer);
		this.typeahead += event.key;
		this.typeaheadTimer = setTimeout(() => this.typeahead = "", TYPEAHEAD_RESET_MS);
		const items = this.items();
		const current = items.findIndex((i) => i.value() === this.cursor().active);
		const index = typeaheadIndex(items.map((i) => i.typeaheadLabel()), this.typeahead, current);
		if (index >= 0) this.apply(selectionMoveTo(this.state(), this.keys(), index, {}, this.multiple()));
	}
	state() {
		return {
			selected: this.selection(),
			...this.cursor()
		};
	}
	apply(next) {
		this.cursor.set({
			anchor: next.anchor,
			active: next.active
		});
		const prev = this.selection();
		if (prev.length !== next.selected.length || prev.some((k, i) => k !== next.selected[i])) this.selection.set(next.selected);
	}
	modifiers(event) {
		return {
			range: event.shiftKey,
			toggle: this.isMac() ? event.metaKey : event.ctrlKey
		};
	}
	isMac() {
		const skin = this.skin();
		return skin === "mac" || skin === "macc";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnSelectable,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.2.0",
		version: "22.2.5",
		type: SnSelectable,
		isStandalone: true,
		selector: "[snSelectable]",
		inputs: {
			role: {
				classPropertyName: "role",
				publicName: "snSelectable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selection: {
				classPropertyName: "selection",
				publicName: "selection",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selection: "selectionChange",
			activated: "activated"
		},
		host: {
			attributes: {
				"data-slot": "sn-selectable",
				"tabindex": "0"
			},
			listeners: {
				"keydown": "onKeydown($event)",
				"focus": "onFocus()"
			},
			properties: {
				"attr.role": "role()",
				"attr.aria-multiselectable": "multiple()",
				"attr.aria-activedescendant": "activeId()"
			}
		},
		providers: [{
			provide: SN_SELECTABLE,
			useExisting: forwardRef(() => SnSelectable)
		}],
		queries: [{
			propertyName: "items",
			predicate: SnSelectableItem,
			descendants: true,
			isSignal: true
		}],
		exportAs: ["snSelectable"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnSelectable,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[snSelectable]",
			exportAs: "snSelectable",
			providers: [{
				provide: SN_SELECTABLE,
				useExisting: forwardRef(() => SnSelectable)
			}],
			host: {
				"data-slot": "sn-selectable",
				tabindex: "0",
				"[attr.role]": "role()",
				"[attr.aria-multiselectable]": "multiple()",
				"[attr.aria-activedescendant]": "activeId()",
				"(keydown)": "onKeydown($event)",
				"(focus)": "onFocus()"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		role: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "snSelectable",
				required: false
			}]
		}],
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		selection: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selection",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectionChange"]
		}],
		activated: [{
			type: i0.Output,
			args: ["activated"]
		}],
		items: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => SnSelectableItem), {
				descendants: true,
				isSignal: true
			}]
		}]
	}
});
function isEditable(target, host) {
	if (!(target instanceof HTMLElement) || target === host) return false;
	return target.isContentEditable || target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement;
}
const SnSelectableImports = [SnSelectable, SnSelectableItem];
const SCOPE = "[snActionScope], [role=\"dialog\"], [role=\"alertdialog\"], form";
const OWNS_ENTER = "textarea, button, a[href], select, [contenteditable=\"\"], [contenteditable=\"true\"], [role=\"listbox\"], [role=\"grid\"], [role=\"menu\"], [role=\"tree\"]";
var SnActionScope = class SnActionScope {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnActionScope,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: SnActionScope,
		isStandalone: true,
		selector: "[snActionScope]",
		host: { attributes: { "data-slot": "sn-action-scope" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnActionScope,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[snActionScope]",
			host: { "data-slot": "sn-action-scope" }
		}]
	}]
});
function listenInScope(key, onKey) {
	const element = inject(ElementRef).nativeElement;
	const destroyRef = inject(DestroyRef);
	afterNextRender(() => {
		const scope = element.closest(SCOPE) ?? element.ownerDocument;
		const listener = (event) => {
			const e = event;
			if (e.key !== key || e.defaultPrevented || e.isComposing) return;
			onKey(e);
		};
		scope.addEventListener("keydown", listener);
		destroyRef.onDestroy(() => scope.removeEventListener("keydown", listener));
	});
}
var SnDefaultAction = class SnDefaultAction {
	button = inject(ElementRef).nativeElement;
	constructor() {
		listenInScope("Enter", (event) => {
			const target = event.target;
			if (this.button.disabled || target?.closest(OWNS_ENTER)) return;
			event.preventDefault();
			this.button.click();
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnDefaultAction,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: SnDefaultAction,
		isStandalone: true,
		selector: "button[snDefaultAction]",
		host: { attributes: { "data-sn-default-action": "" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnDefaultAction,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[snDefaultAction]",
			host: { "data-sn-default-action": "" }
		}]
	}],
	ctorParameters: () => []
});
var SnCancelAction = class SnCancelAction {
	button = inject(ElementRef).nativeElement;
	constructor() {
		listenInScope("Escape", (event) => {
			if (this.button.disabled) return;
			event.preventDefault();
			this.button.click();
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnCancelAction,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: SnCancelAction,
		isStandalone: true,
		selector: "button[snCancelAction]",
		host: { attributes: { "data-sn-cancel-action": "" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnCancelAction,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[snCancelAction]",
			host: { "data-sn-cancel-action": "" }
		}]
	}],
	ctorParameters: () => []
});
var SnDialogButtons = class SnDialogButtons {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnDialogButtons,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: SnDialogButtons,
		isStandalone: true,
		selector: "[snDialogButtons]",
		host: { attributes: { "data-sn-dialog-buttons": "" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnDialogButtons,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[snDialogButtons]",
			host: { "data-sn-dialog-buttons": "" }
		}]
	}]
});
const SnDialogActionsImports = [
	SnActionScope,
	SnDefaultAction,
	SnCancelAction,
	SnDialogButtons
];
export { EMPTY_SELECTION, SnActionScope, SnCancelAction, SnDefaultAction, SnDialogActionsImports, SnDialogButtons, SnSelectable, SnSelectableImports, SnSelectableItem, selectionAll, selectionClear, selectionClick, selectionMoveBy, selectionMoveTo, selectionSync, selectionToggleActive, typeaheadIndex };

//# sourceMappingURL=spartan-native-helm.mjs.map