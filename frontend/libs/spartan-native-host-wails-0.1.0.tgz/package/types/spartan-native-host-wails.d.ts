import { NativeHost } from "@spartan-native/theme";
/** The Go service's bound-method prefix: `<Go package path>.<type>`. */
export declare const DEFAULT_SERVICE = "github.com/spartan-native/host-wails.Service";
/** The event the Go service emits on every appearance change. */
export declare const APPEARANCE_EVENT = "spartan-native:appearance";
/** The event the Go service emits with an item's id when a native menu item is chosen. */
export declare const MENU_ACTION_EVENT = "spartan-native:menu-action";
/** The parts of @wailsio/runtime this adapter uses. Inject a fake in tests. */
export interface WailsRuntimeLike {
  Call: {
    ByName(methodName: string, ...args: unknown[]): Promise<unknown>;
  };
  Events: {
    On(eventName: string, callback: (event: {
      data: unknown;
    }) => void): () => void;
  };
  Window: {
    Minimise(): Promise<void>;
    ToggleMaximise(): Promise<void>;
    Close(): Promise<void>;
    IsMaximised(): Promise<boolean>;
  };
}
export interface WailsHostOptions {
  /** The Go service's bound name, if you wrapped or renamed it. Default: DEFAULT_SERVICE. */
  service?: string;
  /** Use this runtime instead of importing @wailsio/runtime (tests, custom builds). */
  runtime?: WailsRuntimeLike;
}
/**
 * True when the page runs inside a Wails webview: `wails://` on macOS and Linux,
 * `wails.localhost` on Windows (also in `wails3 dev`).
 */
export declare function isWails(location?: Pick<Location, 'protocol' | 'hostname'> | undefined): boolean;
/**
 * NativeHost for Go + Wails v3. Reads the real OS settings through the Go service
 * (github.com/spartan-native/host-wails), live, and owns the window:
 * desktop-ui's window controls minimize, maximize and close it. Native menus too:
 * desktop-ui's menubar becomes the macOS global menu bar, and its context menus are
 * the OS's own. File dialogs and alerts are the OS's too (`host.dialogs`).
 *
 * ```go
 * // main.go
 * Services: []application.Service{application.NewService(spartannative.New())}
 * ```
 * ```ts
 * // app.config.ts
 * provideSpartanNative({ host: wailsHost() })
 * ```
 */
export declare function wailsHost(options?: WailsHostOptions): NativeHost;