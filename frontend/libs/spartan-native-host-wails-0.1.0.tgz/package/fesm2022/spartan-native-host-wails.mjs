import { CAPABILITIES } from "@spartan-native/theme";
const DEFAULT_SERVICE = "github.com/spartan-native/host-wails.Service";
const APPEARANCE_EVENT = "spartan-native:appearance";
const MENU_ACTION_EVENT = "spartan-native:menu-action";
function isWails(location = globalThis.location) {
	return !!location && (location.protocol === "wails:" || location.hostname === "wails.localhost");
}
const INITIAL = {
	systemAccent: "native",
	colorScheme: "native",
	highContrast: "native",
	reduceTransparency: "native",
	textScale: "native",
	windowFocus: "native",
	windowMaterial: "native",
	customTitleBar: "native",
	nativeMenus: "partial",
	notifications: "partial",
	fileDialogs: "native",
	osVersion: "native"
};
function wailsHost(options = {}) {
	const service = options.service ?? "github.com/spartan-native/host-wails.Service";
	let loaded = options.runtime ?? null;
	const runtimePromise = loaded ? Promise.resolve(loaded) : import("@wailsio/runtime").then((rt) => loaded = rt);
	const runtime = () => runtimePromise;
	const call = async (method, ...args) => (await runtime()).Call.ByName(`${service}.${method}`, ...args);
	const capabilities = Object.fromEntries(CAPABILITIES.map((c) => [c, INITIAL[c] ?? "none"]));
	call("Capabilities").then((caps) => Object.assign(capabilities, caps)).catch(() => void 0);
	const on = (event, cb) => {
		let off = null;
		let cancelled = false;
		if (loaded) off = loaded.Events.On(event, (e) => cb(e.data));
		else runtime().then((rt) => {
			if (!cancelled) off = rt.Events.On(event, (e) => cb(e.data));
		}, () => void 0);
		return () => {
			cancelled = true;
			off?.();
			off = null;
		};
	};
	return {
		runtime: "wails",
		capabilities,
		platform: () => call("Platform"),
		appearance: () => call("Appearance"),
		onAppearanceChange: (cb) => on(APPEARANCE_EVENT, (data) => cb(data)),
		window: {
			isFocused: async () => typeof document === "undefined" ? true : document.hasFocus(),
			onFocusChange(cb) {
				const offs = [on("common:WindowFocus", () => cb(true)), on("common:WindowLostFocus", () => cb(false))];
				return () => offs.forEach((off) => off());
			},
			minimize: async () => (await runtime()).Window.Minimise(),
			toggleMaximize: async () => (await runtime()).Window.ToggleMaximise(),
			close: async () => (await runtime()).Window.Close(),
			isMaximized: async () => (await runtime()).Window.IsMaximised(),
			onMaximizedChange(cb) {
				const offs = [on("common:WindowMaximise", () => cb(true)), on("common:WindowUnMaximise", () => cb(false))];
				return () => offs.forEach((off) => off());
			}
		},
		menus: {
			setApplicationMenu: (menu) => call("SetApplicationMenu", menu),
			showContextMenu: (menu, { x, y }) => call("ShowContextMenu", menu, Math.round(x), Math.round(y)),
			onAction: (cb) => on(MENU_ACTION_EVENT, (id) => cb(String(id)))
		},
		dialogs: {
			openFile: async (options = {}) => await call("OpenFile", options) ?? [],
			saveFile: async (options = {}) => await call("SaveFile", options) ?? null,
			pickFolder: async (options = {}) => await call("PickFolder", options) ?? null,
			message: async (options) => await call("Message", options) ?? null
		}
	};
}
export { APPEARANCE_EVENT, DEFAULT_SERVICE, MENU_ACTION_EVENT, isWails, wailsHost };

//# sourceMappingURL=spartan-native-host-wails.mjs.map