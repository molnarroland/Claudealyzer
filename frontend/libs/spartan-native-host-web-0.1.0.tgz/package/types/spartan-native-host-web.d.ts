import { NativeHost, PlatformInfo, Skin } from "@spartan-native/theme";
export interface WebHostOptions {
  /** Accent used where the browser does not expose the system accent. Default: the platform's stock accent. */
  accent?: string;
  /** Force a skin instead of detecting it (e.g. a user setting). */
  skin?: Skin;
  /** The window to read from. Default: the global window. For tests and iframes. */
  window?: Window;
}
/**
 * NativeHost for browsers and installed PWAs. No native side.
 *
 * | Setting | Source | Live |
 * | --- | --- | --- |
 * | light / dark | `prefers-color-scheme` | yes |
 * | contrast | `prefers-contrast`, `forced-colors` | yes |
 * | reduce transparency | `prefers-reduced-transparency` (where supported) | yes |
 * | reduce motion | `prefers-reduced-motion` | yes |
 * | text size | the browser's default font size | yes (ResizeObserver) |
 * | accent | CSS `AccentColor` where the browser exposes the real one (Firefox, Safari), else `options.accent` / the platform's stock accent | on focus / visibility |
 * | window focus | `focus` / `blur` / `visibilitychange` | yes |
 * | OS and skin | User-Agent Client Hints, else the user-agent string | once |
 * | file dialogs | File System Access pickers (Chromium); absent elsewhere | – |
 *
 * ```ts
 * provideSpartanNative({ host: webHost() })
 * ```
 */
export declare function webHost(options?: WebHostOptions): NativeHost;
/** The subset of User-Agent Client Hints this adapter reads (Chromium). */
export interface UserAgentDataLike {
  readonly platform?: string;
  getHighEntropyValues?(hints: string[]): Promise<{
    platformVersion?: string;
  }>;
}
export interface NavigatorLike {
  readonly userAgent: string;
  readonly userAgentData?: UserAgentDataLike;
}
/**
 * The OS, its version and the matching skin, from the browser.
 *
 * - Chromium (User-Agent Client Hints): the real OS version. On Windows,
 *   platformVersion ≥ 13 means Windows 11; on macOS it is the real macOS version.
 *   confidence: 'exact'.
 * - Other browsers: the user-agent string, where Windows and macOS versions are
 *   frozen. Windows → Windows 11, macOS → macOS 26 (the current releases).
 *   confidence: 'hint'.
 * - The Linux desktop (GNOME / KDE) is never visible to a web page: GTK is assumed.
 */
export declare function detectPlatform(nav: NavigatorLike): Promise<PlatformInfo>;
export declare function fromClientHints(platform: string, version: string | null): PlatformInfo;
export declare function fromUserAgent(ua: string): PlatformInfo;
/**
 * How a web app is running:
 *  - 'browser'  in a browser tab
 *  - 'standalone' installed (PWA): the OS draws the whole title bar
 *  - 'overlay'  installed with Window Controls Overlay: the OS draws only the
 *               window buttons; the app draws its own title bar in the
 *               `env(titlebar-area-*)` rectangle
 */
export type DisplayMode = 'browser' | 'standalone' | 'overlay';
export declare function readDisplayMode(win: Window): DisplayMode;
/**
 * Calls `cb` now and whenever the display mode changes (installing, or the user
 * toggling the title bar in an installed app). Returns an unsubscribe function.
 */
export declare function watchDisplayMode(cb: (mode: DisplayMode) => void, win?: Window | undefined): () => void;