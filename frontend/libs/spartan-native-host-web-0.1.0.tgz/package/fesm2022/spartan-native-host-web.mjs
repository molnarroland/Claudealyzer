import { CAPABILITIES, normalizeHex, resolveSkin } from "@spartan-native/theme";
async function detectPlatform(nav) {
	const uaData = nav.userAgentData;
	if (uaData?.platform) {
		let version = null;
		try {
			version = (await uaData.getHighEntropyValues?.(["platformVersion"]))?.platformVersion ?? null;
		} catch {
			version = null;
		}
		return fromClientHints(uaData.platform, version);
	}
	return fromUserAgent(nav.userAgent);
}
function info(os, version, confidence, skin) {
	const base = {
		os,
		version,
		build: null,
		desktop: null
	};
	return {
		...base,
		skin: skin ?? resolveSkin(base),
		confidence
	};
}
function fromClientHints(platform, version) {
	const major = version ? parseInt(version, 10) : NaN;
	switch (platform.toLowerCase()) {
		case "windows": return info("windows", version, version ? "exact" : "hint", Number.isFinite(major) && major > 0 && major < 13 ? "w10" : "win");
		case "macos": return info("macos", version, version ? "exact" : "hint");
		case "chrome os":
		case "chromeos": return info("chromeos", version, "exact");
		case "linux": return info("linux", version, "hint");
		default: return info("unknown", version, "unknown");
	}
}
function fromUserAgent(ua) {
	if (/Android|iPhone|iPad|iPod/i.test(ua)) return info("unknown", null, "unknown");
	if (/Windows NT/i.test(ua)) return info("windows", null, "hint", "win");
	if (/Mac OS X|Macintosh/i.test(ua)) return info("macos", null, "hint", "mac");
	if (/CrOS/i.test(ua)) return info("chromeos", null, "hint");
	if (/Linux/i.test(ua)) return info("linux", null, "hint");
	return info("unknown", null, "unknown");
}
function supportsFilePickers(win) {
	return !!win && "showOpenFilePicker" in win && "showSaveFilePicker" in win && "showDirectoryPicker" in win;
}
function toPickerTypes(filters = []) {
	const matchesAll = filters.length === 0 || filters.some((f) => f.extensions.includes("*"));
	return {
		types: filters.filter((f) => !f.extensions.includes("*") && f.extensions.length > 0).map((f) => ({
			description: f.name,
			accept: { "application/octet-stream": f.extensions.map((e) => "." + e.replace(/^\./, "")) }
		})),
		excludeAcceptAllOption: !matchesAll
	};
}
const picked = (handle) => ({
	name: handle.name,
	handle
});
async function orCancelled(run, cancelled) {
	try {
		return await run();
	} catch (e) {
		if (e instanceof DOMException && e.name === "AbortError") return cancelled;
		throw e;
	}
}
function webDialogs(win) {
	const pickers = win;
	return {
		openFile: (options = {}) => orCancelled(async () => {
			return (await pickers.showOpenFilePicker({
				multiple: !!options.multiple,
				...toPickerTypes(options.filters)
			})).map(picked);
		}, []),
		saveFile: (options = {}) => orCancelled(async () => picked(await pickers.showSaveFilePicker({
			suggestedName: options.fileName,
			...toPickerTypes(options.filters)
		})), null),
		pickFolder: () => orCancelled(async () => picked(await pickers.showDirectoryPicker()), null)
	};
}
const STOCK_ACCENT = {
	win: "#0078d4",
	w10: "#0078d4",
	mac: "#007aff",
	macc: "#007aff",
	gtk: "#3584e4",
	qt: "#3daee9",
	cros: "#0b57d0",
	web: "#0078d4"
};
const CHROMIUM_FIXED_ACCENT = "#0075ff";
const QUERIES = {
	dark: "(prefers-color-scheme: dark)",
	moreContrast: "(prefers-contrast: more)",
	forcedColors: "(forced-colors: active)",
	reduceTransparency: "(prefers-reduced-transparency: reduce)",
	reduceMotion: "(prefers-reduced-motion: reduce)"
};
function webHost(options = {}) {
	const win = options.window ?? (typeof window !== "undefined" ? window : void 0);
	const doc = win?.document;
	const media = (q) => win?.matchMedia ? win.matchMedia(q) : null;
	const matches = (q) => media(q)?.matches ?? false;
	const supportsMedia = (q) => {
		const m = media(q);
		return !!m && m.media !== "not all";
	};
	const supportsAccentColor = !!(win?.CSS)?.supports?.("color", "AccentColor");
	let platformPromise = null;
	const platform = () => platformPromise ??= detectPlatform(win?.navigator ?? { userAgent: "" }).then((p) => options.skin ? {
		...p,
		skin: options.skin
	} : p);
	const probe = doc ? createProbe(doc) : null;
	const systemAccent = () => {
		if (!supportsAccentColor || !probe || !win) return null;
		const hex = rgbToHex(win.getComputedStyle(probe.accent).color);
		return hex && hex !== CHROMIUM_FIXED_ACCENT ? hex : null;
	};
	const exposesAccent = systemAccent() !== null;
	const readAccent = (skin) => systemAccent() ?? normalizeHex(options.accent ?? STOCK_ACCENT[skin] ?? STOCK_ACCENT["web"]);
	const readTextScale = () => {
		const px = probe?.text.getBoundingClientRect().width ?? 16;
		return px > 0 ? Math.round(px / 16 * 20) / 20 : 1;
	};
	const read = (skin) => ({
		skin,
		accent: readAccent(skin),
		scheme: matches(QUERIES.dark) ? "dark" : "light",
		contrast: matches(QUERIES.forcedColors) ? "forced" : matches(QUERIES.moreContrast) ? "more" : "normal",
		reduceTransparency: matches(QUERIES.reduceTransparency),
		reduceMotion: matches(QUERIES.reduceMotion),
		textScale: readTextScale()
	});
	let skin = options.skin ?? "web";
	let last = null;
	const appearance = async () => {
		skin = (await platform()).skin;
		return last = read(skin);
	};
	const appearanceListeners = /* @__PURE__ */ new Set();
	const notify = () => {
		if (appearanceListeners.size === 0) return;
		const next = read(skin);
		if (last && sameAppearance(last, next)) return;
		last = next;
		appearanceListeners.forEach((cb) => cb(next));
	};
	let detach = null;
	const attach = () => {
		const offs = [];
		for (const q of Object.values(QUERIES)) {
			const m = media(q);
			if (!m) continue;
			m.addEventListener?.("change", notify);
			offs.push(() => m.removeEventListener?.("change", notify));
		}
		if (probe && typeof ResizeObserver !== "undefined") {
			const ro = new ResizeObserver(notify);
			ro.observe(probe.text);
			offs.push(() => ro.disconnect());
		}
		win?.addEventListener("focus", notify);
		doc?.addEventListener("visibilitychange", notify);
		offs.push(() => win?.removeEventListener("focus", notify), () => doc?.removeEventListener("visibilitychange", notify));
		return () => offs.forEach((off) => off());
	};
	const focusListeners = /* @__PURE__ */ new Set();
	const isFocused = () => doc ? doc.hasFocus() && doc.visibilityState !== "hidden" : true;
	let focusDetach = null;
	const onFocusEvent = () => {
		const f = isFocused();
		focusListeners.forEach((cb) => cb(f));
	};
	const level = (ok, yes = "partial") => ok ? yes : "none";
	const nav = win?.navigator;
	const support = {
		systemAccent: level(exposesAccent),
		colorScheme: level(supportsMedia(QUERIES.dark), "native"),
		highContrast: level(supportsMedia(QUERIES.forcedColors) || supportsMedia(QUERIES.moreContrast), "native"),
		reduceTransparency: level(supportsMedia(QUERIES.reduceTransparency)),
		textScale: level(!!probe),
		windowFocus: level(!!doc, "native"),
		customTitleBar: level(!!nav && "windowControlsOverlay" in nav),
		notifications: level(!!win && "Notification" in win),
		taskbarProgress: level(!!nav && "setAppBadge" in nav),
		fileDialogs: level(supportsFilePickers(win)),
		osVersion: level(!!nav?.userAgentData)
	};
	return {
		runtime: "web",
		capabilities: Object.fromEntries(CAPABILITIES.map((c) => [c, support[c] ?? "none"])),
		platform,
		appearance,
		onAppearanceChange(cb) {
			appearanceListeners.add(cb);
			detach ??= attach();
			return () => {
				appearanceListeners.delete(cb);
				if (appearanceListeners.size === 0) {
					detach?.();
					detach = null;
				}
			};
		},
		window: {
			isFocused: async () => isFocused(),
			onFocusChange(cb) {
				focusListeners.add(cb);
				if (!focusDetach && win && doc) {
					win.addEventListener("focus", onFocusEvent);
					win.addEventListener("blur", onFocusEvent);
					doc.addEventListener("visibilitychange", onFocusEvent);
					focusDetach = () => {
						win.removeEventListener("focus", onFocusEvent);
						win.removeEventListener("blur", onFocusEvent);
						doc.removeEventListener("visibilitychange", onFocusEvent);
					};
				}
				return () => {
					focusListeners.delete(cb);
					if (focusListeners.size === 0) {
						focusDetach?.();
						focusDetach = null;
					}
				};
			}
		},
		...win && supportsFilePickers(win) ? { dialogs: webDialogs(win) } : {}
	};
}
function createProbe(doc) {
	const host = doc.createElement("div");
	host.setAttribute("aria-hidden", "true");
	host.dataset["snWebHostProbe"] = "";
	host.style.cssText = "position:absolute;width:0;height:0;overflow:hidden;visibility:hidden;pointer-events:none";
	const accent = doc.createElement("span");
	accent.style.cssText = "color:AccentColor";
	const text = doc.createElement("span");
	text.style.cssText = "display:block;font-size:medium;width:1em;height:1px";
	host.append(accent, text);
	(doc.body ?? doc.documentElement).append(host);
	return {
		accent,
		text
	};
}
function rgbToHex(color) {
	const m = color.match(/rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/i);
	if (!m) return null;
	return "#" + [
		m[1],
		m[2],
		m[3]
	].map((v) => Number(v).toString(16).padStart(2, "0")).join("");
}
function sameAppearance(a, b) {
	return a.accent === b.accent && a.scheme === b.scheme && a.contrast === b.contrast && a.reduceTransparency === b.reduceTransparency && a.reduceMotion === b.reduceMotion && a.textScale === b.textScale && a.skin === b.skin;
}
function readDisplayMode(win) {
	if (win.navigator.windowControlsOverlay?.visible) return "overlay";
	const media = (q) => win.matchMedia?.(q).matches ?? false;
	if (media("(display-mode: window-controls-overlay)")) return "overlay";
	if (media("(display-mode: standalone)") || media("(display-mode: minimal-ui)") || media("(display-mode: fullscreen)")) return "standalone";
	return "browser";
}
function watchDisplayMode(cb, win = globalThis.window) {
	if (!win) {
		cb("browser");
		return () => void 0;
	}
	let last = null;
	const update = () => {
		const mode = readDisplayMode(win);
		if (mode !== last) cb(last = mode);
	};
	const queries = [
		"(display-mode: standalone)",
		"(display-mode: window-controls-overlay)",
		"(display-mode: minimal-ui)"
	].map((q) => win.matchMedia?.(q)).filter((m) => !!m);
	const overlay = win.navigator.windowControlsOverlay;
	queries.forEach((m) => m.addEventListener?.("change", update));
	overlay?.addEventListener("geometrychange", update);
	update();
	return () => {
		queries.forEach((m) => m.removeEventListener?.("change", update));
		overlay?.removeEventListener("geometrychange", update);
	};
}
export { detectPlatform, fromClientHints, fromUserAgent, readDisplayMode, watchDisplayMode, webHost };

//# sourceMappingURL=spartan-native-host-web.mjs.map