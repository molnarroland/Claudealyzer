import { CAPABILITIES } from "@spartan-native/theme";
const RUNTIMES = [
	"web",
	"wails",
	"tauri",
	"electron",
	"dotnet",
	"static"
];
const SKINS = [
	"win",
	"w10",
	"mac",
	"macc",
	"gtk",
	"qt",
	"cros",
	"web"
];
const OSES = [
	"windows",
	"macos",
	"linux",
	"chromeos",
	"unknown"
];
const DESKTOPS = [
	"gnome",
	"kde",
	"cinnamon",
	"xfce",
	"other",
	null
];
const LEVELS = [
	"native",
	"partial",
	"none"
];
var CheckFailed = class extends Error {};
var SkipCheck = class extends Error {};
const expect = (ok, message) => {
	if (!ok) throw new CheckFailed(message);
};
const skip = (reason) => {
	throw new SkipCheck(reason);
};
function capture(subscribe, timeoutMs = 500) {
	const received = [];
	const unsubscribe = subscribe((v) => received.push(v));
	const next = (count = 1) => new Promise((resolve) => {
		const started = Date.now();
		const poll = () => received.length >= count || Date.now() - started > timeoutMs ? resolve(received) : setTimeout(poll, 5);
		poll();
	});
	return {
		received,
		unsubscribe,
		next
	};
}
function validatePlatform(p) {
	expect(OSES.includes(p.os), `platform().os is "${p.os}"; expected one of ${OSES.join(", ")}`);
	expect(SKINS.includes(p.skin), `platform().skin is "${p.skin}"; expected one of ${SKINS.join(", ")}`);
	expect([
		"exact",
		"hint",
		"unknown"
	].includes(p.confidence), `platform().confidence is "${p.confidence}"`);
	expect(p.version === null || typeof p.version === "string", "platform().version must be a string or null");
	expect(p.build === null || Number.isInteger(p.build), "platform().build must be an integer or null");
	expect(DESKTOPS.includes(p.desktop), `platform().desktop is "${p.desktop}"`);
}
function validateAppearance(a) {
	expect(SKINS.includes(a.skin), `appearance().skin is "${a.skin}"`);
	expect(/^#[0-9a-f]{6}$/i.test(a.accent), `appearance().accent is "${a.accent}"; expected #rrggbb`);
	expect(a.scheme === "light" || a.scheme === "dark", `appearance().scheme is "${a.scheme}"`);
	expect([
		"normal",
		"more",
		"forced"
	].includes(a.contrast), `appearance().contrast is "${a.contrast}"`);
	expect(typeof a.reduceTransparency === "boolean", "appearance().reduceTransparency must be a boolean");
	expect(typeof a.reduceMotion === "boolean", "appearance().reduceMotion must be a boolean");
	expect(typeof a.textScale === "number" && a.textScale >= .5 && a.textScale <= 4, `appearance().textScale is ${a.textScale}`);
}
const CHECKS = [
	{
		id: "runtime",
		title: "declares a known runtime",
		run: (h) => expect(RUNTIMES.includes(h.runtime), `runtime is "${h.runtime}"; expected one of ${RUNTIMES.join(", ")}`)
	},
	{
		id: "capabilities",
		title: "reports every capability as native, partial or none",
		run: (h) => {
			for (const c of CAPABILITIES) {
				expect(c in h.capabilities, `capability "${c}" is missing`);
				expect(LEVELS.includes(h.capabilities[c]), `capability "${c}" is "${h.capabilities[c]}"`);
			}
		}
	},
	{
		id: "platform",
		title: "platform() resolves a valid PlatformInfo",
		run: async (h) => validatePlatform(await h.platform())
	},
	{
		id: "appearance",
		title: "appearance() resolves a valid AppearanceState",
		run: async (h) => validateAppearance(await h.appearance())
	},
	{
		id: "skin-agrees",
		title: "appearance().skin agrees with platform().skin",
		run: async (h) => {
			const [p, a] = await Promise.all([h.platform(), h.appearance()]);
			expect(p.skin === a.skin, `platform().skin is "${p.skin}" but appearance().skin is "${a.skin}"`);
		}
	},
	{
		id: "focus",
		title: "window.isFocused() resolves a boolean",
		run: async (h) => expect(typeof await h.window.isFocused() === "boolean", "isFocused() must resolve a boolean")
	},
	{
		id: "menus-match-capability",
		title: "menus are present exactly when nativeMenus is not none",
		run: (h) => {
			const level = h.capabilities.nativeMenus;
			const m = h.menus;
			if (level === "none") {
				expect(!m, "nativeMenus is \"none\" but the host has menus");
				return;
			}
			expect(m, `nativeMenus is "${level}" but the host has no menus`);
			expect(typeof m.onAction === "function", "menus.onAction must be a function");
			expect(m.setApplicationMenu || m.showContextMenu, "menus must offer setApplicationMenu() or showContextMenu()");
			const off = m.onAction(() => void 0);
			expect(typeof off === "function", "menus.onAction must return an unsubscribe function");
			off();
			off();
		}
	},
	{
		id: "dialogs-match-capability",
		title: "dialogs are present exactly when fileDialogs is not none",
		run: (h) => {
			const level = h.capabilities.fileDialogs;
			const d = h.dialogs;
			if (level === "none") {
				expect(!d, "fileDialogs is \"none\" but the host has dialogs");
				return;
			}
			expect(d, `fileDialogs is "${level}" but the host has no dialogs`);
			for (const m of [
				"openFile",
				"saveFile",
				"pickFolder"
			]) expect(typeof d[m] === "function", `dialogs.${m} must be a function`);
			expect(d.message === void 0 || typeof d.message === "function", "dialogs.message must be a function when present");
		}
	},
	{
		id: "unsubscribe",
		title: "subscriptions return an unsubscribe function that can be called twice",
		run: (h) => {
			const offA = h.onAppearanceChange(() => void 0);
			const offF = h.window.onFocusChange(() => void 0);
			expect(typeof offA === "function" && typeof offF === "function", "subscribe must return a function");
			offA();
			offA();
			offF();
			offF();
		}
	},
	{
		id: "graceful",
		title: "never throws for capabilities it reports as 'none'",
		run: async (h) => {
			if (h.capabilities.nativeMenus === "none") expect(h.menus === void 0 || typeof h.menus === "object", "menus must be undefined or an object");
			if (h.capabilities.notifications === "none") expect(h.notifications === void 0 || typeof h.notifications === "object", "notifications must be undefined or an object");
			await h.platform();
			await h.appearance();
		}
	},
	{
		id: "live-appearance",
		title: "notifies appearance changes, with the new values",
		run: async (h, d) => {
			if (!d.setAppearance) skip("no driver.setAppearance");
			const before = await h.appearance();
			const scheme = before.scheme === "dark" ? "light" : "dark";
			const sub = capture((cb) => h.onAppearanceChange(cb));
			await d.setAppearance({ scheme });
			const got = await sub.next();
			sub.unsubscribe();
			expect(got.length > 0, "onAppearanceChange did not fire after the scheme changed");
			validateAppearance(got[got.length - 1]);
			expect(got[got.length - 1].scheme === scheme, `expected scheme "${scheme}", got "${got[got.length - 1].scheme}"`);
			await d.setAppearance({ scheme: before.scheme });
		}
	},
	{
		id: "live-appearance-stops",
		title: "stops notifying after unsubscribe",
		run: async (h, d) => {
			if (!d.setAppearance) skip("no driver.setAppearance");
			const before = await h.appearance();
			const sub = capture((cb) => h.onAppearanceChange(cb), 120);
			sub.unsubscribe();
			await d.setAppearance({ scheme: before.scheme === "dark" ? "light" : "dark" });
			const got = await sub.next();
			await d.setAppearance({ scheme: before.scheme });
			expect(got.length === 0, "onAppearanceChange fired after unsubscribe");
		}
	},
	{
		id: "live-focus",
		title: "notifies window focus changes",
		run: async (h, d) => {
			if (!d.setFocused) skip("no driver.setFocused");
			const sub = capture((cb) => h.window.onFocusChange(cb));
			await d.setFocused(false);
			await d.setFocused(true);
			const got = await sub.next(2);
			sub.unsubscribe();
			expect(got.includes(false) && got[got.length - 1] === true, `expected [false … true], got [${got.join(", ")}]`);
		}
	}
];
async function checkHostConformance(host, driver = {}) {
	const results = [];
	for (const check of CHECKS) try {
		await check.run(host, driver);
		results.push({
			id: check.id,
			title: check.title,
			status: "pass"
		});
	} catch (e) {
		const skipped = e instanceof SkipCheck;
		results.push({
			id: check.id,
			title: check.title,
			status: skipped ? "skip" : "fail",
			detail: e instanceof Error ? e.message : String(e)
		});
	}
	return {
		runtime: host.runtime,
		passed: results.every((r) => r.status !== "fail"),
		results
	};
}
function describeHostConformance(name, factory) {
	const g = globalThis;
	if (!g.describe || !g.it) throw new Error("describeHostConformance needs global describe/it (enable your runner's globals).");
	const { describe, it } = g;
	describe(`${name} · host conformance`, () => {
		for (const check of CHECKS) it(check.title, async () => {
			const { host, driver = {} } = await factory();
			try {
				await check.run(host, driver);
			} catch (e) {
				if (!(e instanceof SkipCheck)) throw e;
				console.info(`[${name}] skipped "${check.title}": ${e.message}`);
			}
		});
	});
}
export { CHECKS, SkipCheck, checkHostConformance, describeHostConformance, validateAppearance, validatePlatform };

//# sourceMappingURL=spartan-native-host-conformance.mjs.map