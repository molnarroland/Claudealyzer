import { AppearanceState, NativeHost, PlatformInfo } from "@spartan-native/theme";
/**
 * Lets the suite simulate the OS, so the live-event checks can run.
 * Adapters that can't be driven in a test omit it; those checks are then skipped.
 */
export interface HostDriver {
  /** Change what the OS reports (e.g. flip dark mode, change the accent). */
  setAppearance?(patch: Partial<AppearanceState>): void | Promise<void>;
  /** Focus or blur the window. */
  setFocused?(focused: boolean): void | Promise<void>;
}
export type CheckStatus = 'pass' | 'fail' | 'skip';
export interface CheckResult {
  readonly id: string;
  readonly title: string;
  readonly status: CheckStatus;
  readonly detail?: string;
}
export interface ConformanceReport {
  readonly runtime: string;
  readonly passed: boolean;
  readonly results: readonly CheckResult[];
}
/** One check: throws to fail, throws SkipCheck to skip. */
export interface Check {
  readonly id: string;
  readonly title: string;
  run(host: NativeHost, driver: HostDriver): Promise<void> | void;
}
/** Thrown when a check can't run for this host (e.g. no driver to simulate the OS). */
export declare class SkipCheck extends Error {}
export declare function validatePlatform(p: PlatformInfo): void;
export declare function validateAppearance(a: AppearanceState): void;
/** The checks, in order. Exported so runners can show them as separate tests. */
export declare const CHECKS: readonly Check[];
/**
 * Runs every check against a host and returns a report. Never throws.
 *
 * ```ts
 * const report = await checkHostConformance(wailsHost(), driver);
 * if (!report.passed) console.table(report.results);
 * ```
 */
export declare function checkHostConformance(host: NativeHost, driver?: HostDriver): Promise<ConformanceReport>;
/** What a factory returns: a fresh host, and optionally a driver that simulates the OS. */
export interface HostUnderTest {
  host: NativeHost;
  driver?: HostDriver;
}
/**
 * Registers the conformance suite with the test runner in use (Vitest, Jest, Jasmine:
 * anything with global `describe` / `it`). Each check becomes one test, so a
 * failure names exactly what is wrong. Skipped checks pass and say why.
 *
 * ```ts
 * // wails-host.spec.ts in the host-wails repository (npm/projects/host-wails/src/lib/)
 * describeHostConformance('wailsHost', () => ({ host: wailsHost({ runtime: fakeWailsRuntime() }), driver }));
 * ```
 */
export declare function describeHostConformance(name: string, factory: () => HostUnderTest | Promise<HostUnderTest>): void;