import * as i0 from "@angular/core";
import { ApplicationRef, ChangeDetectionStrategy, Component, DestroyRef, Directive, ElementRef, EnvironmentInjector, Injectable, InjectionToken, Injector, TemplateRef, ViewContainerRef, afterNextRender, afterRenderEffect, booleanAttribute, computed, contentChild, contentChildren, createComponent, effect, forwardRef, inject, input, isDevMode, linkedSignal, model, numberAttribute, output, signal, untracked, viewChild } from "@angular/core";
import { SpartanNativeTheme, injectNativeSkin, injectPlatformFamily, injectSkin, skinFamily } from "@spartan-native/theme";
import { NgIcon } from "@ng-icons/core";
import { FocusKeyManager, InputModalityDetector } from "@angular/cdk/a11y";
import { Directionality } from "@angular/cdk/bidi";
import * as i1 from "@angular/cdk/menu";
import { CdkContextMenuTrigger, CdkMenu, CdkMenuBar, CdkMenuItem, CdkMenuItemCheckbox, CdkMenuItemRadio, CdkMenuTrigger } from "@angular/cdk/menu";
import { DOCUMENT, NgTemplateOutlet } from "@angular/common";
import { createFlexibleConnectedPositionStrategy, createGlobalPositionStrategy, createOverlayRef, createRepositionScrollStrategy } from "@angular/cdk/overlay";
import { ComponentPortal, DomPortal } from "@angular/cdk/portal";
import { Dialog } from "@angular/cdk/dialog";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { selectionAll, selectionClick, selectionMoveBy, selectionMoveTo, selectionToggleActive, typeaheadIndex } from "@spartan-native/helm";
var SnWindowControls = class SnWindowControls {
	buttons = input([
		"minimize",
		"maximize",
		"close"
	], ...ngDevMode ? [{ debugName: "buttons" }] : /* istanbul ignore next */ []);
	maximized = input(false, {
		...ngDevMode ? { debugName: "maximized" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	linuxAll = input(false, {
		...ngDevMode ? { debugName: "linuxAll" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	nativeActions = input(true, {
		...ngDevMode ? { debugName: "nativeActions" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	minimize = output();
	maximize = output();
	close = output();
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	look = computed(() => {
		const skin = this.skin();
		if (skin === "qt") return "kde";
		if (skin === "cros") return "cros";
		const family = this.family();
		return family === "macos" || family === "windows" ? family : "gnome";
	}, ...ngDevMode ? [{ debugName: "look" }] : /* istanbul ignore next */ []);
	hostWindow = inject(SpartanNativeTheme, { optional: true })?.window;
	hostMaximized = signal(false, ...ngDevMode ? [{ debugName: "hostMaximized" }] : /* istanbul ignore next */ []);
	isMaximized = computed(() => this.maximized() || this.hostMaximized(), ...ngDevMode ? [{ debugName: "isMaximized" }] : /* istanbul ignore next */ []);
	constructor() {
		const off = this.hostWindow?.onMaximizedChange?.((m) => this.hostMaximized.set(m));
		if (off) inject(DestroyRef).onDestroy(off);
		this.hostWindow?.isMaximized?.().then((m) => this.hostMaximized.set(m));
	}
	act(action) {
		if (action === "minimize") this.minimize.emit();
		if (action === "maximize") this.maximize.emit();
		if (action === "close") this.close.emit();
		if (!this.nativeActions() || !this.hostWindow) return;
		if (action === "minimize") this.hostWindow.minimize?.();
		if (action === "maximize") this.hostWindow.toggleMaximize?.();
		if (action === "close") this.hostWindow.close?.();
	}
	show(button) {
		return this.buttons().includes(button);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnWindowControls,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnWindowControls,
		isStandalone: true,
		selector: "sn-window-controls",
		inputs: {
			buttons: {
				classPropertyName: "buttons",
				publicName: "buttons",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maximized: {
				classPropertyName: "maximized",
				publicName: "maximized",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			linuxAll: {
				classPropertyName: "linuxAll",
				publicName: "linuxAll",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			nativeActions: {
				classPropertyName: "nativeActions",
				publicName: "nativeActions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			minimize: "minimize",
			maximize: "maximize",
			close: "close"
		},
		host: {
			attributes: {
				"data-slot": "sn-window-controls",
				"role": "group",
				"aria-label": "Window"
			},
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			},
			classAttribute: "sn-chrome"
		},
		ngImport: i0,
		template: `
    @switch (look()) {
      @case ('macos') {
        <button type="button" class="light close" aria-label="Close" (click)="act('close')">
          <svg viewBox="0 0 10 10" aria-hidden="true"><path d="M3 3l4 4M7 3l-4 4" /></svg>
        </button>
        <button type="button" class="light minimize" aria-label="Minimize" (click)="act('minimize')">
          <svg viewBox="0 0 10 10" aria-hidden="true"><path d="M2.5 5h5" /></svg>
        </button>
        <button type="button" class="light zoom" aria-label="Zoom" (click)="act('maximize')">
          <svg viewBox="0 0 10 10" aria-hidden="true"><path d="M3 6.8V3h3.8M7 3.2V7H3.2" /></svg>
        </button>
      }
      @case ('gnome') {
        @if (show('minimize') && linuxAll()) {
          <button type="button" class="round" aria-label="Minimize" (click)="act('minimize')">
            <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 11.5h7" /></svg>
          </button>
        }
        @if (show('maximize') && linuxAll()) {
          <button type="button" class="round" [attr.aria-label]="isMaximized() ? 'Restore' : 'Maximize'" (click)="act('maximize')">
            <svg viewBox="0 0 16 16" aria-hidden="true"><rect x="4.5" y="4.5" width="7" height="7" rx="1" /></svg>
          </button>
        }
        <button type="button" class="round" aria-label="Close" (click)="act('close')">
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5 5l6 6M11 5l-6 6" /></svg>
        </button>
      }
      @default {
        <!-- Windows, KDE Breeze and ChromeOS: minimize, maximize, close on the right -->
        @if (show('minimize')) {
          <button type="button" class="caption" aria-label="Minimize" (click)="act('minimize')">
            <svg viewBox="0 0 10 10" aria-hidden="true">
              @if (look() === 'kde') {
                <path d="M1.5 3.5L5 7l3.5-3.5" />
              } @else {
                <path d="M0 5h10" />
              }
            </svg>
          </button>
        }
        @if (show('maximize')) {
          <button type="button" class="caption" [attr.aria-label]="isMaximized() ? 'Restore' : 'Maximize'" (click)="act('maximize')">
            <svg viewBox="0 0 10 10" aria-hidden="true">
              @if (look() === 'kde') {
                @if (isMaximized()) {
                  <path d="M5 1.5L8.5 5 5 8.5 1.5 5z" />
                } @else {
                  <path d="M1.5 6.5L5 3l3.5 3.5" />
                }
              } @else if (isMaximized()) {
                <path d="M2.5 2.5V1h6.5v6.5H7.5M1 2.5h6.5V9H1z" />
              } @else {
                <rect x="0.5" y="0.5" width="9" height="9" [attr.rx]="skin() === 'w10' ? 0 : look() === 'cros' ? 1.5 : 1" />
              }
            </svg>
          </button>
        }
        <button type="button" class="caption close" aria-label="Close" (click)="act('close')">
          <svg viewBox="0 0 10 10" aria-hidden="true"><path d="M0.5 0.5l9 9M9.5 0.5l-9 9" /></svg>
        </button>
      }
    }
  `,
		isInline: true,
		styles: [":host{display:inline-flex;align-items:center;flex:none;-webkit-app-region:no-drag;app-region:no-drag;--wails-draggable: no-drag}button{display:grid;place-items:center;padding:0;border:0;background:transparent;color:inherit;cursor:default;transition:background-color var(--sn-duration-fast) var(--sn-easing),color var(--sn-duration-fast) var(--sn-easing)}button:focus-visible{outline:var(--sn-focus-outline);outline-offset:calc(var(--sn-focus-offset) * -1)}svg{fill:none;stroke:currentColor;stroke-width:1;stroke-linecap:round;stroke-linejoin:round}:host([data-family=windows]){align-self:stretch}:host([data-family=windows]) .caption{width:2.875rem;height:100%;min-height:2rem}:host([data-family=windows]) .caption svg{width:.625rem;height:.625rem;stroke-linecap:butt;stroke-linejoin:miter}:host([data-family=windows]) .caption:hover{background:color-mix(in srgb,var(--sn-color-fg) 6%,transparent)}:host([data-family=windows]) .caption:active{background:color-mix(in srgb,var(--sn-color-fg) 4%,transparent)}:host([data-family=windows]) .caption.close:hover{background:#c42b1c;color:#fff}:host([data-family=windows]) .caption.close:active{background:#c83c31;color:#fff}:host([data-skin=w10]) .caption:hover{background:color-mix(in srgb,var(--sn-color-fg) 10%,transparent)}:host([data-skin=w10]) .caption:active{background:color-mix(in srgb,var(--sn-color-fg) 20%,transparent)}:host([data-skin=w10]) .caption.close:hover{background:#e81123}:host([data-skin=w10]) .caption.close:active{background:#f1707a}:host([data-family=macos]){gap:.5rem;padding-inline:.125rem}:host([data-family=macos]) .light{width:.75rem;height:.75rem;border-radius:50%;box-shadow:inset 0 0 0 .5px #0000002e;color:#0000008c}:host([data-family=macos]) .light.close{background:#ff5f57}:host([data-family=macos]) .light.minimize{background:#febc2e}:host([data-family=macos]) .light.zoom{background:#28c840}:host([data-family=macos]) .light svg{width:.5rem;height:.5rem;stroke-width:1.4;opacity:0}:host([data-family=macos]):hover .light svg,:host([data-family=macos]):focus-within .light svg{opacity:1}:host([data-skin=mac]){gap:.5625rem}:host([data-skin=mac]) .light{width:.8125rem;height:.8125rem}:host-context(.inactive) .light{background:color-mix(in srgb,var(--sn-color-fg) 22%,transparent)!important;box-shadow:none}:host([data-family=linux]),:host([data-family=web]){gap:.75rem}:host([data-family=linux]) .round,:host([data-family=web]) .round{width:1.5rem;height:1.5rem;border-radius:50%;background:color-mix(in srgb,var(--sn-color-fg) 10%,transparent)}:host([data-family=linux]) .round svg,:host([data-family=web]) .round svg{width:1rem;height:1rem;stroke-width:1.6}:host([data-family=linux]) .round:hover,:host([data-family=web]) .round:hover{background:color-mix(in srgb,var(--sn-color-fg) 15%,transparent)}:host([data-family=linux]) .round:active,:host([data-family=web]) .round:active{background:color-mix(in srgb,var(--sn-color-fg) 24%,transparent)}:host([data-skin=qt]){gap:.25rem;padding-inline-end:.125rem}:host([data-skin=qt]) .caption{width:1.5rem;height:1.5rem;border-radius:50%}:host([data-skin=qt]) .caption svg{width:.625rem;height:.625rem;stroke-width:1.2}:host([data-skin=qt]) .caption:hover{background:color-mix(in srgb,var(--sn-color-fg) 12%,transparent)}:host([data-skin=qt]) .caption:active{background:color-mix(in srgb,var(--sn-color-fg) 22%,transparent)}:host([data-skin=qt]) .caption.close:hover,:host([data-skin=qt]) .caption.close:active{background:#da4453;color:#fff}:host([data-skin=cros]){gap:.125rem}:host([data-skin=cros]) .caption{width:2rem;height:2rem;border-radius:50%}:host([data-skin=cros]) .caption svg{width:.75rem;height:.75rem;stroke-width:1.2}:host([data-skin=cros]) .caption:hover{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}:host([data-skin=cros]) .caption:active{background:color-mix(in srgb,var(--sn-color-fg) 12%,transparent)}@media(forced-colors:active){button{color:ButtonText!important}.caption:hover,.caption.close:hover,.round:hover{background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-family=macos]) .light{border:1px solid ButtonText;box-sizing:border-box}button:focus-visible{outline:2px solid CanvasText}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnWindowControls,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-window-controls",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-window-controls",
				class: "sn-chrome",
				role: "group",
				"aria-label": "Window",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    @switch (look()) {
      @case ('macos') {
        <button type="button" class="light close" aria-label="Close" (click)="act('close')">
          <svg viewBox="0 0 10 10" aria-hidden="true"><path d="M3 3l4 4M7 3l-4 4" /></svg>
        </button>
        <button type="button" class="light minimize" aria-label="Minimize" (click)="act('minimize')">
          <svg viewBox="0 0 10 10" aria-hidden="true"><path d="M2.5 5h5" /></svg>
        </button>
        <button type="button" class="light zoom" aria-label="Zoom" (click)="act('maximize')">
          <svg viewBox="0 0 10 10" aria-hidden="true"><path d="M3 6.8V3h3.8M7 3.2V7H3.2" /></svg>
        </button>
      }
      @case ('gnome') {
        @if (show('minimize') && linuxAll()) {
          <button type="button" class="round" aria-label="Minimize" (click)="act('minimize')">
            <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 11.5h7" /></svg>
          </button>
        }
        @if (show('maximize') && linuxAll()) {
          <button type="button" class="round" [attr.aria-label]="isMaximized() ? 'Restore' : 'Maximize'" (click)="act('maximize')">
            <svg viewBox="0 0 16 16" aria-hidden="true"><rect x="4.5" y="4.5" width="7" height="7" rx="1" /></svg>
          </button>
        }
        <button type="button" class="round" aria-label="Close" (click)="act('close')">
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5 5l6 6M11 5l-6 6" /></svg>
        </button>
      }
      @default {
        <!-- Windows, KDE Breeze and ChromeOS: minimize, maximize, close on the right -->
        @if (show('minimize')) {
          <button type="button" class="caption" aria-label="Minimize" (click)="act('minimize')">
            <svg viewBox="0 0 10 10" aria-hidden="true">
              @if (look() === 'kde') {
                <path d="M1.5 3.5L5 7l3.5-3.5" />
              } @else {
                <path d="M0 5h10" />
              }
            </svg>
          </button>
        }
        @if (show('maximize')) {
          <button type="button" class="caption" [attr.aria-label]="isMaximized() ? 'Restore' : 'Maximize'" (click)="act('maximize')">
            <svg viewBox="0 0 10 10" aria-hidden="true">
              @if (look() === 'kde') {
                @if (isMaximized()) {
                  <path d="M5 1.5L8.5 5 5 8.5 1.5 5z" />
                } @else {
                  <path d="M1.5 6.5L5 3l3.5 3.5" />
                }
              } @else if (isMaximized()) {
                <path d="M2.5 2.5V1h6.5v6.5H7.5M1 2.5h6.5V9H1z" />
              } @else {
                <rect x="0.5" y="0.5" width="9" height="9" [attr.rx]="skin() === 'w10' ? 0 : look() === 'cros' ? 1.5 : 1" />
              }
            </svg>
          </button>
        }
        <button type="button" class="caption close" aria-label="Close" (click)="act('close')">
          <svg viewBox="0 0 10 10" aria-hidden="true"><path d="M0.5 0.5l9 9M9.5 0.5l-9 9" /></svg>
        </button>
      }
    }
  `,
			styles: [":host{display:inline-flex;align-items:center;flex:none;-webkit-app-region:no-drag;app-region:no-drag;--wails-draggable: no-drag}button{display:grid;place-items:center;padding:0;border:0;background:transparent;color:inherit;cursor:default;transition:background-color var(--sn-duration-fast) var(--sn-easing),color var(--sn-duration-fast) var(--sn-easing)}button:focus-visible{outline:var(--sn-focus-outline);outline-offset:calc(var(--sn-focus-offset) * -1)}svg{fill:none;stroke:currentColor;stroke-width:1;stroke-linecap:round;stroke-linejoin:round}:host([data-family=windows]){align-self:stretch}:host([data-family=windows]) .caption{width:2.875rem;height:100%;min-height:2rem}:host([data-family=windows]) .caption svg{width:.625rem;height:.625rem;stroke-linecap:butt;stroke-linejoin:miter}:host([data-family=windows]) .caption:hover{background:color-mix(in srgb,var(--sn-color-fg) 6%,transparent)}:host([data-family=windows]) .caption:active{background:color-mix(in srgb,var(--sn-color-fg) 4%,transparent)}:host([data-family=windows]) .caption.close:hover{background:#c42b1c;color:#fff}:host([data-family=windows]) .caption.close:active{background:#c83c31;color:#fff}:host([data-skin=w10]) .caption:hover{background:color-mix(in srgb,var(--sn-color-fg) 10%,transparent)}:host([data-skin=w10]) .caption:active{background:color-mix(in srgb,var(--sn-color-fg) 20%,transparent)}:host([data-skin=w10]) .caption.close:hover{background:#e81123}:host([data-skin=w10]) .caption.close:active{background:#f1707a}:host([data-family=macos]){gap:.5rem;padding-inline:.125rem}:host([data-family=macos]) .light{width:.75rem;height:.75rem;border-radius:50%;box-shadow:inset 0 0 0 .5px #0000002e;color:#0000008c}:host([data-family=macos]) .light.close{background:#ff5f57}:host([data-family=macos]) .light.minimize{background:#febc2e}:host([data-family=macos]) .light.zoom{background:#28c840}:host([data-family=macos]) .light svg{width:.5rem;height:.5rem;stroke-width:1.4;opacity:0}:host([data-family=macos]):hover .light svg,:host([data-family=macos]):focus-within .light svg{opacity:1}:host([data-skin=mac]){gap:.5625rem}:host([data-skin=mac]) .light{width:.8125rem;height:.8125rem}:host-context(.inactive) .light{background:color-mix(in srgb,var(--sn-color-fg) 22%,transparent)!important;box-shadow:none}:host([data-family=linux]),:host([data-family=web]){gap:.75rem}:host([data-family=linux]) .round,:host([data-family=web]) .round{width:1.5rem;height:1.5rem;border-radius:50%;background:color-mix(in srgb,var(--sn-color-fg) 10%,transparent)}:host([data-family=linux]) .round svg,:host([data-family=web]) .round svg{width:1rem;height:1rem;stroke-width:1.6}:host([data-family=linux]) .round:hover,:host([data-family=web]) .round:hover{background:color-mix(in srgb,var(--sn-color-fg) 15%,transparent)}:host([data-family=linux]) .round:active,:host([data-family=web]) .round:active{background:color-mix(in srgb,var(--sn-color-fg) 24%,transparent)}:host([data-skin=qt]){gap:.25rem;padding-inline-end:.125rem}:host([data-skin=qt]) .caption{width:1.5rem;height:1.5rem;border-radius:50%}:host([data-skin=qt]) .caption svg{width:.625rem;height:.625rem;stroke-width:1.2}:host([data-skin=qt]) .caption:hover{background:color-mix(in srgb,var(--sn-color-fg) 12%,transparent)}:host([data-skin=qt]) .caption:active{background:color-mix(in srgb,var(--sn-color-fg) 22%,transparent)}:host([data-skin=qt]) .caption.close:hover,:host([data-skin=qt]) .caption.close:active{background:#da4453;color:#fff}:host([data-skin=cros]){gap:.125rem}:host([data-skin=cros]) .caption{width:2rem;height:2rem;border-radius:50%}:host([data-skin=cros]) .caption svg{width:.75rem;height:.75rem;stroke-width:1.2}:host([data-skin=cros]) .caption:hover{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}:host([data-skin=cros]) .caption:active{background:color-mix(in srgb,var(--sn-color-fg) 12%,transparent)}@media(forced-colors:active){button{color:ButtonText!important}.caption:hover,.caption.close:hover,.round:hover{background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-family=macos]) .light{border:1px solid ButtonText;box-sizing:border-box}button:focus-visible{outline:2px solid CanvasText}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		buttons: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "buttons",
				required: false
			}]
		}],
		maximized: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maximized",
				required: false
			}]
		}],
		linuxAll: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "linuxAll",
				required: false
			}]
		}],
		nativeActions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "nativeActions",
				required: false
			}]
		}],
		minimize: [{
			type: i0.Output,
			args: ["minimize"]
		}],
		maximize: [{
			type: i0.Output,
			args: ["maximize"]
		}],
		close: [{
			type: i0.Output,
			args: ["close"]
		}]
	}
});
var SnTitleBar = class SnTitleBar {
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	subtitle = input("", ...ngDevMode ? [{ debugName: "subtitle" }] : /* istanbul ignore next */ []);
	windowControls = input("custom", ...ngDevMode ? [{ debugName: "windowControls" }] : /* istanbul ignore next */ []);
	buttons = input([
		"minimize",
		"maximize",
		"close"
	], ...ngDevMode ? [{ debugName: "buttons" }] : /* istanbul ignore next */ []);
	maximized = input(false, {
		...ngDevMode ? { debugName: "maximized" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	minimize = output();
	maximize = output();
	close = output();
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	nativeSkin = injectNativeSkin();
	showIcon = computed(() => this.family() === "windows" || this.skin() === "qt" || this.skin() === "cros", ...ngDevMode ? [{ debugName: "showIcon" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnTitleBar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnTitleBar,
		isStandalone: true,
		selector: "sn-title-bar",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			subtitle: {
				classPropertyName: "subtitle",
				publicName: "subtitle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			windowControls: {
				classPropertyName: "windowControls",
				publicName: "windowControls",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			buttons: {
				classPropertyName: "buttons",
				publicName: "buttons",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maximized: {
				classPropertyName: "maximized",
				publicName: "maximized",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			minimize: "minimize",
			maximize: "maximize",
			close: "close"
		},
		host: {
			attributes: {
				"data-slot": "sn-title-bar",
				"role": "banner",
				"data-tauri-drag-region": ""
			},
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()",
				"attr.data-controls": "windowControls()",
				"attr.data-native": "windowControls() === \"native\" ? nativeSkin() : null"
			},
			classAttribute: "sn-chrome"
		},
		ngImport: i0,
		template: `
    @if (family() === 'macos' && windowControls() === 'custom') {
      <sn-window-controls [buttons]="buttons()" (close)="close.emit()" (minimize)="minimize.emit()" (maximize)="maximize.emit()" />
    }
    <div class="start">
      @if (showIcon()) {
        <ng-content select="[snTitleBarIcon]" />
      }
      <ng-content select="[snTitleBarStart]" />
    </div>
    <div class="title">
      <span class="text">{{ title() }}</span>
      @if (subtitle()) {
        <span class="subtitle">{{ subtitle() }}</span>
      }
    </div>
    <div class="end">
      <ng-content select="[snTitleBarEnd]" />
    </div>
    @if (family() !== 'macos' && windowControls() === 'custom') {
      <sn-window-controls
        [buttons]="buttons()"
        [maximized]="maximized()"
        (close)="close.emit()"
        (minimize)="minimize.emit()"
        (maximize)="maximize.emit()"
      />
    }
  `,
		isInline: true,
		styles: [":host{display:flex;align-items:center;gap:.5rem;position:relative;flex:none;-webkit-user-select:none;user-select:none;-webkit-app-region:drag;app-region:drag;--wails-draggable: drag}.start,.end{display:flex;align-items:center;gap:.375rem}.start ::ng-deep>:is(button,a,input,[role=button]),.end ::ng-deep>:is(button,a,input,[role=button]){-webkit-app-region:no-drag;app-region:no-drag;--wails-draggable: no-drag}.title{display:flex;flex-direction:column;min-width:0;line-height:1.2}.text,.subtitle{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.subtitle{font-size:var(--sn-font-size-small);font-weight:400;color:var(--sn-color-fg-muted)}.start ::ng-deep [snTitleBarIcon]{width:1rem;height:1rem}:host([data-family=linux]) .title,:host([data-family=web]) .title,:host([data-family=macos]) .title{position:absolute;left:50%;translate:-50% 0;align-items:center;max-width:50%}:host([data-family=linux]) .end,:host([data-family=web]) .end,:host([data-family=macos]) .end{margin-inline-start:auto}:host([data-family=windows]){height:2rem;padding-inline-start:1rem;font-size:var(--sn-font-size-small)}:host([data-family=windows]) .title{margin-inline-end:auto}:host([data-family=windows])[data-controls=native]{height:env(titlebar-area-height,2rem)}:host([data-skin=w10]){padding-inline-start:.5rem}:host([data-family=macos]){height:2.375rem;padding-inline:.875rem;font-size:var(--sn-font-size)}:host([data-family=macos]) .title{font-weight:var(--sn-font-weight-strong)}:host([data-family=macos])[data-controls=native]{height:env(titlebar-area-height,2.375rem)}:host([data-skin=macc]){height:1.75rem;padding-inline:.5rem}:host([data-skin=macc])[data-controls=native]{height:env(titlebar-area-height,1.75rem)}:host([data-family=linux]),:host([data-family=web]){min-height:2.875rem;padding-inline:.375rem .625rem;font-size:var(--sn-font-size)}:host([data-family=linux]) .title,:host([data-family=web]) .title{font-weight:700}:host([data-family=linux])[data-controls=native],:host([data-family=web])[data-controls=native]{min-height:env(titlebar-area-height,2.875rem)}:host([data-skin=qt]){min-height:2.125rem;padding-inline:.75rem .375rem;background:var(--sn-color-bg)}:host([data-skin=qt]) .title{font-weight:400}:host([data-skin=qt])[data-controls=native]{min-height:env(titlebar-area-height,2.125rem)}:host([data-skin=cros]){min-height:2.25rem;padding-inline:.875rem .25rem;font-size:.8125rem}:host([data-skin=cros]) .title{margin-inline-end:auto;font-weight:var(--sn-font-weight-strong)}:host([data-skin=cros])[data-controls=native]{min-height:env(titlebar-area-height,2.25rem)}:host([data-native=win]),:host([data-native=w10]){padding-inline-end:calc(100vw - env(titlebar-area-x,0px) - env(titlebar-area-width,calc(100vw - 8.625rem)))}:host([data-native=mac]){padding-inline-start:env(titlebar-area-x,4.875rem)}:host([data-native=macc]){padding-inline-start:env(titlebar-area-x,4.375rem)}:host([data-native=gtk]),:host([data-native=web]){padding-inline-end:calc(100vw - env(titlebar-area-x,0px) - env(titlebar-area-width,calc(100vw - 6rem)))}:host([data-native=qt]){padding-inline-end:calc(100vw - env(titlebar-area-x,0px) - env(titlebar-area-width,calc(100vw - 5.5rem)))}:host([data-native=cros]){padding-inline-end:calc(100vw - env(titlebar-area-x,0px) - env(titlebar-area-width,calc(100vw - 6.75rem)))}@media(forced-colors:active){:host{border-bottom:1px solid CanvasText}}\n"],
		dependencies: [{
			kind: "component",
			type: SnWindowControls,
			selector: "sn-window-controls",
			inputs: [
				"buttons",
				"maximized",
				"linuxAll",
				"nativeActions"
			],
			outputs: [
				"minimize",
				"maximize",
				"close"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnTitleBar,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-title-bar",
			imports: [SnWindowControls],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-title-bar",
				class: "sn-chrome",
				role: "banner",
				"data-tauri-drag-region": "",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()",
				"[attr.data-controls]": "windowControls()",
				"[attr.data-native]": "windowControls() === \"native\" ? nativeSkin() : null"
			},
			template: `
    @if (family() === 'macos' && windowControls() === 'custom') {
      <sn-window-controls [buttons]="buttons()" (close)="close.emit()" (minimize)="minimize.emit()" (maximize)="maximize.emit()" />
    }
    <div class="start">
      @if (showIcon()) {
        <ng-content select="[snTitleBarIcon]" />
      }
      <ng-content select="[snTitleBarStart]" />
    </div>
    <div class="title">
      <span class="text">{{ title() }}</span>
      @if (subtitle()) {
        <span class="subtitle">{{ subtitle() }}</span>
      }
    </div>
    <div class="end">
      <ng-content select="[snTitleBarEnd]" />
    </div>
    @if (family() !== 'macos' && windowControls() === 'custom') {
      <sn-window-controls
        [buttons]="buttons()"
        [maximized]="maximized()"
        (close)="close.emit()"
        (minimize)="minimize.emit()"
        (maximize)="maximize.emit()"
      />
    }
  `,
			styles: [":host{display:flex;align-items:center;gap:.5rem;position:relative;flex:none;-webkit-user-select:none;user-select:none;-webkit-app-region:drag;app-region:drag;--wails-draggable: drag}.start,.end{display:flex;align-items:center;gap:.375rem}.start ::ng-deep>:is(button,a,input,[role=button]),.end ::ng-deep>:is(button,a,input,[role=button]){-webkit-app-region:no-drag;app-region:no-drag;--wails-draggable: no-drag}.title{display:flex;flex-direction:column;min-width:0;line-height:1.2}.text,.subtitle{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.subtitle{font-size:var(--sn-font-size-small);font-weight:400;color:var(--sn-color-fg-muted)}.start ::ng-deep [snTitleBarIcon]{width:1rem;height:1rem}:host([data-family=linux]) .title,:host([data-family=web]) .title,:host([data-family=macos]) .title{position:absolute;left:50%;translate:-50% 0;align-items:center;max-width:50%}:host([data-family=linux]) .end,:host([data-family=web]) .end,:host([data-family=macos]) .end{margin-inline-start:auto}:host([data-family=windows]){height:2rem;padding-inline-start:1rem;font-size:var(--sn-font-size-small)}:host([data-family=windows]) .title{margin-inline-end:auto}:host([data-family=windows])[data-controls=native]{height:env(titlebar-area-height,2rem)}:host([data-skin=w10]){padding-inline-start:.5rem}:host([data-family=macos]){height:2.375rem;padding-inline:.875rem;font-size:var(--sn-font-size)}:host([data-family=macos]) .title{font-weight:var(--sn-font-weight-strong)}:host([data-family=macos])[data-controls=native]{height:env(titlebar-area-height,2.375rem)}:host([data-skin=macc]){height:1.75rem;padding-inline:.5rem}:host([data-skin=macc])[data-controls=native]{height:env(titlebar-area-height,1.75rem)}:host([data-family=linux]),:host([data-family=web]){min-height:2.875rem;padding-inline:.375rem .625rem;font-size:var(--sn-font-size)}:host([data-family=linux]) .title,:host([data-family=web]) .title{font-weight:700}:host([data-family=linux])[data-controls=native],:host([data-family=web])[data-controls=native]{min-height:env(titlebar-area-height,2.875rem)}:host([data-skin=qt]){min-height:2.125rem;padding-inline:.75rem .375rem;background:var(--sn-color-bg)}:host([data-skin=qt]) .title{font-weight:400}:host([data-skin=qt])[data-controls=native]{min-height:env(titlebar-area-height,2.125rem)}:host([data-skin=cros]){min-height:2.25rem;padding-inline:.875rem .25rem;font-size:.8125rem}:host([data-skin=cros]) .title{margin-inline-end:auto;font-weight:var(--sn-font-weight-strong)}:host([data-skin=cros])[data-controls=native]{min-height:env(titlebar-area-height,2.25rem)}:host([data-native=win]),:host([data-native=w10]){padding-inline-end:calc(100vw - env(titlebar-area-x,0px) - env(titlebar-area-width,calc(100vw - 8.625rem)))}:host([data-native=mac]){padding-inline-start:env(titlebar-area-x,4.875rem)}:host([data-native=macc]){padding-inline-start:env(titlebar-area-x,4.375rem)}:host([data-native=gtk]),:host([data-native=web]){padding-inline-end:calc(100vw - env(titlebar-area-x,0px) - env(titlebar-area-width,calc(100vw - 6rem)))}:host([data-native=qt]){padding-inline-end:calc(100vw - env(titlebar-area-x,0px) - env(titlebar-area-width,calc(100vw - 5.5rem)))}:host([data-native=cros]){padding-inline-end:calc(100vw - env(titlebar-area-x,0px) - env(titlebar-area-width,calc(100vw - 6.75rem)))}@media(forced-colors:active){:host{border-bottom:1px solid CanvasText}}\n"]
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		subtitle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "subtitle",
				required: false
			}]
		}],
		windowControls: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "windowControls",
				required: false
			}]
		}],
		buttons: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "buttons",
				required: false
			}]
		}],
		maximized: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maximized",
				required: false
			}]
		}],
		minimize: [{
			type: i0.Output,
			args: ["minimize"]
		}],
		maximize: [{
			type: i0.Output,
			args: ["maximize"]
		}],
		close: [{
			type: i0.Output,
			args: ["close"]
		}]
	}
});
var SnStatusItem = class SnStatusItem {
	live = input(false, {
		...ngDevMode ? { debugName: "live" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnStatusItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnStatusItem,
		isStandalone: true,
		selector: "[snStatusItem]",
		inputs: { live: {
			classPropertyName: "live",
			publicName: "live",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "data-slot": "sn-status-item" },
			properties: { "attr.role": "live() ? 'status' : null" }
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnStatusItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[snStatusItem]",
			host: {
				"data-slot": "sn-status-item",
				"[attr.role]": "live() ? 'status' : null"
			}
		}]
	}],
	propDecorators: { live: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "live",
			required: false
		}]
	}] }
});
var SnStatusBar = class SnStatusBar {
	ariaLabel = input("Status", ...ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnStatusBar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnStatusBar,
		isStandalone: true,
		selector: "sn-status-bar",
		inputs: { ariaLabel: {
			classPropertyName: "ariaLabel",
			publicName: "ariaLabel",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: {
				"data-slot": "sn-status-bar",
				"role": "group"
			},
			properties: {
				"attr.aria-label": "ariaLabel()",
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			},
			classAttribute: "sn-chrome"
		},
		ngImport: i0,
		template: `
    <div class="start"><ng-content /></div>
    <div class="end"><ng-content select="[snStatusBarEnd]" /></div>
  `,
		isInline: true,
		styles: ["@charset \"UTF-8\";:host{display:flex;align-items:center;gap:1rem;flex:none;min-width:0;min-height:1.5rem;padding-inline:.75rem;box-sizing:border-box;background:var(--sn-color-bg);color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small);line-height:1.3;white-space:nowrap;-webkit-user-select:none;user-select:none}.start,.end{display:flex;align-items:center;gap:1rem;min-width:0}.start{flex:1}.end:empty{display:none}:host ::ng-deep [data-slot=sn-status-item]{display:inline-flex;align-items:center;gap:.375rem;min-width:0;overflow:hidden;text-overflow:ellipsis}:host([data-skin=win]){min-height:1.75rem;padding-inline:1rem;gap:1.25rem}:host([data-skin=win]) .start,:host([data-skin=win]) .end{gap:1.25rem}:host([data-skin=w10]),:host([data-skin=qt]){min-height:1.5rem;border-top:1px solid var(--sn-color-border)}:host([data-skin=w10]) .start,:host([data-skin=w10]) .end,:host([data-skin=qt]) .start,:host([data-skin=qt]) .end{gap:0}:host([data-skin=w10]) ::ng-deep [data-slot=sn-status-item],:host([data-skin=qt]) ::ng-deep [data-slot=sn-status-item]{padding-inline:.625rem}:host([data-skin=w10]) ::ng-deep [data-slot=sn-status-item]:first-child,:host([data-skin=qt]) ::ng-deep [data-slot=sn-status-item]:first-child{padding-inline-start:0}:host([data-skin=w10]) ::ng-deep [data-slot=sn-status-item]+[data-slot=sn-status-item],:host([data-skin=w10]) .end,:host([data-skin=qt]) ::ng-deep [data-slot=sn-status-item]+[data-slot=sn-status-item],:host([data-skin=qt]) .end{border-inline-start:1px solid var(--sn-color-border)}:host([data-skin=w10]) .end ::ng-deep [data-slot=sn-status-item]:first-child,:host([data-skin=qt]) .end ::ng-deep [data-slot=sn-status-item]:first-child{padding-inline-start:.625rem}:host([data-skin=w10]) .end ::ng-deep [data-slot=sn-status-item]:last-child,:host([data-skin=qt]) .end ::ng-deep [data-slot=sn-status-item]:last-child{padding-inline-end:0}:host([data-skin=w10]){color:var(--sn-color-fg)}:host([data-skin=qt]){min-height:2rem;padding-inline:.5rem;border-top:0;box-shadow:inset 0 1px 0 var(--sn-color-border);color:var(--sn-color-fg)}:host([data-family=macos]){justify-content:center;gap:0;min-height:1.5rem;border-top:1px solid var(--sn-color-border)}:host([data-family=macos]) .start,:host([data-family=macos]) .end{flex:none;gap:0}:host([data-family=macos]) ::ng-deep [data-slot=sn-status-item]+[data-slot=sn-status-item]:before,:host([data-family=macos]) .end:not(:empty):before{content:\",\\a0\"}:host([data-family=macos]) .start:empty+.end:before{content:none}:host([data-skin=mac]){background:transparent}:host([data-family=linux]:not([data-skin=qt])),:host([data-family=web]){min-height:2.875rem;padding-inline:.75rem;box-shadow:inset 0 1px 0 var(--sn-color-border);color:var(--sn-color-fg);font-size:var(--sn-font-size)}:host([data-family=linux]:not([data-skin=qt])) .start,:host([data-family=linux]:not([data-skin=qt])) .end,:host([data-family=web]) .start,:host([data-family=web]) .end{gap:.75rem}:host([data-family=chromeos]){min-height:2rem;padding-inline:1.5rem;background:transparent;letter-spacing:.01em}:host([data-family=chromeos]) .start,:host([data-family=chromeos]) .end{gap:1.5rem}@media(forced-colors:active){:host{border-top:1px solid CanvasText;color:CanvasText}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnStatusBar,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-status-bar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-status-bar",
				class: "sn-chrome",
				role: "group",
				"[attr.aria-label]": "ariaLabel()",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    <div class="start"><ng-content /></div>
    <div class="end"><ng-content select="[snStatusBarEnd]" /></div>
  `,
			styles: ["@charset \"UTF-8\";:host{display:flex;align-items:center;gap:1rem;flex:none;min-width:0;min-height:1.5rem;padding-inline:.75rem;box-sizing:border-box;background:var(--sn-color-bg);color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small);line-height:1.3;white-space:nowrap;-webkit-user-select:none;user-select:none}.start,.end{display:flex;align-items:center;gap:1rem;min-width:0}.start{flex:1}.end:empty{display:none}:host ::ng-deep [data-slot=sn-status-item]{display:inline-flex;align-items:center;gap:.375rem;min-width:0;overflow:hidden;text-overflow:ellipsis}:host([data-skin=win]){min-height:1.75rem;padding-inline:1rem;gap:1.25rem}:host([data-skin=win]) .start,:host([data-skin=win]) .end{gap:1.25rem}:host([data-skin=w10]),:host([data-skin=qt]){min-height:1.5rem;border-top:1px solid var(--sn-color-border)}:host([data-skin=w10]) .start,:host([data-skin=w10]) .end,:host([data-skin=qt]) .start,:host([data-skin=qt]) .end{gap:0}:host([data-skin=w10]) ::ng-deep [data-slot=sn-status-item],:host([data-skin=qt]) ::ng-deep [data-slot=sn-status-item]{padding-inline:.625rem}:host([data-skin=w10]) ::ng-deep [data-slot=sn-status-item]:first-child,:host([data-skin=qt]) ::ng-deep [data-slot=sn-status-item]:first-child{padding-inline-start:0}:host([data-skin=w10]) ::ng-deep [data-slot=sn-status-item]+[data-slot=sn-status-item],:host([data-skin=w10]) .end,:host([data-skin=qt]) ::ng-deep [data-slot=sn-status-item]+[data-slot=sn-status-item],:host([data-skin=qt]) .end{border-inline-start:1px solid var(--sn-color-border)}:host([data-skin=w10]) .end ::ng-deep [data-slot=sn-status-item]:first-child,:host([data-skin=qt]) .end ::ng-deep [data-slot=sn-status-item]:first-child{padding-inline-start:.625rem}:host([data-skin=w10]) .end ::ng-deep [data-slot=sn-status-item]:last-child,:host([data-skin=qt]) .end ::ng-deep [data-slot=sn-status-item]:last-child{padding-inline-end:0}:host([data-skin=w10]){color:var(--sn-color-fg)}:host([data-skin=qt]){min-height:2rem;padding-inline:.5rem;border-top:0;box-shadow:inset 0 1px 0 var(--sn-color-border);color:var(--sn-color-fg)}:host([data-family=macos]){justify-content:center;gap:0;min-height:1.5rem;border-top:1px solid var(--sn-color-border)}:host([data-family=macos]) .start,:host([data-family=macos]) .end{flex:none;gap:0}:host([data-family=macos]) ::ng-deep [data-slot=sn-status-item]+[data-slot=sn-status-item]:before,:host([data-family=macos]) .end:not(:empty):before{content:\",\\a0\"}:host([data-family=macos]) .start:empty+.end:before{content:none}:host([data-skin=mac]){background:transparent}:host([data-family=linux]:not([data-skin=qt])),:host([data-family=web]){min-height:2.875rem;padding-inline:.75rem;box-shadow:inset 0 1px 0 var(--sn-color-border);color:var(--sn-color-fg);font-size:var(--sn-font-size)}:host([data-family=linux]:not([data-skin=qt])) .start,:host([data-family=linux]:not([data-skin=qt])) .end,:host([data-family=web]) .start,:host([data-family=web]) .end{gap:.75rem}:host([data-family=chromeos]){min-height:2rem;padding-inline:1.5rem;background:transparent;letter-spacing:.01em}:host([data-family=chromeos]) .start,:host([data-family=chromeos]) .end{gap:1.5rem}@media(forced-colors:active){:host{border-top:1px solid CanvasText;color:CanvasText}}\n"]
		}]
	}],
	propDecorators: { ariaLabel: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "ariaLabel",
			required: false
		}]
	}] }
});
const SnStatusBarImports = [SnStatusBar, SnStatusItem];
let nextId$7 = 0;
var SnSettingsGroup = class SnSettingsGroup {
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	description = input("", ...ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []);
	headingId = `sn-settings-group-${nextId$7++}`;
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnSettingsGroup,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnSettingsGroup,
		isStandalone: true,
		selector: "sn-settings-group",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: {
				"data-slot": "sn-settings-group",
				"role": "group"
			},
			properties: {
				"attr.aria-labelledby": "title() ? headingId : null",
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		ngImport: i0,
		template: `
    @if (title() || description()) {
      <div class="header">
        @if (title()) {
          <h2 [id]="headingId">{{ title() }}</h2>
        }
        @if (description()) {
          <p>{{ description() }}</p>
        }
      </div>
    }
    <div class="rows"><ng-content /></div>
  `,
		isInline: true,
		styles: [":host{display:flex;flex-direction:column;gap:.625rem}.header{display:flex;flex-direction:column;gap:.125rem}h2,p{margin:0}h2{font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong)}p{color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small)}.rows{display:flex;flex-direction:column}:host([data-family=linux]) h2,:host([data-family=web]) h2{font-weight:700}:host([data-family=linux]) .rows,:host([data-family=web]) .rows{overflow:hidden;border-radius:var(--sn-radius-surface);background:var(--sn-color-surface-solid);box-shadow:var(--sn-shadow-card)}:host([data-family=windows]){gap:.5rem}:host([data-family=windows]) .rows{gap:.25rem}:host([data-skin=w10]) h2{font-size:var(--sn-font-size-title);font-weight:400}:host([data-skin=w10]) .rows{gap:.5rem}:host([data-family=macos]){gap:.375rem}:host([data-family=macos]) .header{padding-inline:.625rem}:host([data-family=macos]) .rows{overflow:hidden;border-radius:.75rem;border:1px solid var(--sn-color-glass-border);background:var(--sn-color-glass);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-skin=macc]) .rows{border-radius:var(--sn-radius-surface);box-shadow:none}:host([data-skin=qt]){gap:.75rem}:host([data-skin=qt]) .header{align-items:center;text-align:center}:host([data-skin=qt]) h2{font-size:calc(var(--sn-font-size) * 1.2);font-weight:var(--sn-font-weight-strong)}:host([data-skin=qt]) .rows{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);column-gap:.75rem;row-gap:.625rem;overflow:visible;border-radius:0;background:none;box-shadow:none}:host([data-skin=cros]){gap:.5rem}:host([data-skin=cros]) .header{padding-inline:1rem}:host([data-skin=cros]) h2{color:var(--sn-color-fg)}:host([data-skin=cros]) .rows{overflow:hidden;border-radius:var(--sn-radius-surface);background:var(--sn-color-surface)}@media(forced-colors:active){.rows{border:1px solid CanvasText}:host([data-skin=qt]) .rows{border:0}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnSettingsGroup,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-settings-group",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-settings-group",
				role: "group",
				"[attr.aria-labelledby]": "title() ? headingId : null",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    @if (title() || description()) {
      <div class="header">
        @if (title()) {
          <h2 [id]="headingId">{{ title() }}</h2>
        }
        @if (description()) {
          <p>{{ description() }}</p>
        }
      </div>
    }
    <div class="rows"><ng-content /></div>
  `,
			styles: [":host{display:flex;flex-direction:column;gap:.625rem}.header{display:flex;flex-direction:column;gap:.125rem}h2,p{margin:0}h2{font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong)}p{color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small)}.rows{display:flex;flex-direction:column}:host([data-family=linux]) h2,:host([data-family=web]) h2{font-weight:700}:host([data-family=linux]) .rows,:host([data-family=web]) .rows{overflow:hidden;border-radius:var(--sn-radius-surface);background:var(--sn-color-surface-solid);box-shadow:var(--sn-shadow-card)}:host([data-family=windows]){gap:.5rem}:host([data-family=windows]) .rows{gap:.25rem}:host([data-skin=w10]) h2{font-size:var(--sn-font-size-title);font-weight:400}:host([data-skin=w10]) .rows{gap:.5rem}:host([data-family=macos]){gap:.375rem}:host([data-family=macos]) .header{padding-inline:.625rem}:host([data-family=macos]) .rows{overflow:hidden;border-radius:.75rem;border:1px solid var(--sn-color-glass-border);background:var(--sn-color-glass);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-skin=macc]) .rows{border-radius:var(--sn-radius-surface);box-shadow:none}:host([data-skin=qt]){gap:.75rem}:host([data-skin=qt]) .header{align-items:center;text-align:center}:host([data-skin=qt]) h2{font-size:calc(var(--sn-font-size) * 1.2);font-weight:var(--sn-font-weight-strong)}:host([data-skin=qt]) .rows{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);column-gap:.75rem;row-gap:.625rem;overflow:visible;border-radius:0;background:none;box-shadow:none}:host([data-skin=cros]){gap:.5rem}:host([data-skin=cros]) .header{padding-inline:1rem}:host([data-skin=cros]) h2{color:var(--sn-color-fg)}:host([data-skin=cros]) .rows{overflow:hidden;border-radius:var(--sn-radius-surface);background:var(--sn-color-surface)}@media(forced-colors:active){.rows{border:1px solid CanvasText}:host([data-skin=qt]) .rows{border:0}}\n"]
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}]
	}
});
var SnSettingsRow = class SnSettingsRow {
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	subtitle = input("", ...ngDevMode ? [{ debugName: "subtitle" }] : /* istanbul ignore next */ []);
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnSettingsRow,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnSettingsRow,
		isStandalone: true,
		selector: "sn-settings-row",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			subtitle: {
				classPropertyName: "subtitle",
				publicName: "subtitle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "sn-settings-row" },
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		ngImport: i0,
		template: `
    <ng-content select="[snSettingsIcon]" />
    <div class="text">
      <span class="title">{{ title() }}</span>
      @if (subtitle()) {
        <span class="subtitle">{{ subtitle() }}</span>
      }
    </div>
    <div class="control"><ng-content /></div>
  `,
		isInline: true,
		styles: [":host{display:flex;align-items:center;gap:.875rem}.text{display:flex;flex-direction:column;flex:1;min-width:0;gap:.0625rem}.subtitle{color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small)}.control{display:flex;align-items:center;gap:.5rem;flex:none}:host ::ng-deep [snSettingsIcon]{flex:none;font-size:1.25em;color:var(--sn-color-fg-muted)}:host([data-family=linux]),:host([data-family=web]){min-height:3.25rem;padding:.5rem .75rem}:host([data-family=linux]:not([data-skin=qt]):not(:first-child)),:host([data-family=web]:not(:first-child)){border-top:1px solid var(--sn-color-border)}:host([data-family=windows]){min-height:4rem;padding:.75rem 1rem;gap:1rem;border:1px solid var(--sn-color-stroke);border-radius:var(--sn-radius-surface);background:var(--sn-color-surface)}:host([data-family=windows]) ::ng-deep [snSettingsIcon]{color:var(--sn-color-fg)}:host([data-skin=w10]){flex-direction:column;align-items:flex-start;gap:.375rem;min-height:0;padding:0;border:0;background:none}:host([data-skin=w10]) ::ng-deep [snSettingsIcon]{display:none}:host([data-family=macos]){position:relative;min-height:2.25rem;padding:.375rem .625rem}:host([data-family=macos]:not(:first-child)):before{content:\"\";position:absolute;top:0;inset-inline:.625rem 0;height:1px;background:color-mix(in srgb,var(--sn-color-fg) 10%,transparent)}:host([data-skin=qt]){display:grid;grid-column:1/-1;grid-template-columns:subgrid;align-items:center;row-gap:.125rem;min-height:var(--sn-control-height);padding:0;border:0}:host([data-skin=qt]) .text{display:contents}:host([data-skin=qt]) .title{grid-column:1;grid-row:1;justify-self:end;text-align:end}:host([data-skin=qt]) .title:after{content:\":\"}:host([data-skin=qt]) .control{grid-column:2;grid-row:1;justify-self:start}:host([data-skin=qt]) .subtitle{grid-column:2;grid-row:2}:host([data-skin=qt]) ::ng-deep [snSettingsIcon]{display:none}:host([data-skin=cros]){min-height:3.5rem;padding:.5rem 1rem;gap:1rem}:host([data-skin=cros]) ::ng-deep [snSettingsIcon]{color:var(--sn-color-fg)}:host([data-skin=cros]:not(:first-child)){border-top:1px solid var(--sn-color-stroke)}@media(forced-colors:active){:host([data-family=windows]){border:1px solid CanvasText}:host([data-family=macos]:not(:first-child)):before{background:CanvasText}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnSettingsRow,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-settings-row",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-settings-row",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    <ng-content select="[snSettingsIcon]" />
    <div class="text">
      <span class="title">{{ title() }}</span>
      @if (subtitle()) {
        <span class="subtitle">{{ subtitle() }}</span>
      }
    </div>
    <div class="control"><ng-content /></div>
  `,
			styles: [":host{display:flex;align-items:center;gap:.875rem}.text{display:flex;flex-direction:column;flex:1;min-width:0;gap:.0625rem}.subtitle{color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small)}.control{display:flex;align-items:center;gap:.5rem;flex:none}:host ::ng-deep [snSettingsIcon]{flex:none;font-size:1.25em;color:var(--sn-color-fg-muted)}:host([data-family=linux]),:host([data-family=web]){min-height:3.25rem;padding:.5rem .75rem}:host([data-family=linux]:not([data-skin=qt]):not(:first-child)),:host([data-family=web]:not(:first-child)){border-top:1px solid var(--sn-color-border)}:host([data-family=windows]){min-height:4rem;padding:.75rem 1rem;gap:1rem;border:1px solid var(--sn-color-stroke);border-radius:var(--sn-radius-surface);background:var(--sn-color-surface)}:host([data-family=windows]) ::ng-deep [snSettingsIcon]{color:var(--sn-color-fg)}:host([data-skin=w10]){flex-direction:column;align-items:flex-start;gap:.375rem;min-height:0;padding:0;border:0;background:none}:host([data-skin=w10]) ::ng-deep [snSettingsIcon]{display:none}:host([data-family=macos]){position:relative;min-height:2.25rem;padding:.375rem .625rem}:host([data-family=macos]:not(:first-child)):before{content:\"\";position:absolute;top:0;inset-inline:.625rem 0;height:1px;background:color-mix(in srgb,var(--sn-color-fg) 10%,transparent)}:host([data-skin=qt]){display:grid;grid-column:1/-1;grid-template-columns:subgrid;align-items:center;row-gap:.125rem;min-height:var(--sn-control-height);padding:0;border:0}:host([data-skin=qt]) .text{display:contents}:host([data-skin=qt]) .title{grid-column:1;grid-row:1;justify-self:end;text-align:end}:host([data-skin=qt]) .title:after{content:\":\"}:host([data-skin=qt]) .control{grid-column:2;grid-row:1;justify-self:start}:host([data-skin=qt]) .subtitle{grid-column:2;grid-row:2}:host([data-skin=qt]) ::ng-deep [snSettingsIcon]{display:none}:host([data-skin=cros]){min-height:3.5rem;padding:.5rem 1rem;gap:1rem}:host([data-skin=cros]) ::ng-deep [snSettingsIcon]{color:var(--sn-color-fg)}:host([data-skin=cros]:not(:first-child)){border-top:1px solid var(--sn-color-stroke)}@media(forced-colors:active){:host([data-family=windows]){border:1px solid CanvasText}:host([data-family=macos]:not(:first-child)):before{background:CanvasText}}\n"]
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		subtitle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "subtitle",
				required: false
			}]
		}]
	}
});
var SnStatusPage = class SnStatusPage {
	icon = input("", ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	description = input("", ...ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []);
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnStatusPage,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnStatusPage,
		isStandalone: true,
		selector: "sn-status-page",
		inputs: {
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: {
				"data-slot": "sn-status-page",
				"role": "status"
			},
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		ngImport: i0,
		template: `
    @if (icon()) {
      <ng-icon class="icon" [name]="icon()" aria-hidden="true" />
    }
    <h2>{{ title() }}</h2>
    @if (description()) {
      <p>{{ description() }}</p>
    }
    <div class="actions"><ng-content /></div>
  `,
		isInline: true,
		styles: [":host{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.625rem;padding:2.25rem 1.5rem;text-align:center}h2,p{margin:0}p{max-width:34em;color:var(--sn-color-fg-muted)}.icon{flex:none}.actions{display:flex;flex-wrap:wrap;justify-content:center;gap:.5rem;margin-top:.5rem}.actions:empty{display:none}:host([data-family=linux]),:host([data-family=web]){gap:.75rem}:host([data-family=linux]) .icon,:host([data-family=web]) .icon{font-size:8rem;opacity:.55;margin-bottom:1.125rem}:host([data-family=linux]) h2,:host([data-family=web]) h2{font-size:2em;font-weight:800;line-height:1.2}:host([data-family=linux]) p,:host([data-family=web]) p{color:var(--sn-color-fg)}:host([data-family=linux]) .actions ::ng-deep [data-slot=button],:host([data-family=web]) .actions ::ng-deep [data-slot=button]{border-radius:var(--sn-radius-pill);padding-inline:2rem}:host([data-family=macos]){gap:.375rem}:host([data-family=macos]) .icon{font-size:3rem;color:var(--sn-color-fg-muted);margin-bottom:.625rem}:host([data-family=macos]) h2{font-size:calc(var(--sn-font-size) * 1.3);font-weight:700}:host([data-family=windows]){gap:.5rem}:host([data-family=windows]) .icon{box-sizing:content-box;font-size:2rem;padding:1rem;border-radius:50%;background:var(--sn-color-secondary);color:var(--sn-color-accent-text);margin-bottom:.375rem}:host([data-family=windows]) h2{font-size:var(--sn-font-size-title);font-weight:var(--sn-font-weight-strong)}:host([data-skin=qt]){gap:.5rem}:host([data-skin=qt]) .icon{font-size:4rem;color:var(--sn-color-fg-muted);opacity:.55;margin-bottom:.5rem}:host([data-skin=qt]) h2{font-size:1.1875rem;font-weight:var(--sn-font-weight-strong);line-height:1.3;color:var(--sn-color-fg-muted)}:host([data-skin=qt]) p{color:var(--sn-color-fg-muted)}:host([data-skin=qt]) .actions ::ng-deep [data-slot=button]{border-radius:var(--sn-radius-control);padding-inline:var(--sn-control-padding-x)}:host([data-skin=cros]){gap:.5rem}:host([data-skin=cros]) .icon{box-sizing:content-box;font-size:2.25rem;padding:1.125rem;border-radius:50%;background:var(--sn-color-glass-border);color:var(--sn-color-glass-highlight);margin-bottom:.5rem}:host([data-skin=cros]) h2{font-size:var(--sn-font-size-title);font-weight:400}\n"],
		dependencies: [{
			kind: "component",
			type: NgIcon,
			selector: "ng-icon",
			inputs: [
				"name",
				"svg",
				"size",
				"strokeWidth",
				"color"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnStatusPage,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-status-page",
			imports: [NgIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-status-page",
				role: "status",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    @if (icon()) {
      <ng-icon class="icon" [name]="icon()" aria-hidden="true" />
    }
    <h2>{{ title() }}</h2>
    @if (description()) {
      <p>{{ description() }}</p>
    }
    <div class="actions"><ng-content /></div>
  `,
			styles: [":host{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.625rem;padding:2.25rem 1.5rem;text-align:center}h2,p{margin:0}p{max-width:34em;color:var(--sn-color-fg-muted)}.icon{flex:none}.actions{display:flex;flex-wrap:wrap;justify-content:center;gap:.5rem;margin-top:.5rem}.actions:empty{display:none}:host([data-family=linux]),:host([data-family=web]){gap:.75rem}:host([data-family=linux]) .icon,:host([data-family=web]) .icon{font-size:8rem;opacity:.55;margin-bottom:1.125rem}:host([data-family=linux]) h2,:host([data-family=web]) h2{font-size:2em;font-weight:800;line-height:1.2}:host([data-family=linux]) p,:host([data-family=web]) p{color:var(--sn-color-fg)}:host([data-family=linux]) .actions ::ng-deep [data-slot=button],:host([data-family=web]) .actions ::ng-deep [data-slot=button]{border-radius:var(--sn-radius-pill);padding-inline:2rem}:host([data-family=macos]){gap:.375rem}:host([data-family=macos]) .icon{font-size:3rem;color:var(--sn-color-fg-muted);margin-bottom:.625rem}:host([data-family=macos]) h2{font-size:calc(var(--sn-font-size) * 1.3);font-weight:700}:host([data-family=windows]){gap:.5rem}:host([data-family=windows]) .icon{box-sizing:content-box;font-size:2rem;padding:1rem;border-radius:50%;background:var(--sn-color-secondary);color:var(--sn-color-accent-text);margin-bottom:.375rem}:host([data-family=windows]) h2{font-size:var(--sn-font-size-title);font-weight:var(--sn-font-weight-strong)}:host([data-skin=qt]){gap:.5rem}:host([data-skin=qt]) .icon{font-size:4rem;color:var(--sn-color-fg-muted);opacity:.55;margin-bottom:.5rem}:host([data-skin=qt]) h2{font-size:1.1875rem;font-weight:var(--sn-font-weight-strong);line-height:1.3;color:var(--sn-color-fg-muted)}:host([data-skin=qt]) p{color:var(--sn-color-fg-muted)}:host([data-skin=qt]) .actions ::ng-deep [data-slot=button]{border-radius:var(--sn-radius-control);padding-inline:var(--sn-control-padding-x)}:host([data-skin=cros]){gap:.5rem}:host([data-skin=cros]) .icon{box-sizing:content-box;font-size:2.25rem;padding:1.125rem;border-radius:50%;background:var(--sn-color-glass-border);color:var(--sn-color-glass-highlight);margin-bottom:.5rem}:host([data-skin=cros]) h2{font-size:var(--sn-font-size-title);font-weight:400}\n"]
		}]
	}],
	propDecorators: {
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}]
	}
});
const SHOW_DELAY = 600;
var SnTooltipPanel = class SnTooltipPanel {
	text = signal("", ...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnTooltipPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: SnTooltipPanel,
		isStandalone: true,
		selector: "sn-tooltip-panel",
		host: {
			attributes: {
				"data-slot": "sn-tooltip",
				"aria-hidden": "true"
			},
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()",
				"textContent": "text()"
			}
		},
		ngImport: i0,
		template: "",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnTooltipPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-tooltip-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-tooltip",
				"aria-hidden": "true",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()",
				"[textContent]": "text()"
			},
			template: ""
		}]
	}]
});
var SnTooltip = class SnTooltip {
	snTooltip = input("", ...ngDevMode ? [{ debugName: "snTooltip" }] : /* istanbul ignore next */ []);
	snTooltipDisabled = input(false, {
		...ngDevMode ? { debugName: "snTooltipDisabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	text = signal(null, ...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	shown = computed(() => this.snTooltipDisabled() ? "" : this.text() ?? this.snTooltip(), ...ngDevMode ? [{ debugName: "shown" }] : /* istanbul ignore next */ []);
	element = inject(ElementRef).nativeElement;
	injector = inject(Injector);
	modality = inject(InputModalityDetector);
	overlay = null;
	panel = null;
	timer = null;
	constructor() {
		effect(() => {
			const text = this.shown();
			if (this.panel) this.panel.text.set(text);
			if (!text) this.hide();
		});
		inject(DestroyRef).onDestroy(() => {
			this.hide();
			this.overlay?.dispose();
		});
	}
	onPointerEnter(event) {
		if (event.pointerType === "touch") return;
		this.schedule(SHOW_DELAY);
	}
	onFocus() {
		if (this.modality.mostRecentModality === "keyboard") this.schedule(0);
	}
	schedule(delay) {
		this.clearTimer();
		this.timer = setTimeout(() => this.show(), delay);
	}
	show() {
		this.clearTimer();
		const text = this.shown();
		if (!text || !this.element.isConnected) return;
		if (!this.overlay) this.overlay = createOverlayRef(this.injector, {
			positionStrategy: createFlexibleConnectedPositionStrategy(this.injector, this.element).withFlexibleDimensions(false).withViewportMargin(8).withPositions([{
				originX: "center",
				originY: "bottom",
				overlayX: "center",
				overlayY: "top",
				offsetY: 6
			}, {
				originX: "center",
				originY: "top",
				overlayX: "center",
				overlayY: "bottom",
				offsetY: -6
			}]),
			scrollStrategy: createRepositionScrollStrategy(this.injector),
			panelClass: "sn-tooltip-pane"
		});
		if (!this.overlay.hasAttached()) this.panel = this.overlay.attach(new ComponentPortal(SnTooltipPanel, null, this.injector)).instance;
		this.panel.text.set(text);
		this.overlay.updatePosition();
	}
	hide() {
		this.clearTimer();
		if (this.overlay?.hasAttached()) this.overlay.detach();
		this.panel = null;
	}
	clearTimer() {
		if (this.timer !== null) clearTimeout(this.timer);
		this.timer = null;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnTooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnTooltip,
		isStandalone: true,
		selector: "[snTooltip]",
		inputs: {
			snTooltip: {
				classPropertyName: "snTooltip",
				publicName: "snTooltip",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			snTooltipDisabled: {
				classPropertyName: "snTooltipDisabled",
				publicName: "snTooltipDisabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { listeners: {
			"pointerenter": "onPointerEnter($event)",
			"pointerleave": "hide()",
			"pointerdown": "hide()",
			"focusin": "onFocus()",
			"focusout": "hide()",
			"keydown.escape": "hide()"
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnTooltip,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[snTooltip]",
			host: {
				"(pointerenter)": "onPointerEnter($event)",
				"(pointerleave)": "hide()",
				"(pointerdown)": "hide()",
				"(focusin)": "onFocus()",
				"(focusout)": "hide()",
				"(keydown.escape)": "hide()"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		snTooltip: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "snTooltip",
				required: false
			}]
		}],
		snTooltipDisabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "snTooltipDisabled",
				required: false
			}]
		}]
	}
});
const MAC_ORDER = [
	"ctrl",
	"alt",
	"shift",
	"mod"
];
const PC_ORDER = [
	"mod",
	"ctrl",
	"alt",
	"shift"
];
const MAC = {
	mod: "⌘",
	ctrl: "⌃",
	alt: "⌥",
	shift: "⇧",
	enter: "↩",
	backspace: "⌫",
	delete: "⌦",
	escape: "⎋",
	tab: "⇥",
	space: "Space",
	up: "↑",
	down: "↓",
	left: "←",
	right: "→"
};
const PC = {
	mod: "Ctrl",
	ctrl: "Ctrl",
	alt: "Alt",
	shift: "Shift",
	enter: "Enter",
	backspace: "Backspace",
	delete: "Del",
	escape: "Esc",
	tab: "Tab",
	space: "Space",
	up: "↑",
	down: "↓",
	left: "←",
	right: "→"
};
function formatShortcut(shortcut, family) {
	const parts = shortcut.toLowerCase().split("+").map((p) => p.trim()).filter(Boolean);
	const mac = family === "macos";
	const order = mac ? MAC_ORDER : PC_ORDER;
	const names = mac ? MAC : PC;
	const modifiers = order.filter((m) => parts.includes(m));
	const keys = parts.filter((p) => !order.includes(p));
	const shown = mac ? modifiers : [...new Set(modifiers.map((m) => names[m]))];
	const key = keys.map((k) => names[k] ?? k.toUpperCase());
	return mac ? [...shown.map((m) => names[m]), ...key].join("") : [...shown, ...key].join("+");
}
var SnShortcut = class SnShortcut {
	shortcut = input.required({
		...ngDevMode ? { debugName: "shortcut" } : /* istanbul ignore next */ {},
		alias: "snShortcut"
	});
	skin = injectSkin();
	family = injectPlatformFamily();
	text = computed(() => formatShortcut(this.shortcut(), this.family()), ...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnShortcut,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnShortcut,
		isStandalone: true,
		selector: "[snShortcut]",
		inputs: { shortcut: {
			classPropertyName: "shortcut",
			publicName: "snShortcut",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			attributes: { "data-slot": "sn-shortcut" },
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()",
				"textContent": "text()",
				"attr.aria-label": "text()"
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnShortcut,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[snShortcut]",
			host: {
				"data-slot": "sn-shortcut",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()",
				"[textContent]": "text()",
				"[attr.aria-label]": "text()"
			}
		}]
	}],
	propDecorators: { shortcut: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "snShortcut",
			required: true
		}]
	}] }
});
var SnMenuTemplates = class SnMenuTemplates {
	family = input("windows", ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	beforeRun = input(null, ...ngDevMode ? [{ debugName: "beforeRun" }] : /* istanbul ignore next */ []);
	menu = viewChild.required("menu", ...ngDevMode ? [{ debugName: "menu" }] : /* istanbul ignore next */ []);
	submenuPosition = [{
		originX: "end",
		originY: "top",
		overlayX: "start",
		overlayY: "top",
		offsetY: -4
	}, {
		originX: "start",
		originY: "top",
		overlayX: "end",
		overlayY: "top",
		offsetY: -4
	}];
	shortcut(accelerator) {
		return formatShortcut(accelerator, this.family());
	}
	run(item) {
		if (item.enabled === false) return;
		this.beforeRun()?.();
		item.action?.();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnMenuTemplates,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnMenuTemplates,
		isStandalone: true,
		selector: "sn-menu-templates",
		inputs: {
			family: {
				classPropertyName: "family",
				publicName: "family",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			beforeRun: {
				classPropertyName: "beforeRun",
				publicName: "beforeRun",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { styleAttribute: "display: none" },
		viewQueries: [{
			propertyName: "menu",
			first: true,
			predicate: ["menu"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <ng-template #menu let-items>
      <div cdkMenu data-slot="dropdown-menu" class="sn-menu">
        @for (item of items; track $index) {
          @if (item.type === 'separator') {
            <div role="separator" data-slot="dropdown-menu-separator" class="sn-menu-separator"></div>
          } @else if (item.submenu) {
            <button
              type="button"
              cdkMenuItem
              data-slot="dropdown-menu-sub-trigger"
              class="sn-menu-item"
              [cdkMenuTriggerFor]="menu"
              [cdkMenuTriggerData]="{ $implicit: item.submenu }"
              [cdkMenuPosition]="submenuPosition"
              [cdkMenuItemDisabled]="item.enabled === false"
              [attr.data-disabled]="item.enabled === false ? '' : null"
            >
              <span class="sn-menu-check"></span>
              <span class="sn-menu-label">{{ item.label }}</span>
              <svg class="sn-menu-chevron" viewBox="0 0 16 16" aria-hidden="true"><path d="M6 4l4 4-4 4" /></svg>
            </button>
          } @else if (item.type === 'checkbox') {
            <button
              type="button"
              cdkMenuItemCheckbox
              data-slot="dropdown-menu-checkbox-item"
              class="sn-menu-item"
              [cdkMenuItemChecked]="!!item.checked"
              [attr.data-checked]="item.checked ? '' : null"
              [cdkMenuItemDisabled]="item.enabled === false"
              [attr.data-disabled]="item.enabled === false ? '' : null"
              (cdkMenuItemTriggered)="run(item)"
            >
              <span class="sn-menu-check">
                @if (item.checked) {
                  <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7" /></svg>
                }
              </span>
              <span class="sn-menu-label">{{ item.label }}</span>
              @if (item.accelerator) {
                <kbd data-slot="dropdown-menu-shortcut" class="sn-menu-shortcut">{{ shortcut(item.accelerator) }}</kbd>
              }
            </button>
          } @else if (item.type === 'radio') {
            <button
              type="button"
              cdkMenuItemRadio
              data-slot="dropdown-menu-radio-item"
              class="sn-menu-item"
              [cdkMenuItemChecked]="!!item.checked"
              [attr.data-checked]="item.checked ? '' : null"
              [cdkMenuItemDisabled]="item.enabled === false"
              [attr.data-disabled]="item.enabled === false ? '' : null"
              (cdkMenuItemTriggered)="run(item)"
            >
              <span class="sn-menu-check">
                @if (item.checked) {
                  <svg viewBox="0 0 16 16" aria-hidden="true"><circle class="dot" cx="8" cy="8" r="3" /></svg>
                }
              </span>
              <span class="sn-menu-label">{{ item.label }}</span>
              @if (item.accelerator) {
                <kbd data-slot="dropdown-menu-shortcut" class="sn-menu-shortcut">{{ shortcut(item.accelerator) }}</kbd>
              }
            </button>
          } @else {
            <button
              type="button"
              cdkMenuItem
              data-slot="dropdown-menu-item"
              class="sn-menu-item"
              [cdkMenuItemDisabled]="item.enabled === false"
              [attr.data-disabled]="item.enabled === false ? '' : null"
              (cdkMenuItemTriggered)="run(item)"
            >
              <span class="sn-menu-check"></span>
              <span class="sn-menu-label">{{ item.label }}</span>
              @if (item.accelerator) {
                <kbd data-slot="dropdown-menu-shortcut" class="sn-menu-shortcut">{{ shortcut(item.accelerator) }}</kbd>
              }
            </button>
          }
        }
      </div>
    </ng-template>
  `,
		isInline: true,
		styles: ["@layer spartan-native.base{.sn-menu{display:flex;flex-direction:column;min-inline-size:13rem;max-block-size:calc(100vh - 2rem);overflow-y:auto;box-sizing:border-box;font-family:var(--sn-font-sans);font-size:var(--sn-font-size);outline:none;cursor:default;-webkit-user-select:none;user-select:none}.sn-menu-item{box-sizing:border-box;margin:0;border:0;background:transparent;color:inherit;font:inherit;text-align:start;display:flex;align-items:center;gap:.5rem;inline-size:100%;white-space:nowrap;cursor:default}.sn-menu-item[data-disabled]{opacity:.45;pointer-events:none}.sn-menu-check{display:grid;place-items:center;flex:none;inline-size:1rem;block-size:1rem}.sn-menu-check svg{width:1rem;height:1rem;fill:none;stroke:currentColor;stroke-width:1.75;stroke-linecap:round;stroke-linejoin:round}.sn-menu-check .dot{fill:currentColor;stroke:none}.sn-menu-label{flex:1}.sn-menu-shortcut{margin-inline-start:2rem;font:inherit;font-size:var(--sn-font-size-small);color:var(--sn-color-fg-muted);letter-spacing:.02em}.sn-menu-chevron{width:.875rem;height:.875rem;margin-inline-start:2rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;opacity:.7}.sn-menu-separator{block-size:1px;margin-block:.25rem;background:var(--sn-color-border)}}@media(forced-colors:active){.sn-menu{border:1px solid CanvasText}.sn-menu-item:is(:hover,:focus){background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}.sn-menu-separator{background:CanvasText}}\n"],
		dependencies: [
			{
				kind: "directive",
				type: CdkMenu,
				selector: "[cdkMenu]",
				outputs: ["closed"],
				exportAs: ["cdkMenu"]
			},
			{
				kind: "directive",
				type: CdkMenuItem,
				selector: "[cdkMenuItem]",
				inputs: ["cdkMenuItemDisabled", "cdkMenuitemTypeaheadLabel"],
				outputs: ["cdkMenuItemTriggered"],
				exportAs: ["cdkMenuItem"]
			},
			{
				kind: "directive",
				type: CdkMenuItemCheckbox,
				selector: "[cdkMenuItemCheckbox]",
				exportAs: ["cdkMenuItemCheckbox"]
			},
			{
				kind: "directive",
				type: CdkMenuItemRadio,
				selector: "[cdkMenuItemRadio]",
				exportAs: ["cdkMenuItemRadio"]
			},
			{
				kind: "directive",
				type: CdkMenuTrigger,
				selector: "[cdkMenuTriggerFor]",
				inputs: [
					"cdkMenuTriggerFor",
					"cdkMenuPosition",
					"cdkMenuTriggerData",
					"cdkMenuTriggerTransformOriginOn"
				],
				outputs: ["cdkMenuOpened", "cdkMenuClosed"],
				exportAs: ["cdkMenuTriggerFor"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnMenuTemplates,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-menu-templates",
			imports: [
				CdkMenu,
				CdkMenuItem,
				CdkMenuItemCheckbox,
				CdkMenuItemRadio,
				CdkMenuTrigger
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { style: "display: none" },
			template: `
    <ng-template #menu let-items>
      <div cdkMenu data-slot="dropdown-menu" class="sn-menu">
        @for (item of items; track $index) {
          @if (item.type === 'separator') {
            <div role="separator" data-slot="dropdown-menu-separator" class="sn-menu-separator"></div>
          } @else if (item.submenu) {
            <button
              type="button"
              cdkMenuItem
              data-slot="dropdown-menu-sub-trigger"
              class="sn-menu-item"
              [cdkMenuTriggerFor]="menu"
              [cdkMenuTriggerData]="{ $implicit: item.submenu }"
              [cdkMenuPosition]="submenuPosition"
              [cdkMenuItemDisabled]="item.enabled === false"
              [attr.data-disabled]="item.enabled === false ? '' : null"
            >
              <span class="sn-menu-check"></span>
              <span class="sn-menu-label">{{ item.label }}</span>
              <svg class="sn-menu-chevron" viewBox="0 0 16 16" aria-hidden="true"><path d="M6 4l4 4-4 4" /></svg>
            </button>
          } @else if (item.type === 'checkbox') {
            <button
              type="button"
              cdkMenuItemCheckbox
              data-slot="dropdown-menu-checkbox-item"
              class="sn-menu-item"
              [cdkMenuItemChecked]="!!item.checked"
              [attr.data-checked]="item.checked ? '' : null"
              [cdkMenuItemDisabled]="item.enabled === false"
              [attr.data-disabled]="item.enabled === false ? '' : null"
              (cdkMenuItemTriggered)="run(item)"
            >
              <span class="sn-menu-check">
                @if (item.checked) {
                  <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7" /></svg>
                }
              </span>
              <span class="sn-menu-label">{{ item.label }}</span>
              @if (item.accelerator) {
                <kbd data-slot="dropdown-menu-shortcut" class="sn-menu-shortcut">{{ shortcut(item.accelerator) }}</kbd>
              }
            </button>
          } @else if (item.type === 'radio') {
            <button
              type="button"
              cdkMenuItemRadio
              data-slot="dropdown-menu-radio-item"
              class="sn-menu-item"
              [cdkMenuItemChecked]="!!item.checked"
              [attr.data-checked]="item.checked ? '' : null"
              [cdkMenuItemDisabled]="item.enabled === false"
              [attr.data-disabled]="item.enabled === false ? '' : null"
              (cdkMenuItemTriggered)="run(item)"
            >
              <span class="sn-menu-check">
                @if (item.checked) {
                  <svg viewBox="0 0 16 16" aria-hidden="true"><circle class="dot" cx="8" cy="8" r="3" /></svg>
                }
              </span>
              <span class="sn-menu-label">{{ item.label }}</span>
              @if (item.accelerator) {
                <kbd data-slot="dropdown-menu-shortcut" class="sn-menu-shortcut">{{ shortcut(item.accelerator) }}</kbd>
              }
            </button>
          } @else {
            <button
              type="button"
              cdkMenuItem
              data-slot="dropdown-menu-item"
              class="sn-menu-item"
              [cdkMenuItemDisabled]="item.enabled === false"
              [attr.data-disabled]="item.enabled === false ? '' : null"
              (cdkMenuItemTriggered)="run(item)"
            >
              <span class="sn-menu-check"></span>
              <span class="sn-menu-label">{{ item.label }}</span>
              @if (item.accelerator) {
                <kbd data-slot="dropdown-menu-shortcut" class="sn-menu-shortcut">{{ shortcut(item.accelerator) }}</kbd>
              }
            </button>
          }
        }
      </div>
    </ng-template>
  `,
			styles: ["@layer spartan-native.base{.sn-menu{display:flex;flex-direction:column;min-inline-size:13rem;max-block-size:calc(100vh - 2rem);overflow-y:auto;box-sizing:border-box;font-family:var(--sn-font-sans);font-size:var(--sn-font-size);outline:none;cursor:default;-webkit-user-select:none;user-select:none}.sn-menu-item{box-sizing:border-box;margin:0;border:0;background:transparent;color:inherit;font:inherit;text-align:start;display:flex;align-items:center;gap:.5rem;inline-size:100%;white-space:nowrap;cursor:default}.sn-menu-item[data-disabled]{opacity:.45;pointer-events:none}.sn-menu-check{display:grid;place-items:center;flex:none;inline-size:1rem;block-size:1rem}.sn-menu-check svg{width:1rem;height:1rem;fill:none;stroke:currentColor;stroke-width:1.75;stroke-linecap:round;stroke-linejoin:round}.sn-menu-check .dot{fill:currentColor;stroke:none}.sn-menu-label{flex:1}.sn-menu-shortcut{margin-inline-start:2rem;font:inherit;font-size:var(--sn-font-size-small);color:var(--sn-color-fg-muted);letter-spacing:.02em}.sn-menu-chevron{width:.875rem;height:.875rem;margin-inline-start:2rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;opacity:.7}.sn-menu-separator{block-size:1px;margin-block:.25rem;background:var(--sn-color-border)}}@media(forced-colors:active){.sn-menu{border:1px solid CanvasText}.sn-menu-item:is(:hover,:focus){background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}.sn-menu-separator{background:CanvasText}}\n"]
		}]
	}],
	propDecorators: {
		family: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "family",
				required: false
			}]
		}],
		beforeRun: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "beforeRun",
				required: false
			}]
		}],
		menu: [{
			type: i0.ViewChild,
			args: ["menu", { isSignal: true }]
		}]
	}
});
const LABELLED = [
	"win",
	"w10",
	"qt"
];
const SN_COMMAND_BAR = new InjectionToken("SnCommandBar");
var SnCommandOverflow = class SnCommandOverflow {
	template = inject(TemplateRef);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnCommandOverflow,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: SnCommandOverflow,
		isStandalone: true,
		selector: "ng-template[snCommandOverflow]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnCommandOverflow,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[snCommandOverflow]" }]
	}]
});
var SnCommandGroup = class SnCommandGroup {
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnCommandGroup,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnCommandGroup,
		isStandalone: true,
		selector: "sn-command-group",
		inputs: { label: {
			classPropertyName: "label",
			publicName: "label",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: {
				"data-slot": "sn-command-group",
				"role": "group"
			},
			properties: { "attr.aria-label": "label() || null" }
		},
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnCommandGroup,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-command-group",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-command-group",
				role: "group",
				"[attr.aria-label]": "label() || null"
			},
			template: "<ng-content />"
		}]
	}],
	propDecorators: { label: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "label",
			required: false
		}]
	}] }
});
var SnCommand = class SnCommand {
	icon = input("", ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	isDisabled = input(false, {
		...ngDevMode ? { debugName: "isDisabled" } : /* istanbul ignore next */ {},
		alias: "disabled",
		transform: booleanAttribute
	});
	hideLabel = input(false, {
		...ngDevMode ? { debugName: "hideLabel" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	variant = input("default", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	priority = input(0, {
		...ngDevMode ? { debugName: "priority" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	secondary = input(false, {
		...ngDevMode ? { debugName: "secondary" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	tabbable = signal(true, ...ngDevMode ? [{ debugName: "tabbable" }] : /* istanbul ignore next */ []);
	collapsed = signal(false, ...ngDevMode ? [{ debugName: "collapsed" }] : /* istanbul ignore next */ []);
	element = inject(ElementRef).nativeElement;
	bar = inject(SN_COMMAND_BAR, { optional: true });
	iconOnly = computed(() => this.hideLabel() || !!this.bar?.iconOnly() || !!this.bar?.compact(), ...ngDevMode ? [{ debugName: "iconOnly" }] : /* istanbul ignore next */ []);
	constructor() {
		const tooltip = inject(SnTooltip, { self: true });
		effect(() => tooltip.text.set(this.iconOnly() ? this.label() : ""));
		if (this.bar) {
			this.bar.register(this);
			inject(DestroyRef).onDestroy(() => this.bar.unregister(this));
		}
	}
	get disabled() {
		return this.isDisabled() || this.collapsed();
	}
	focus() {
		this.element.focus();
	}
	setCollapsed(collapsed) {
		this.element.toggleAttribute("data-collapsed", collapsed);
		this.collapsed.set(collapsed);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnCommand,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnCommand,
		isStandalone: true,
		selector: "button[snCommand]",
		inputs: {
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			isDisabled: {
				classPropertyName: "isDisabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			priority: {
				classPropertyName: "priority",
				publicName: "priority",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			secondary: {
				classPropertyName: "secondary",
				publicName: "secondary",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: {
				"data-slot": "sn-command",
				"type": "button"
			},
			properties: {
				"attr.tabindex": "tabbable() ? 0 : -1",
				"disabled": "isDisabled()",
				"attr.data-icon-only": "iconOnly() ? \"\" : null",
				"attr.data-variant": "variant() === \"accent\" ? \"accent\" : null"
			}
		},
		hostDirectives: [{ directive: SnTooltip }],
		ngImport: i0,
		template: `
    @if (icon()) {
      <ng-icon [name]="icon()" aria-hidden="true" />
    }
    <ng-content />
    <span class="label">{{ label() }}</span>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NgIcon,
			selector: "ng-icon",
			inputs: [
				"name",
				"svg",
				"size",
				"strokeWidth",
				"color"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnCommand,
	decorators: [{
		type: Component,
		args: [{
			selector: "button[snCommand]",
			imports: [NgIcon],
			hostDirectives: [SnTooltip],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-command",
				type: "button",
				"[attr.tabindex]": "tabbable() ? 0 : -1",
				"[disabled]": "isDisabled()",
				"[attr.data-icon-only]": "iconOnly() ? \"\" : null",
				"[attr.data-variant]": "variant() === \"accent\" ? \"accent\" : null"
			},
			template: `
    @if (icon()) {
      <ng-icon [name]="icon()" aria-hidden="true" />
    }
    <ng-content />
    <span class="label">{{ label() }}</span>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		isDisabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		priority: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "priority",
				required: false
			}]
		}],
		secondary: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "secondary",
				required: false
			}]
		}]
	}
});
var SnCommandBar = class SnCommandBar {
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	titlePosition = input("auto", ...ngDevMode ? [{ debugName: "titlePosition" }] : /* istanbul ignore next */ []);
	headingLevel = input(1, {
		...ngDevMode ? { debugName: "headingLevel" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	ariaLabel = input("", ...ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	overflowLabel = input("More options", ...ngDevMode ? [{ debugName: "overflowLabel" }] : /* istanbul ignore next */ []);
	commands = input(null, ...ngDevMode ? [{ debugName: "commands" }] : /* istanbul ignore next */ []);
	overflowItems = input([], ...ngDevMode ? [{ debugName: "overflowItems" }] : /* istanbul ignore next */ []);
	collapse = input("auto", ...ngDevMode ? [{ debugName: "collapse" }] : /* istanbul ignore next */ []);
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	platform = injectPlatformFamily();
	iconOnly = computed(() => !LABELLED.includes(this.skin()), ...ngDevMode ? [{ debugName: "iconOnly" }] : /* istanbul ignore next */ []);
	compact = signal(false, ...ngDevMode ? [{ debugName: "compact" }] : /* istanbul ignore next */ []);
	resolvedTitlePosition = computed(() => {
		const position = this.titlePosition();
		if (position !== "auto") return position;
		return this.skin() === "gtk" || this.family() === "web" ? "center" : "start";
	}, ...ngDevMode ? [{ debugName: "resolvedTitlePosition" }] : /* istanbul ignore next */ []);
	commandsLead = computed(() => this.skin() === "gtk" || this.family() === "web", ...ngDevMode ? [{ debugName: "commandsLead" }] : /* istanbul ignore next */ []);
	moreGlyph = computed(() => {
		const skin = this.skin();
		return skin === "cros" ? "vertical" : skin === "gtk" || skin === "qt" || this.family() === "web" ? "menu" : "dots";
	}, ...ngDevMode ? [{ debugName: "moreGlyph" }] : /* istanbul ignore next */ []);
	overflow = contentChild(SnCommandOverflow, ...ngDevMode ? [{ debugName: "overflow" }] : /* istanbul ignore next */ []);
	menuPosition = [{
		originX: "end",
		originY: "bottom",
		overlayX: "end",
		overlayY: "top",
		offsetY: 4
	}, {
		originX: "end",
		originY: "top",
		overlayX: "end",
		overlayY: "bottom",
		offsetY: -4
	}];
	commandInjector = Injector.create({
		providers: [{
			provide: SN_COMMAND_BAR,
			useValue: this
		}],
		parent: inject(Injector)
	});
	host = inject(ElementRef).nativeElement;
	titleEl = viewChild("titleEl", ...ngDevMode ? [{ debugName: "titleEl" }] : /* istanbul ignore next */ []);
	more = viewChild.required(SnCommand, ...ngDevMode ? [{ debugName: "more" }] : /* istanbul ignore next */ []);
	registered = signal([], ...ngDevMode ? [{ debugName: "registered" }] : /* istanbul ignore next */ []);
	ordered = signal([], ...ngDevMode ? [{ debugName: "ordered" }] : /* istanbul ignore next */ []);
	collapsedCommands = signal([], ...ngDevMode ? [{ debugName: "collapsedCommands" }] : /* istanbul ignore next */ []);
	menuItems = computed(() => {
		const commands = this.collapsedCommands().map((c) => ({
			label: c.label(),
			enabled: !c.isDisabled(),
			action: () => c.element.click()
		}));
		const extra = this.overflowItems();
		return commands.length && extra.length ? [
			...commands,
			{ type: "separator" },
			...extra
		] : [...commands, ...extra];
	}, ...ngDevMode ? [{ debugName: "menuItems" }] : /* istanbul ignore next */ []);
	items = this.ordered;
	rendered = false;
	fitted = signal(0, ...ngDevMode ? [{ debugName: "fitted" }] : /* istanbul ignore next */ []);
	active = signal(null, ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	keys = new FocusKeyManager(this.items, inject(Injector)).withHorizontalOrientation(inject(Directionality, { optional: true })?.value ?? "ltr").withVerticalOrientation(false).withHomeAndEnd().withWrap();
	constructor() {
		this.keys.change.subscribe(() => this.active.set(this.keys.activeItem));
		effect(() => {
			const items = this.items();
			const active = this.active();
			this.fitted();
			const visible = (i) => !i.disabled && !i.element.hidden;
			const stop = active && items.includes(active) && visible(active) ? active : items.find(visible);
			for (const item of items) item.tabbable.set(item === stop);
		});
		afterRenderEffect(() => {
			const sorted = [...this.registered()].sort((a, b) => a.element.compareDocumentPosition(b.element) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1);
			const current = untracked(this.ordered);
			if (sorted.length !== current.length || sorted.some((c, i) => c !== current[i])) this.ordered.set(sorted);
		});
		afterRenderEffect(() => {
			this.ordered();
			this.title();
			this.skin();
			this.collapse();
			this.overflowItems();
			this.overflow();
			for (const c of this.ordered()) {
				if (c === untracked(this.more)) continue;
				c.label();
				c.priority();
				c.secondary();
				c.icon();
			}
			untracked(() => {
				this.rendered = true;
				this.fit();
			});
		});
		if (typeof ResizeObserver !== "undefined") {
			let width = -1;
			const observer = new ResizeObserver(([entry]) => {
				const next = Math.round(entry.contentRect.width);
				if (next === width) return;
				width = next;
				this.fit();
			});
			observer.observe(this.host);
			inject(DestroyRef).onDestroy(() => observer.disconnect());
		}
		const fonts = this.host.ownerDocument.fonts;
		if (fonts?.addEventListener) {
			const refit = () => this.fit();
			fonts.ready.then(refit);
			fonts.addEventListener("loadingdone", refit);
			inject(DestroyRef).onDestroy(() => fonts.removeEventListener("loadingdone", refit));
		}
		inject(DestroyRef).onDestroy(() => this.rendered = false);
	}
	register(command) {
		this.registered.update((list) => [...list, command]);
	}
	unregister(command) {
		this.registered.update((list) => list.filter((c) => c !== command));
	}
	fit() {
		if (!this.rendered) return;
		const moreCommand = this.more();
		const more = moreCommand.element;
		const commands = this.ordered().filter((c) => c !== moreCommand);
		const title = this.titleEl()?.nativeElement;
		const auto = this.collapse() === "auto";
		for (const c of commands) c.setCollapsed(c.secondary());
		this.host.removeAttribute("data-compact");
		let compact = false;
		const showMore = () => {
			const collapsed = commands.some((c) => c.collapsed());
			more.hidden = !(collapsed || this.overflowItems().length || this.overflow());
		};
		showMore();
		const overflowing = () => this.host.scrollWidth > this.host.clientWidth + 1 || !!title && title.scrollWidth > title.clientWidth + 1;
		if (auto && overflowing()) {
			if (!this.iconOnly() && commands.some((c) => c.icon() || c.element.querySelector("svg, ng-icon, img"))) {
				compact = true;
				this.host.setAttribute("data-compact", "");
			}
			const queue = commands.map((command, index) => ({
				command,
				index
			})).filter(({ command }) => !command.secondary()).sort((a, b) => a.command.priority() - b.command.priority() || b.index - a.index);
			for (const { command } of queue) {
				if (!overflowing()) break;
				command.setCollapsed(true);
				showMore();
			}
		}
		this.compact.set(compact);
		this.fitted.update((n) => n + 1);
		this.collapsedCommands.set(commands.filter((c) => c.collapsed()));
		if (isDevMode() && this.overflow() && this.menuItems().length) console.warn("sn-command-bar: commands are in the overflow menu, so the snCommandOverflow template is not shown. Use secondary commands or overflowItems instead.");
	}
	onKeydown(event) {
		if (!this.items().some((i) => i.element === event.target)) return;
		this.keys.onKeydown(event);
	}
	onFocusin(event) {
		const item = this.items().find((i) => i.element === event.target);
		if (item) {
			this.keys.updateActiveItem(item);
			this.active.set(item);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnCommandBar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnCommandBar,
		isStandalone: true,
		selector: "sn-command-bar",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			titlePosition: {
				classPropertyName: "titlePosition",
				publicName: "titlePosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			headingLevel: {
				classPropertyName: "headingLevel",
				publicName: "headingLevel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ariaLabel: {
				classPropertyName: "ariaLabel",
				publicName: "ariaLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			overflowLabel: {
				classPropertyName: "overflowLabel",
				publicName: "overflowLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			commands: {
				classPropertyName: "commands",
				publicName: "commands",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			overflowItems: {
				classPropertyName: "overflowItems",
				publicName: "overflowItems",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			collapse: {
				classPropertyName: "collapse",
				publicName: "collapse",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "sn-command-bar" },
			listeners: {
				"keydown": "onKeydown($event)",
				"focusin": "onFocusin($event)"
			},
			properties: {
				"attr.title": "null",
				"attr.data-family": "family()",
				"attr.data-skin": "skin()",
				"attr.data-title": "resolvedTitlePosition()"
			},
			classAttribute: "sn-chrome"
		},
		providers: [{
			provide: SN_COMMAND_BAR,
			useExisting: SnCommandBar
		}],
		queries: [{
			propertyName: "overflow",
			first: true,
			predicate: SnCommandOverflow,
			descendants: true,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "titleEl",
			first: true,
			predicate: ["titleEl"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "more",
			first: true,
			predicate: SnCommand,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div class="lead">
      <ng-content select="[snCommandBarStart]" />
      @if (commandsLead()) {
        <ng-container [ngTemplateOutlet]="toolbar" />
      }
    </div>
    @if (title()) {
      <span #titleEl class="title" [attr.role]="headingLevel() ? 'heading' : null" [attr.aria-level]="headingLevel() || null">{{ title() }}</span>
    }
    <div class="trail">
      <div class="cluster">
        @if (!commandsLead()) {
          <ng-container [ngTemplateOutlet]="toolbar" />
        }
        <button
          snCommand
          hideLabel
          class="more"
          [label]="overflowLabel()"
          [cdkMenuTriggerFor]="menuItems().length ? menus.menu() : (overflow()?.template ?? null)"
          [cdkMenuTriggerData]="{ $implicit: menuItems() }"
          [cdkMenuPosition]="menuPosition"
        >
          @switch (moreGlyph()) {
            @case ('menu') {
              <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M2.5 4h11M2.5 8h11M2.5 12h11" /></svg>
            }
            @case ('vertical') {
              <svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="3" r="1.4" /><circle cx="8" cy="8" r="1.4" /><circle cx="8" cy="13" r="1.4" /></svg>
            }
            @default {
              <svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="3" cy="8" r="1.3" /><circle cx="8" cy="8" r="1.3" /><circle cx="13" cy="8" r="1.3" /></svg>
            }
          }
        </button>
      </div>
      <ng-content select="[snCommandBarEnd]" />
    </div>
    <ng-template #toolbar>
      <div class="commands" role="toolbar" [attr.aria-label]="ariaLabel() || title() || null">
        <ng-content />
        @if (commands(); as extra) {
          <ng-container [ngTemplateOutlet]="extra" [ngTemplateOutletInjector]="commandInjector" />
        }
      </div>
    </ng-template>
    <sn-menu-templates #menus [family]="platform()" />
  `,
		isInline: true,
		styles: [":host{display:flex;align-items:center;gap:.5rem;position:relative;flex:none;min-width:0;-webkit-user-select:none;user-select:none}.lead,.trail,.cluster{display:flex;align-items:center;gap:.5rem}.lead{flex:none}.trail{flex:1 1 auto;justify-content:flex-end}.title{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host([data-title=center]) .lead,:host([data-title=center]) .trail{flex:1 1 0}:host([data-title=center]) .title{text-align:center}.commands{display:flex;align-items:center;gap:.25rem;min-width:0}:host ::ng-deep [data-slot=sn-command-group]{display:flex;align-items:center;gap:inherit}:host ::ng-deep [data-slot=sn-command-group]:not(:has(>[data-slot=sn-command]:not([data-collapsed]))){display:none}:host(:is([data-family=windows],[data-family=linux],[data-family=web])) ::ng-deep .commands>[data-slot=sn-command-group]:not(:first-child):before,:host(:is([data-family=windows],[data-family=linux],[data-family=web])) ::ng-deep .commands>[data-slot=sn-command-group]:not(:last-child):not(:has(+[data-slot=sn-command-group])):after{content:\"\";align-self:stretch;width:1px;margin-block:.375rem;background:var(--sn-color-border)}:host([data-family=chromeos]) ::ng-deep .commands>[data-slot=sn-command-group]+*{margin-inline-start:.5rem}:host ::ng-deep [data-slot=sn-command]{all:unset;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:.5rem;flex:none;min-height:var(--sn-control-height);padding-inline:.625rem;border:1px solid transparent;border-radius:var(--sn-radius-control);color:var(--sn-color-fg);font:inherit;font-weight:var(--sn-font-weight-control);white-space:nowrap;cursor:default;transition:background-color var(--sn-duration-fast) var(--sn-easing),border-color var(--sn-duration-fast) var(--sn-easing)}:host ::ng-deep [data-slot=sn-command]:hover:not(:disabled),:host ::ng-deep [data-slot=sn-command][aria-expanded=true]{background:var(--sn-color-hover)}:host ::ng-deep [data-slot=sn-command]:active:not(:disabled){background:color-mix(in srgb,var(--sn-color-fg) 12%,transparent)}:host ::ng-deep [data-slot=sn-command]:focus-visible{outline:var(--sn-focus-outline);outline-offset:var(--sn-focus-offset)}:host ::ng-deep [data-slot=sn-command]:disabled{opacity:.4}:host ::ng-deep [data-slot=sn-command]>:is(ng-icon,svg){flex:none;width:1.125rem;height:1.125rem;font-size:1.125rem}:host ::ng-deep [data-slot=sn-command]>svg{fill:currentColor}:host ::ng-deep [data-slot=sn-command]>svg path{fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}:host ::ng-deep [data-slot=sn-command][data-icon-only]:has(>:is(ng-icon,svg,img)){padding-inline:0;aspect-ratio:1}:host ::ng-deep [data-slot=sn-command][data-icon-only]:has(>:is(ng-icon,svg,img)) .label{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}:host ::ng-deep [data-slot=sn-command][data-collapsed]{display:none!important}:host([data-compact]) ::ng-deep [data-slot=sn-command]:has(>:is(ng-icon,svg,img)){flex-direction:row;min-width:0;padding-inline:0;aspect-ratio:1}:host([data-compact]) ::ng-deep [data-slot=sn-command]:has(>:is(ng-icon,svg,img)) .label{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}:host ::ng-deep [data-slot=sn-command][data-variant=accent]{background:var(--sn-color-primary);border-color:var(--sn-color-primary-edge, transparent);color:var(--sn-color-primary-fg)}:host ::ng-deep [data-slot=sn-command][data-variant=accent]:hover:not(:disabled),:host ::ng-deep [data-slot=sn-command][data-variant=accent][aria-expanded=true]{background:color-mix(in srgb,var(--sn-color-primary) 90%,var(--sn-color-fg))}:host ::ng-deep [data-slot=sn-command][data-variant=accent]:active:not(:disabled){background:color-mix(in srgb,var(--sn-color-primary) 80%,var(--sn-color-fg))}:host([data-family=windows]){min-height:3rem;padding-inline:1rem .5rem}:host([data-family=windows]) .title{font-size:calc(var(--sn-font-size) * 1.43);font-weight:var(--sn-font-weight-strong)}:host([data-family=windows]) ::ng-deep [data-slot=sn-command]{min-height:2.25rem;font-weight:400}:host([data-family=windows]) ::ng-deep [data-slot=sn-command]>:is(ng-icon,svg){width:1rem;height:1rem;font-size:1rem}:host([data-skin=w10]) ::ng-deep [data-slot=sn-command]{flex-direction:column;gap:.25rem;min-width:4.25rem;min-height:3.5rem;padding:.375rem .5rem;border-radius:0;font-size:var(--sn-font-size-small)}:host([data-family=macos]){min-height:3.25rem;padding-inline:1rem .75rem}:host([data-family=macos]) .title{font-size:calc(var(--sn-font-size) * 1.15);font-weight:700}:host([data-family=macos]) .commands,:host([data-family=macos]) .cluster{gap:.5rem}:host([data-family=macos]) ::ng-deep [data-slot=sn-command]{min-height:2.25rem;color:var(--sn-color-fg)}:host([data-family=macos]) ::ng-deep [data-slot=sn-command]>:is(ng-icon,svg){width:1rem;height:1rem;font-size:1rem}:host([data-skin=mac]) .cluster:not(:has([data-slot=sn-command-group])):has([data-slot=sn-command]:not([data-collapsed],[hidden])){padding:.125rem;border-radius:var(--sn-radius-pill);background:var(--sn-color-glass);border:1px solid var(--sn-color-glass-border);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight),var(--sn-shadow-card);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));gap:0}:host([data-skin=mac]) .cluster:not(:has([data-slot=sn-command-group])):has([data-slot=sn-command]:not([data-collapsed],[hidden])) .commands{gap:0}:host([data-skin=mac]) .cluster:has([data-slot=sn-command-group]) .more:not([hidden]),:host([data-skin=mac]) .cluster:has([data-slot=sn-command-group]) ::ng-deep :is([data-slot=sn-command-group],.commands>[data-slot=sn-command]:not([data-variant=accent])){padding:.125rem;border-radius:var(--sn-radius-pill);background:var(--sn-color-glass);border:1px solid var(--sn-color-glass-border);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight),var(--sn-shadow-card);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));gap:0}:host([data-skin=mac]) ::ng-deep [data-slot=sn-command]{border-radius:var(--sn-radius-pill);min-width:2.25rem}:host([data-skin=macc]){min-height:3.25rem}:host([data-skin=macc]) ::ng-deep [data-slot=sn-command]{min-height:1.75rem;min-width:2rem;aspect-ratio:auto;padding-inline:.375rem;color:var(--sn-color-fg-muted)}:host([data-family=linux]),:host([data-family=web]){min-height:2.875rem;padding-inline:.375rem;background:var(--sn-color-bg);box-shadow:inset 0 -1px 0 var(--sn-color-border)}:host([data-family=linux]) .title,:host([data-family=web]) .title{font-weight:700}:host([data-family=linux]) .commands,:host([data-family=web]) .commands{gap:.375rem}:host([data-family=linux]) ::ng-deep [data-slot=sn-command],:host([data-family=web]) ::ng-deep [data-slot=sn-command]{min-height:2.125rem;min-width:2.125rem;font-weight:700}:host([data-skin=qt]){min-height:2.75rem;padding-inline:.75rem .375rem;gap:.75rem}:host([data-skin=qt]) .trail{justify-content:flex-start}:host([data-skin=qt]) .cluster{flex:1}:host([data-skin=qt]) .more{margin-inline-start:auto}:host([data-skin=qt]) .title{font-size:calc(var(--sn-font-size) * 1.15);font-weight:400;padding-inline-end:.75rem;border-inline-end:1px solid var(--sn-color-border)}:host([data-skin=qt]) .commands{gap:.125rem}:host([data-skin=qt]) ::ng-deep [data-slot=sn-command]{min-height:2rem;padding-inline:.375rem .5rem;gap:.375rem;font-weight:400}:host([data-skin=qt]) ::ng-deep [data-slot=sn-command]>:is(ng-icon,svg){width:1.375rem;height:1.375rem;font-size:1.375rem}:host([data-skin=qt]) ::ng-deep [data-slot=sn-command]:hover:not(:disabled),:host([data-skin=qt]) ::ng-deep [data-slot=sn-command][aria-expanded=true]{border-color:var(--sn-color-primary);background:color-mix(in srgb,var(--sn-color-primary) 15%,transparent)}:host([data-family=chromeos]){min-height:4rem;padding-inline:1rem .25rem;background:var(--sn-color-bg)}:host([data-family=chromeos]) .title{font-size:var(--sn-font-size-title);font-weight:400}:host([data-family=chromeos]) .commands,:host([data-family=chromeos]) .cluster{gap:0}:host([data-family=chromeos]) ::ng-deep [data-slot=sn-command]{min-height:3rem;min-width:3rem;border:0;border-radius:var(--sn-radius-pill);color:var(--sn-color-fg-muted)}:host([data-family=chromeos]) ::ng-deep [data-slot=sn-command]>:is(ng-icon,svg){width:1.5rem;height:1.5rem;font-size:1.5rem}:host([data-family=chromeos]) ::ng-deep [data-slot=sn-command]:hover:not(:disabled),:host([data-family=chromeos]) ::ng-deep [data-slot=sn-command][aria-expanded=true]{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}:host([data-family=chromeos]) ::ng-deep [data-slot=sn-command]:active:not(:disabled){background:color-mix(in srgb,var(--sn-color-fg) 12%,transparent)}@media(forced-colors:active){:host{border-bottom:1px solid CanvasText}:host ::ng-deep [data-slot=sn-command]{color:ButtonText!important}:host ::ng-deep [data-slot=sn-command]:hover:not(:disabled),:host ::ng-deep [data-slot=sn-command][aria-expanded=true]{background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host ::ng-deep [data-slot=sn-command]:disabled{color:GrayText!important;opacity:1}:host([data-skin=mac]) :is(.cluster,[data-slot=sn-command-group]){border-color:CanvasText}}\n"],
		dependencies: [
			{
				kind: "directive",
				type: CdkMenuTrigger,
				selector: "[cdkMenuTriggerFor]",
				inputs: [
					"cdkMenuTriggerFor",
					"cdkMenuPosition",
					"cdkMenuTriggerData",
					"cdkMenuTriggerTransformOriginOn"
				],
				outputs: ["cdkMenuOpened", "cdkMenuClosed"],
				exportAs: ["cdkMenuTriggerFor"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "component",
				type: SnCommand,
				selector: "button[snCommand]",
				inputs: [
					"icon",
					"label",
					"disabled",
					"hideLabel",
					"variant",
					"priority",
					"secondary"
				]
			},
			{
				kind: "component",
				type: SnMenuTemplates,
				selector: "sn-menu-templates",
				inputs: ["family", "beforeRun"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnCommandBar,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-command-bar",
			imports: [
				CdkMenuTrigger,
				NgTemplateOutlet,
				SnCommand,
				SnMenuTemplates
			],
			providers: [{
				provide: SN_COMMAND_BAR,
				useExisting: SnCommandBar
			}],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-command-bar",
				class: "sn-chrome",
				"[attr.title]": "null",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()",
				"[attr.data-title]": "resolvedTitlePosition()",
				"(keydown)": "onKeydown($event)",
				"(focusin)": "onFocusin($event)"
			},
			template: `
    <div class="lead">
      <ng-content select="[snCommandBarStart]" />
      @if (commandsLead()) {
        <ng-container [ngTemplateOutlet]="toolbar" />
      }
    </div>
    @if (title()) {
      <span #titleEl class="title" [attr.role]="headingLevel() ? 'heading' : null" [attr.aria-level]="headingLevel() || null">{{ title() }}</span>
    }
    <div class="trail">
      <div class="cluster">
        @if (!commandsLead()) {
          <ng-container [ngTemplateOutlet]="toolbar" />
        }
        <button
          snCommand
          hideLabel
          class="more"
          [label]="overflowLabel()"
          [cdkMenuTriggerFor]="menuItems().length ? menus.menu() : (overflow()?.template ?? null)"
          [cdkMenuTriggerData]="{ $implicit: menuItems() }"
          [cdkMenuPosition]="menuPosition"
        >
          @switch (moreGlyph()) {
            @case ('menu') {
              <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M2.5 4h11M2.5 8h11M2.5 12h11" /></svg>
            }
            @case ('vertical') {
              <svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="3" r="1.4" /><circle cx="8" cy="8" r="1.4" /><circle cx="8" cy="13" r="1.4" /></svg>
            }
            @default {
              <svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="3" cy="8" r="1.3" /><circle cx="8" cy="8" r="1.3" /><circle cx="13" cy="8" r="1.3" /></svg>
            }
          }
        </button>
      </div>
      <ng-content select="[snCommandBarEnd]" />
    </div>
    <ng-template #toolbar>
      <div class="commands" role="toolbar" [attr.aria-label]="ariaLabel() || title() || null">
        <ng-content />
        @if (commands(); as extra) {
          <ng-container [ngTemplateOutlet]="extra" [ngTemplateOutletInjector]="commandInjector" />
        }
      </div>
    </ng-template>
    <sn-menu-templates #menus [family]="platform()" />
  `,
			styles: [":host{display:flex;align-items:center;gap:.5rem;position:relative;flex:none;min-width:0;-webkit-user-select:none;user-select:none}.lead,.trail,.cluster{display:flex;align-items:center;gap:.5rem}.lead{flex:none}.trail{flex:1 1 auto;justify-content:flex-end}.title{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host([data-title=center]) .lead,:host([data-title=center]) .trail{flex:1 1 0}:host([data-title=center]) .title{text-align:center}.commands{display:flex;align-items:center;gap:.25rem;min-width:0}:host ::ng-deep [data-slot=sn-command-group]{display:flex;align-items:center;gap:inherit}:host ::ng-deep [data-slot=sn-command-group]:not(:has(>[data-slot=sn-command]:not([data-collapsed]))){display:none}:host(:is([data-family=windows],[data-family=linux],[data-family=web])) ::ng-deep .commands>[data-slot=sn-command-group]:not(:first-child):before,:host(:is([data-family=windows],[data-family=linux],[data-family=web])) ::ng-deep .commands>[data-slot=sn-command-group]:not(:last-child):not(:has(+[data-slot=sn-command-group])):after{content:\"\";align-self:stretch;width:1px;margin-block:.375rem;background:var(--sn-color-border)}:host([data-family=chromeos]) ::ng-deep .commands>[data-slot=sn-command-group]+*{margin-inline-start:.5rem}:host ::ng-deep [data-slot=sn-command]{all:unset;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:.5rem;flex:none;min-height:var(--sn-control-height);padding-inline:.625rem;border:1px solid transparent;border-radius:var(--sn-radius-control);color:var(--sn-color-fg);font:inherit;font-weight:var(--sn-font-weight-control);white-space:nowrap;cursor:default;transition:background-color var(--sn-duration-fast) var(--sn-easing),border-color var(--sn-duration-fast) var(--sn-easing)}:host ::ng-deep [data-slot=sn-command]:hover:not(:disabled),:host ::ng-deep [data-slot=sn-command][aria-expanded=true]{background:var(--sn-color-hover)}:host ::ng-deep [data-slot=sn-command]:active:not(:disabled){background:color-mix(in srgb,var(--sn-color-fg) 12%,transparent)}:host ::ng-deep [data-slot=sn-command]:focus-visible{outline:var(--sn-focus-outline);outline-offset:var(--sn-focus-offset)}:host ::ng-deep [data-slot=sn-command]:disabled{opacity:.4}:host ::ng-deep [data-slot=sn-command]>:is(ng-icon,svg){flex:none;width:1.125rem;height:1.125rem;font-size:1.125rem}:host ::ng-deep [data-slot=sn-command]>svg{fill:currentColor}:host ::ng-deep [data-slot=sn-command]>svg path{fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}:host ::ng-deep [data-slot=sn-command][data-icon-only]:has(>:is(ng-icon,svg,img)){padding-inline:0;aspect-ratio:1}:host ::ng-deep [data-slot=sn-command][data-icon-only]:has(>:is(ng-icon,svg,img)) .label{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}:host ::ng-deep [data-slot=sn-command][data-collapsed]{display:none!important}:host([data-compact]) ::ng-deep [data-slot=sn-command]:has(>:is(ng-icon,svg,img)){flex-direction:row;min-width:0;padding-inline:0;aspect-ratio:1}:host([data-compact]) ::ng-deep [data-slot=sn-command]:has(>:is(ng-icon,svg,img)) .label{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}:host ::ng-deep [data-slot=sn-command][data-variant=accent]{background:var(--sn-color-primary);border-color:var(--sn-color-primary-edge, transparent);color:var(--sn-color-primary-fg)}:host ::ng-deep [data-slot=sn-command][data-variant=accent]:hover:not(:disabled),:host ::ng-deep [data-slot=sn-command][data-variant=accent][aria-expanded=true]{background:color-mix(in srgb,var(--sn-color-primary) 90%,var(--sn-color-fg))}:host ::ng-deep [data-slot=sn-command][data-variant=accent]:active:not(:disabled){background:color-mix(in srgb,var(--sn-color-primary) 80%,var(--sn-color-fg))}:host([data-family=windows]){min-height:3rem;padding-inline:1rem .5rem}:host([data-family=windows]) .title{font-size:calc(var(--sn-font-size) * 1.43);font-weight:var(--sn-font-weight-strong)}:host([data-family=windows]) ::ng-deep [data-slot=sn-command]{min-height:2.25rem;font-weight:400}:host([data-family=windows]) ::ng-deep [data-slot=sn-command]>:is(ng-icon,svg){width:1rem;height:1rem;font-size:1rem}:host([data-skin=w10]) ::ng-deep [data-slot=sn-command]{flex-direction:column;gap:.25rem;min-width:4.25rem;min-height:3.5rem;padding:.375rem .5rem;border-radius:0;font-size:var(--sn-font-size-small)}:host([data-family=macos]){min-height:3.25rem;padding-inline:1rem .75rem}:host([data-family=macos]) .title{font-size:calc(var(--sn-font-size) * 1.15);font-weight:700}:host([data-family=macos]) .commands,:host([data-family=macos]) .cluster{gap:.5rem}:host([data-family=macos]) ::ng-deep [data-slot=sn-command]{min-height:2.25rem;color:var(--sn-color-fg)}:host([data-family=macos]) ::ng-deep [data-slot=sn-command]>:is(ng-icon,svg){width:1rem;height:1rem;font-size:1rem}:host([data-skin=mac]) .cluster:not(:has([data-slot=sn-command-group])):has([data-slot=sn-command]:not([data-collapsed],[hidden])){padding:.125rem;border-radius:var(--sn-radius-pill);background:var(--sn-color-glass);border:1px solid var(--sn-color-glass-border);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight),var(--sn-shadow-card);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));gap:0}:host([data-skin=mac]) .cluster:not(:has([data-slot=sn-command-group])):has([data-slot=sn-command]:not([data-collapsed],[hidden])) .commands{gap:0}:host([data-skin=mac]) .cluster:has([data-slot=sn-command-group]) .more:not([hidden]),:host([data-skin=mac]) .cluster:has([data-slot=sn-command-group]) ::ng-deep :is([data-slot=sn-command-group],.commands>[data-slot=sn-command]:not([data-variant=accent])){padding:.125rem;border-radius:var(--sn-radius-pill);background:var(--sn-color-glass);border:1px solid var(--sn-color-glass-border);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight),var(--sn-shadow-card);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));gap:0}:host([data-skin=mac]) ::ng-deep [data-slot=sn-command]{border-radius:var(--sn-radius-pill);min-width:2.25rem}:host([data-skin=macc]){min-height:3.25rem}:host([data-skin=macc]) ::ng-deep [data-slot=sn-command]{min-height:1.75rem;min-width:2rem;aspect-ratio:auto;padding-inline:.375rem;color:var(--sn-color-fg-muted)}:host([data-family=linux]),:host([data-family=web]){min-height:2.875rem;padding-inline:.375rem;background:var(--sn-color-bg);box-shadow:inset 0 -1px 0 var(--sn-color-border)}:host([data-family=linux]) .title,:host([data-family=web]) .title{font-weight:700}:host([data-family=linux]) .commands,:host([data-family=web]) .commands{gap:.375rem}:host([data-family=linux]) ::ng-deep [data-slot=sn-command],:host([data-family=web]) ::ng-deep [data-slot=sn-command]{min-height:2.125rem;min-width:2.125rem;font-weight:700}:host([data-skin=qt]){min-height:2.75rem;padding-inline:.75rem .375rem;gap:.75rem}:host([data-skin=qt]) .trail{justify-content:flex-start}:host([data-skin=qt]) .cluster{flex:1}:host([data-skin=qt]) .more{margin-inline-start:auto}:host([data-skin=qt]) .title{font-size:calc(var(--sn-font-size) * 1.15);font-weight:400;padding-inline-end:.75rem;border-inline-end:1px solid var(--sn-color-border)}:host([data-skin=qt]) .commands{gap:.125rem}:host([data-skin=qt]) ::ng-deep [data-slot=sn-command]{min-height:2rem;padding-inline:.375rem .5rem;gap:.375rem;font-weight:400}:host([data-skin=qt]) ::ng-deep [data-slot=sn-command]>:is(ng-icon,svg){width:1.375rem;height:1.375rem;font-size:1.375rem}:host([data-skin=qt]) ::ng-deep [data-slot=sn-command]:hover:not(:disabled),:host([data-skin=qt]) ::ng-deep [data-slot=sn-command][aria-expanded=true]{border-color:var(--sn-color-primary);background:color-mix(in srgb,var(--sn-color-primary) 15%,transparent)}:host([data-family=chromeos]){min-height:4rem;padding-inline:1rem .25rem;background:var(--sn-color-bg)}:host([data-family=chromeos]) .title{font-size:var(--sn-font-size-title);font-weight:400}:host([data-family=chromeos]) .commands,:host([data-family=chromeos]) .cluster{gap:0}:host([data-family=chromeos]) ::ng-deep [data-slot=sn-command]{min-height:3rem;min-width:3rem;border:0;border-radius:var(--sn-radius-pill);color:var(--sn-color-fg-muted)}:host([data-family=chromeos]) ::ng-deep [data-slot=sn-command]>:is(ng-icon,svg){width:1.5rem;height:1.5rem;font-size:1.5rem}:host([data-family=chromeos]) ::ng-deep [data-slot=sn-command]:hover:not(:disabled),:host([data-family=chromeos]) ::ng-deep [data-slot=sn-command][aria-expanded=true]{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}:host([data-family=chromeos]) ::ng-deep [data-slot=sn-command]:active:not(:disabled){background:color-mix(in srgb,var(--sn-color-fg) 12%,transparent)}@media(forced-colors:active){:host{border-bottom:1px solid CanvasText}:host ::ng-deep [data-slot=sn-command]{color:ButtonText!important}:host ::ng-deep [data-slot=sn-command]:hover:not(:disabled),:host ::ng-deep [data-slot=sn-command][aria-expanded=true]{background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host ::ng-deep [data-slot=sn-command]:disabled{color:GrayText!important;opacity:1}:host([data-skin=mac]) :is(.cluster,[data-slot=sn-command-group]){border-color:CanvasText}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		titlePosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "titlePosition",
				required: false
			}]
		}],
		headingLevel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "headingLevel",
				required: false
			}]
		}],
		ariaLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		overflowLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "overflowLabel",
				required: false
			}]
		}],
		commands: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "commands",
				required: false
			}]
		}],
		overflowItems: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "overflowItems",
				required: false
			}]
		}],
		collapse: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "collapse",
				required: false
			}]
		}],
		overflow: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => SnCommandOverflow), { isSignal: true }]
		}],
		titleEl: [{
			type: i0.ViewChild,
			args: ["titleEl", { isSignal: true }]
		}],
		more: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => SnCommand), { isSignal: true }]
		}]
	}
});
const SnCommandBarImports = [
	SnCommandBar,
	SnCommand,
	SnCommandGroup,
	SnCommandOverflow
];
function coachMarkPositions(placement) {
	if (placement === "top" || placement === "bottom") return (placement === "bottom" ? ["bottom", "top"] : ["top", "bottom"]).flatMap((side) => [
		"center",
		"start",
		"end"
	].map((align) => ({
		originX: align,
		overlayX: align,
		originY: side,
		overlayY: side === "bottom" ? "top" : "bottom"
	})));
	return (placement === "end" ? ["end", "start"] : ["start", "end"]).flatMap((side) => [
		"center",
		"top",
		"bottom"
	].map((align) => ({
		originY: align,
		overlayY: align,
		originX: side,
		overlayX: side === "end" ? "start" : "end"
	})));
}
function coachMarkSide(tip, anchor) {
	if (tip.top >= anchor.bottom - 1) return "bottom";
	if (tip.bottom <= anchor.top + 1) return "top";
	return tip.left >= anchor.right - 1 ? "right" : "left";
}
let nextId$6 = 0;
var SnCoachMark = class SnCoachMark {
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	icon = input("", ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	placement = input("bottom", ...ngDevMode ? [{ debugName: "placement" }] : /* istanbul ignore next */ []);
	closeLabel = input("Close", ...ngDevMode ? [{ debugName: "closeLabel" }] : /* istanbul ignore next */ []);
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	anchor = signal(null, ...ngDevMode ? [{ debugName: "anchor" }] : /* istanbul ignore next */ []);
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	titleId = `sn-coach-mark-title-${nextId$6}`;
	bodyId = `sn-coach-mark-body-${nextId$6++}`;
	host = inject(ElementRef).nativeElement;
	document = inject(DOCUMENT);
	injector = inject(Injector);
	overlay;
	strategy;
	overlayAnchor;
	constructor() {
		effect(() => {
			const anchor = this.anchor();
			const positions = coachMarkPositions(this.placement());
			if (this.open() && anchor) untracked(() => this.attach(anchor, positions));
			else untracked(() => this.detach());
		});
		inject(DestroyRef).onDestroy(() => this.overlay?.dispose());
	}
	show() {
		this.open.set(true);
	}
	hide() {
		this.open.set(false);
	}
	toggle() {
		this.open.update((open) => !open);
	}
	onEscape(event) {
		event.preventDefault();
		this.hide();
	}
	attach(anchor, positions) {
		if (this.overlayAnchor !== anchor) {
			this.overlay?.dispose();
			this.overlay = void 0;
		}
		if (!this.overlay) {
			this.overlayAnchor = anchor;
			this.strategy = createFlexibleConnectedPositionStrategy(this.injector, anchor).withFlexibleDimensions(false).withPush(false).withViewportMargin(8).withPopoverLocation("inline");
			this.strategy.positionChanges.subscribe(() => this.placed(anchor));
			this.overlay = createOverlayRef(this.injector, {
				positionStrategy: this.strategy,
				scrollStrategy: createRepositionScrollStrategy(this.injector),
				usePopover: true,
				panelClass: "sn-coach-mark-pane"
			});
		}
		this.strategy.withPositions(positions);
		if (this.overlay.hasAttached()) {
			this.overlay.updatePosition();
			return;
		}
		const first = positions[0];
		this.host.dataset["side"] = first.overlayY === "top" ? "bottom" : first.overlayY === "bottom" ? "top" : first.originX === "end" ? "right" : "left";
		this.overlay.attach(new DomPortal(this.host));
	}
	detach() {
		if (!this.overlay?.hasAttached()) return;
		const hadFocus = this.host.contains(this.document.activeElement);
		this.overlay.detach();
		delete this.host.dataset["placed"];
		delete this.host.dataset["side"];
		if (hadFocus) this.overlayAnchor?.focus();
	}
	placed(anchor) {
		const tip = this.host.getBoundingClientRect();
		const a = anchor.getBoundingClientRect();
		const side = coachMarkSide(tip, a);
		this.host.dataset["side"] = side;
		const beak = side === "top" || side === "bottom" ? a.left + a.width / 2 - tip.left : a.top + a.height / 2 - tip.top;
		this.host.style.setProperty("--sn-coach-mark-beak-at", `${beak}px`);
		this.host.dataset["placed"] = "";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnCoachMark,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnCoachMark,
		isStandalone: true,
		selector: "sn-coach-mark",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placement: {
				classPropertyName: "placement",
				publicName: "placement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeLabel: {
				classPropertyName: "closeLabel",
				publicName: "closeLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { open: "openChange" },
		host: {
			attributes: {
				"data-slot": "sn-coach-mark",
				"role": "dialog"
			},
			listeners: { "keydown.escape": "onEscape($event)" },
			properties: {
				"attr.title": "null",
				"attr.aria-labelledby": "titleId",
				"attr.aria-describedby": "bodyId",
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		ngImport: i0,
		template: `
    <div class="card">
      <div class="hero"><ng-content select="[snCoachMarkHero]" /></div>
      <div class="content">
        <div class="header">
          @if (icon()) {
            <ng-icon class="icon" [name]="icon()" aria-hidden="true" />
          }
          <h2 class="title" [id]="titleId">{{ title() }}</h2>
          <button type="button" class="close" [attr.aria-label]="closeLabel()" (click)="hide()">
            <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" /></svg>
          </button>
        </div>
        <div class="body" [id]="bodyId"><ng-content /></div>
        <div class="actions"><ng-content select="[snCoachMarkAction]" /></div>
      </div>
    </div>
    <span class="beak" aria-hidden="true"></span>
  `,
		isInline: true,
		styles: [":host{--bg: var(--sn-color-surface-solid);--border: var(--sn-color-border);--radius: var(--sn-radius-overlay);--shadow: var(--sn-shadow-overlay);--material: none;--pad: .75rem;--beak: .75rem;--gap: .25rem;--beak-min: calc(var(--radius) + var(--beak) * .75);display:none;position:relative;box-sizing:border-box;inline-size:20rem;max-inline-size:calc(100vw - 1rem);color:var(--sn-color-fg);font-family:var(--sn-font-sans);font-size:var(--sn-font-size);line-height:var(--sn-line-height)}:host([data-side]){display:block;animation:sn-coach-mark-in var(--sn-duration-fast) var(--sn-easing)}:host([data-side]:not([data-placed])){visibility:hidden}:host{--offset: calc(var(--gap) + var(--beak) * .71)}:host([data-side=top]),:host([data-side=bottom]){margin-block:var(--offset)}:host([data-side=left]),:host([data-side=right]){margin-inline:var(--offset)}@keyframes sn-coach-mark-in{0%{opacity:0}}@media(prefers-reduced-motion:reduce){:host([data-side]){animation:none}}.card{border:1px solid var(--border);border-radius:var(--radius);background:var(--bg);box-shadow:var(--shadow);-webkit-backdrop-filter:var(--material);backdrop-filter:var(--material)}.beak{position:absolute;inline-size:var(--beak);block-size:var(--beak);box-sizing:border-box;border:1px solid var(--border);background:var(--bg);-webkit-backdrop-filter:var(--material);backdrop-filter:var(--material);pointer-events:none}:host([data-side=bottom]) .beak,:host([data-side=top]) .beak{left:clamp(var(--beak-min),var(--sn-coach-mark-beak-at, 50%),100% - var(--beak-min))}:host([data-side=left]) .beak,:host([data-side=right]) .beak{top:clamp(var(--beak-min),var(--sn-coach-mark-beak-at, 50%),100% - var(--beak-min))}:host([data-side=bottom]) .beak{top:calc(var(--beak) / -2);transform:translate(-50%) rotate(45deg);clip-path:polygon(0 0,100% 0,0 100%)}:host([data-side=top]) .beak{bottom:calc(var(--beak) / -2);transform:translate(-50%) rotate(45deg);clip-path:polygon(100% 0,100% 100%,0 100%)}:host([data-side=right]) .beak{left:calc(var(--beak) / -2);transform:translateY(-50%) rotate(45deg);clip-path:polygon(0 0,100% 100%,0 100%)}:host([data-side=left]) .beak{right:calc(var(--beak) / -2);transform:translateY(-50%) rotate(45deg);clip-path:polygon(0 0,100% 0,100% 100%)}.hero{overflow:hidden;border-start-start-radius:calc(var(--radius) - 1px);border-start-end-radius:calc(var(--radius) - 1px)}.hero:empty{display:none}.hero ::ng-deep>*{display:block;inline-size:100%}.content{display:flex;flex-direction:column;gap:.375rem;padding:var(--pad)}.header{display:flex;align-items:flex-start;gap:.5rem}.icon{flex:none;font-size:1.25rem;color:var(--sn-color-accent-text)}.title{flex:1;margin:0;font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong);line-height:inherit}.body{color:var(--sn-color-fg)}.close{flex:none;display:grid;place-items:center;inline-size:1.75rem;block-size:1.75rem;margin:-.25rem -.25rem 0 0;padding:0;border:0;border-radius:var(--sn-radius-control);background:transparent;color:var(--sn-color-fg-muted);cursor:default}.close svg{inline-size:1rem;block-size:1rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.close:hover{background:var(--sn-color-hover);color:var(--sn-color-fg)}.close:focus-visible{outline:var(--sn-focus-outline);outline-offset:calc(var(--sn-focus-offset) * -1)}.actions{display:flex;justify-content:flex-end;gap:.5rem;margin-top:.375rem}.actions:empty{display:none}:host([data-skin=gtk]),:host([data-family=web]){--pad: .75rem;--beak: .75rem}:host([data-skin=gtk]) .title,:host([data-family=web]) .title{font-weight:700}:host([data-skin=gtk]) .close,:host([data-family=web]) .close{border-radius:var(--sn-radius-pill)}:host([data-family=windows]){--bg: var(--sn-color-acrylic);--border: var(--sn-color-stroke);--pad: .75rem;--beak: .875rem;--gap: .125rem;--material: blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-family=windows]) .content{gap:.25rem}:host([data-family=windows]) .close{inline-size:2rem;block-size:2rem;margin:-.375rem -.375rem 0 0;border-radius:var(--sn-radius-control)}:host([data-family=windows]) .actions{flex-direction:row-reverse;margin-top:.75rem}:host([data-family=windows]) .actions ::ng-deep>*{flex:1 1 0}:host([data-skin=w10]){--bg: var(--sn-color-surface-solid);--border: var(--sn-color-border);--material: none}:host([data-family=macos]){--bg: var(--sn-color-acrylic);--border: var(--sn-color-glass-border);--pad: 1rem;--beak: .8125rem;--gap: .125rem;--shadow: inset 0 1px 0 var(--sn-color-glass-highlight), var(--sn-shadow-overlay);--material: blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-family=macos]) .beak{border-radius:.1875rem}:host([data-family=macos]) .title{font-weight:700}:host([data-family=macos]) .body{color:var(--sn-color-fg-muted)}:host([data-family=macos]) .close{inline-size:1.25rem;block-size:1.25rem;margin:0;border-radius:var(--sn-radius-pill);background:var(--sn-color-hover)}:host([data-family=macos]) .close svg{inline-size:.625rem;block-size:.625rem;stroke-width:2.25}:host([data-family=macos]) .actions{margin-top:.5rem}:host([data-skin=macc]){--shadow: var(--sn-shadow-overlay)}:host([data-skin=qt]){--bg: var(--sn-color-surface-solid);--border: var(--sn-color-border);--beak: 0;--gap: .375rem}:host([data-skin=qt]) .beak{display:none}:host([data-skin=qt]) .actions{flex-direction:row-reverse;justify-content:flex-start;margin-top:.5rem}:host([data-skin=qt]) .close{border-radius:var(--sn-radius-control)}:host([data-skin=cros]){--bg: var(--sn-color-glass);--border: transparent;--radius: var(--sn-radius-surface);--beak: 0;--gap: .25rem}:host([data-skin=cros]) .beak{display:none}:host([data-skin=cros]) .content{gap:.25rem;padding:.75rem 1rem .5rem}:host([data-skin=cros]) .title{font-weight:500}:host([data-skin=cros]) .body{color:var(--sn-color-fg-muted)}:host([data-skin=cros]) .close{border-radius:var(--sn-radius-pill)}:host([data-skin=cros]) .actions{justify-content:flex-start;gap:0;margin:.25rem 0 0 -.75rem}:host([data-skin=cros]) .actions ::ng-deep>*{border-color:transparent;background:transparent;box-shadow:none;color:var(--sn-color-accent-text)}:host([data-skin=cros]) .actions ::ng-deep>*:hover{background:var(--sn-color-hover)}@media(forced-colors:active){.card,.beak{border-color:CanvasText}.close:hover{background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}}\n"],
		dependencies: [{
			kind: "component",
			type: NgIcon,
			selector: "ng-icon",
			inputs: [
				"name",
				"svg",
				"size",
				"strokeWidth",
				"color"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnCoachMark,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-coach-mark",
			imports: [NgIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-coach-mark",
				role: "dialog",
				"[attr.title]": "null",
				"[attr.aria-labelledby]": "titleId",
				"[attr.aria-describedby]": "bodyId",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()",
				"(keydown.escape)": "onEscape($event)"
			},
			template: `
    <div class="card">
      <div class="hero"><ng-content select="[snCoachMarkHero]" /></div>
      <div class="content">
        <div class="header">
          @if (icon()) {
            <ng-icon class="icon" [name]="icon()" aria-hidden="true" />
          }
          <h2 class="title" [id]="titleId">{{ title() }}</h2>
          <button type="button" class="close" [attr.aria-label]="closeLabel()" (click)="hide()">
            <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" /></svg>
          </button>
        </div>
        <div class="body" [id]="bodyId"><ng-content /></div>
        <div class="actions"><ng-content select="[snCoachMarkAction]" /></div>
      </div>
    </div>
    <span class="beak" aria-hidden="true"></span>
  `,
			styles: [":host{--bg: var(--sn-color-surface-solid);--border: var(--sn-color-border);--radius: var(--sn-radius-overlay);--shadow: var(--sn-shadow-overlay);--material: none;--pad: .75rem;--beak: .75rem;--gap: .25rem;--beak-min: calc(var(--radius) + var(--beak) * .75);display:none;position:relative;box-sizing:border-box;inline-size:20rem;max-inline-size:calc(100vw - 1rem);color:var(--sn-color-fg);font-family:var(--sn-font-sans);font-size:var(--sn-font-size);line-height:var(--sn-line-height)}:host([data-side]){display:block;animation:sn-coach-mark-in var(--sn-duration-fast) var(--sn-easing)}:host([data-side]:not([data-placed])){visibility:hidden}:host{--offset: calc(var(--gap) + var(--beak) * .71)}:host([data-side=top]),:host([data-side=bottom]){margin-block:var(--offset)}:host([data-side=left]),:host([data-side=right]){margin-inline:var(--offset)}@keyframes sn-coach-mark-in{0%{opacity:0}}@media(prefers-reduced-motion:reduce){:host([data-side]){animation:none}}.card{border:1px solid var(--border);border-radius:var(--radius);background:var(--bg);box-shadow:var(--shadow);-webkit-backdrop-filter:var(--material);backdrop-filter:var(--material)}.beak{position:absolute;inline-size:var(--beak);block-size:var(--beak);box-sizing:border-box;border:1px solid var(--border);background:var(--bg);-webkit-backdrop-filter:var(--material);backdrop-filter:var(--material);pointer-events:none}:host([data-side=bottom]) .beak,:host([data-side=top]) .beak{left:clamp(var(--beak-min),var(--sn-coach-mark-beak-at, 50%),100% - var(--beak-min))}:host([data-side=left]) .beak,:host([data-side=right]) .beak{top:clamp(var(--beak-min),var(--sn-coach-mark-beak-at, 50%),100% - var(--beak-min))}:host([data-side=bottom]) .beak{top:calc(var(--beak) / -2);transform:translate(-50%) rotate(45deg);clip-path:polygon(0 0,100% 0,0 100%)}:host([data-side=top]) .beak{bottom:calc(var(--beak) / -2);transform:translate(-50%) rotate(45deg);clip-path:polygon(100% 0,100% 100%,0 100%)}:host([data-side=right]) .beak{left:calc(var(--beak) / -2);transform:translateY(-50%) rotate(45deg);clip-path:polygon(0 0,100% 100%,0 100%)}:host([data-side=left]) .beak{right:calc(var(--beak) / -2);transform:translateY(-50%) rotate(45deg);clip-path:polygon(0 0,100% 0,100% 100%)}.hero{overflow:hidden;border-start-start-radius:calc(var(--radius) - 1px);border-start-end-radius:calc(var(--radius) - 1px)}.hero:empty{display:none}.hero ::ng-deep>*{display:block;inline-size:100%}.content{display:flex;flex-direction:column;gap:.375rem;padding:var(--pad)}.header{display:flex;align-items:flex-start;gap:.5rem}.icon{flex:none;font-size:1.25rem;color:var(--sn-color-accent-text)}.title{flex:1;margin:0;font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong);line-height:inherit}.body{color:var(--sn-color-fg)}.close{flex:none;display:grid;place-items:center;inline-size:1.75rem;block-size:1.75rem;margin:-.25rem -.25rem 0 0;padding:0;border:0;border-radius:var(--sn-radius-control);background:transparent;color:var(--sn-color-fg-muted);cursor:default}.close svg{inline-size:1rem;block-size:1rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.close:hover{background:var(--sn-color-hover);color:var(--sn-color-fg)}.close:focus-visible{outline:var(--sn-focus-outline);outline-offset:calc(var(--sn-focus-offset) * -1)}.actions{display:flex;justify-content:flex-end;gap:.5rem;margin-top:.375rem}.actions:empty{display:none}:host([data-skin=gtk]),:host([data-family=web]){--pad: .75rem;--beak: .75rem}:host([data-skin=gtk]) .title,:host([data-family=web]) .title{font-weight:700}:host([data-skin=gtk]) .close,:host([data-family=web]) .close{border-radius:var(--sn-radius-pill)}:host([data-family=windows]){--bg: var(--sn-color-acrylic);--border: var(--sn-color-stroke);--pad: .75rem;--beak: .875rem;--gap: .125rem;--material: blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-family=windows]) .content{gap:.25rem}:host([data-family=windows]) .close{inline-size:2rem;block-size:2rem;margin:-.375rem -.375rem 0 0;border-radius:var(--sn-radius-control)}:host([data-family=windows]) .actions{flex-direction:row-reverse;margin-top:.75rem}:host([data-family=windows]) .actions ::ng-deep>*{flex:1 1 0}:host([data-skin=w10]){--bg: var(--sn-color-surface-solid);--border: var(--sn-color-border);--material: none}:host([data-family=macos]){--bg: var(--sn-color-acrylic);--border: var(--sn-color-glass-border);--pad: 1rem;--beak: .8125rem;--gap: .125rem;--shadow: inset 0 1px 0 var(--sn-color-glass-highlight), var(--sn-shadow-overlay);--material: blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-family=macos]) .beak{border-radius:.1875rem}:host([data-family=macos]) .title{font-weight:700}:host([data-family=macos]) .body{color:var(--sn-color-fg-muted)}:host([data-family=macos]) .close{inline-size:1.25rem;block-size:1.25rem;margin:0;border-radius:var(--sn-radius-pill);background:var(--sn-color-hover)}:host([data-family=macos]) .close svg{inline-size:.625rem;block-size:.625rem;stroke-width:2.25}:host([data-family=macos]) .actions{margin-top:.5rem}:host([data-skin=macc]){--shadow: var(--sn-shadow-overlay)}:host([data-skin=qt]){--bg: var(--sn-color-surface-solid);--border: var(--sn-color-border);--beak: 0;--gap: .375rem}:host([data-skin=qt]) .beak{display:none}:host([data-skin=qt]) .actions{flex-direction:row-reverse;justify-content:flex-start;margin-top:.5rem}:host([data-skin=qt]) .close{border-radius:var(--sn-radius-control)}:host([data-skin=cros]){--bg: var(--sn-color-glass);--border: transparent;--radius: var(--sn-radius-surface);--beak: 0;--gap: .25rem}:host([data-skin=cros]) .beak{display:none}:host([data-skin=cros]) .content{gap:.25rem;padding:.75rem 1rem .5rem}:host([data-skin=cros]) .title{font-weight:500}:host([data-skin=cros]) .body{color:var(--sn-color-fg-muted)}:host([data-skin=cros]) .close{border-radius:var(--sn-radius-pill)}:host([data-skin=cros]) .actions{justify-content:flex-start;gap:0;margin:.25rem 0 0 -.75rem}:host([data-skin=cros]) .actions ::ng-deep>*{border-color:transparent;background:transparent;box-shadow:none;color:var(--sn-color-accent-text)}:host([data-skin=cros]) .actions ::ng-deep>*:hover{background:var(--sn-color-hover)}@media(forced-colors:active){.card,.beak{border-color:CanvasText}.close:hover{background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		placement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placement",
				required: false
			}]
		}],
		closeLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeLabel",
				required: false
			}]
		}],
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}]
	}
});
var SnCoachMarkFor = class SnCoachMarkFor {
	snCoachMarkFor = input.required(...ngDevMode ? [{ debugName: "snCoachMarkFor" }] : /* istanbul ignore next */ []);
	constructor() {
		const el = inject(ElementRef).nativeElement;
		effect((onCleanup) => {
			const tip = this.snCoachMarkFor();
			tip.anchor.set(el);
			onCleanup(() => {
				if (tip.anchor() === el) tip.anchor.set(null);
			});
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnCoachMarkFor,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnCoachMarkFor,
		isStandalone: true,
		selector: "[snCoachMarkFor]",
		inputs: { snCoachMarkFor: {
			classPropertyName: "snCoachMarkFor",
			publicName: "snCoachMarkFor",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			listeners: { "keydown.escape": "snCoachMarkFor().hide()" },
			properties: { "attr.aria-describedby": "snCoachMarkFor().open() ? snCoachMarkFor().bodyId : null" }
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnCoachMarkFor,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[snCoachMarkFor]",
			host: {
				"[attr.aria-describedby]": "snCoachMarkFor().open() ? snCoachMarkFor().bodyId : null",
				"(keydown.escape)": "snCoachMarkFor().hide()"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { snCoachMarkFor: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "snCoachMarkFor",
			required: true
		}]
	}] }
});
const SnCoachMarkImports = [SnCoachMark, SnCoachMarkFor];
let nextId$5 = 0;
var SnModalSheet = class SnModalSheet {
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	role = input("dialog", ...ngDevMode ? [{ debugName: "role" }] : /* istanbul ignore next */ []);
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	titleId = `sn-modal-sheet-title-${nextId$5++}`;
	panel = viewChild.required("panel", ...ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []);
	dialog = inject(Dialog);
	injector = inject(Injector);
	host = inject(ElementRef).nativeElement;
	ref;
	constructor() {
		afterRenderEffect(() => {
			if (this.open() && !this.ref) this.show(this.family() === "macos");
			else if (!this.open() && this.ref) this.ref.close();
		});
		inject(DestroyRef).onDestroy(() => {
			const ref = this.ref;
			this.ref = void 0;
			ref?.close();
		});
	}
	show(sheet) {
		const ref = this.ref = this.dialog.open(this.panel(), {
			role: this.role(),
			ariaModal: true,
			ariaLabelledBy: this.titleId,
			disableClose: true,
			backdropClass: sheet ? "cdk-overlay-transparent-backdrop" : "cdk-overlay-dark-backdrop",
			panelClass: "sn-modal-sheet-pane",
			positionStrategy: this.position(sheet)
		});
		if (sheet) ref.overlayRef.overlayElement.style.setProperty("--sn-sheet-top", `${this.sheetTop()}px`);
		ref.keydownEvents.subscribe((e) => {
			if (e.key === "Escape") {
				e.preventDefault();
				this.open.set(false);
			}
		});
		ref.closed.subscribe(() => {
			if (this.ref !== ref) return;
			this.ref = void 0;
			this.open.set(false);
		});
	}
	sheetTop() {
		const window = this.host.closest("[snSheetHost]");
		if (!window) return 0;
		const titleBar = window.querySelector("[data-slot=\"sn-title-bar\"]");
		return titleBar ? titleBar.getBoundingClientRect().bottom : window.getBoundingClientRect().top;
	}
	position(sheet) {
		const window = sheet ? this.host.closest("[snSheetHost]") : null;
		if (!window) {
			const global = createGlobalPositionStrategy(this.injector).centerHorizontally();
			return sheet ? global.top("0") : global.centerVertically();
		}
		const titleBar = window.querySelector("[data-slot=\"sn-title-bar\"]");
		return createFlexibleConnectedPositionStrategy(this.injector, titleBar ?? window).withFlexibleDimensions(false).withPush(false).withPositions([{
			originX: "center",
			originY: titleBar ? "bottom" : "top",
			overlayX: "center",
			overlayY: "top"
		}]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnModalSheet,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.5",
		type: SnModalSheet,
		isStandalone: true,
		selector: "sn-modal-sheet",
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			role: {
				classPropertyName: "role",
				publicName: "role",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { open: "openChange" },
		host: {
			attributes: { "data-slot": "sn-modal-sheet" },
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		viewQueries: [{
			propertyName: "panel",
			first: true,
			predicate: ["panel"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <ng-template #panel>
      <div class="sheet" data-slot="sn-modal-sheet-panel" [attr.data-family]="family()" [attr.data-skin]="skin()">
        <h2 class="title" [id]="titleId">{{ title() }}</h2>
        <div class="body"><ng-content /></div>
        <div class="actions">
          <span class="secondary"><ng-content select="[snSheetSecondary]" /></span>
          <span class="cancel" (click)="open.set(false)"><ng-content select="[snSheetCancel]" /></span>
          <span class="primary"><ng-content select="[snSheetPrimary]" /></span>
        </div>
      </div>
    </ng-template>
  `,
		isInline: true,
		styles: [":host{display:none}.sheet{display:grid;grid-template-columns:auto 1fr auto;grid-template-areas:\"title title title\" \"body body body\" \"actions actions actions\";width:min(var(--sn-dialog-width),100vw - 2rem);max-height:calc(100vh - 2rem);overflow:auto}.sheet[data-family=macos]{max-height:calc(100vh - var(--sn-sheet-top, 0px) - 1rem)}.sheet{box-sizing:border-box;color:var(--sn-color-fg);font-family:var(--sn-font-sans);font-size:var(--sn-font-size);line-height:var(--sn-line-height);background:var(--sn-color-surface-solid);border-radius:var(--sn-radius-overlay);box-shadow:var(--sn-shadow-overlay);animation:sn-sheet-in calc(var(--sn-duration-fast) * 2) var(--sn-easing)}@media(prefers-reduced-motion:reduce){.sheet{animation:none}}.title{grid-area:title;margin:0;font-size:calc(var(--sn-font-size) * 1.08);font-weight:var(--sn-font-weight-strong)}.body{grid-area:body;display:flex;flex-direction:column;gap:.75rem;min-width:0}.actions{grid-area:actions;display:flex;justify-content:flex-end;gap:.5rem}.sheet.sheet .actions:not(:has(>:not(:empty))){display:none}.secondary{margin-inline-end:auto}.secondary,.cancel,.primary{display:grid}.secondary:empty,.cancel:empty,.primary:empty{display:none}@keyframes sn-sheet-in{0%{opacity:0;transform:scale(.96)}}@keyframes sn-sheet-down{0%{transform:translateY(-100%)}}.sheet[data-family=macos]{width:min(28rem,100vw - 2rem);gap:1rem;padding:var(--sn-dialog-padding);margin-top:.375rem;border:1px solid var(--sn-color-glass-border);background:var(--sn-color-acrylic);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));animation-name:sn-sheet-down}.sheet[data-family=macos] .title{font-weight:700}.sheet[data-skin=macc]{margin-top:0;border-top:0;border-radius:0 0 var(--sn-radius-overlay) var(--sn-radius-overlay)}.sheet[data-family=windows]{border:1px solid var(--sn-color-stroke)}.sheet[data-family=windows] .title{padding:var(--sn-dialog-padding) var(--sn-dialog-padding) .75rem;font-size:var(--sn-font-size-title)}.sheet[data-family=windows] .body{padding:0 var(--sn-dialog-padding) var(--sn-dialog-padding)}.sheet[data-family=windows] .actions{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;padding:var(--sn-dialog-padding);background:var(--sn-color-bg);border-top:1px solid var(--sn-color-stroke)}.sheet[data-family=windows] .primary{order:-2}.sheet[data-family=windows] .secondary{order:-1;margin-inline-end:0}.sheet[data-skin=w10] .actions{padding-top:0;background:none;border-top:0}.sheet[data-skin=gtk],.sheet[data-skin=web]{grid-template-areas:\"cancel title primary\" \"body body body\" \"secondary secondary secondary\"}.sheet[data-skin=gtk] .title,.sheet[data-skin=web] .title{grid-column:1/-1;grid-row:1;display:flex;align-items:center;justify-content:center;min-height:2.875rem;padding:0 6rem;font-weight:700;text-align:center}.sheet[data-skin=gtk] .body,.sheet[data-skin=web] .body{padding:.75rem var(--sn-dialog-padding) var(--sn-dialog-padding)}.sheet[data-skin=gtk] .actions,.sheet[data-skin=web] .actions{display:contents}.sheet[data-skin=gtk] .cancel,.sheet[data-skin=gtk] .primary,.sheet[data-skin=web] .cancel,.sheet[data-skin=web] .primary{grid-row:1;align-self:center;margin:0 .375rem}.sheet[data-skin=gtk] .cancel,.sheet[data-skin=web] .cancel{grid-column:1}.sheet[data-skin=gtk] .primary,.sheet[data-skin=web] .primary{grid-column:3}.sheet[data-skin=gtk] .secondary,.sheet[data-skin=web] .secondary{grid-area:secondary;justify-self:start;margin:0 var(--sn-dialog-padding) var(--sn-dialog-padding)}.sheet[data-skin=qt]{border:1px solid var(--sn-color-border)}.sheet[data-skin=qt] .title{padding:.375rem .75rem;font-size:var(--sn-font-size);text-align:center;background:var(--sn-color-surface);border-bottom:1px solid var(--sn-color-border)}.sheet[data-skin=qt] .body{padding:var(--sn-dialog-padding)}.sheet[data-skin=qt] .actions{padding:0 var(--sn-dialog-padding) var(--sn-dialog-padding)}.sheet[data-skin=qt] .primary{order:-1}.sheet[data-skin=cros]{gap:1rem;padding:var(--sn-dialog-padding)}.sheet[data-skin=cros] .title{font-size:1.5rem;font-weight:400}.sheet[data-skin=cros] .actions ::ng-deep [data-slot=button]{background:transparent;border-color:transparent;box-shadow:none;color:var(--sn-color-accent-text)}.sheet[data-skin=cros] .actions ::ng-deep [data-slot=button].text-destructive{color:var(--sn-color-danger)}.sheet[data-skin=cros] .actions{gap:.25rem}@media(forced-colors:active){.sheet{border:1px solid CanvasText}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnModalSheet,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-modal-sheet",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-modal-sheet",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    <ng-template #panel>
      <div class="sheet" data-slot="sn-modal-sheet-panel" [attr.data-family]="family()" [attr.data-skin]="skin()">
        <h2 class="title" [id]="titleId">{{ title() }}</h2>
        <div class="body"><ng-content /></div>
        <div class="actions">
          <span class="secondary"><ng-content select="[snSheetSecondary]" /></span>
          <span class="cancel" (click)="open.set(false)"><ng-content select="[snSheetCancel]" /></span>
          <span class="primary"><ng-content select="[snSheetPrimary]" /></span>
        </div>
      </div>
    </ng-template>
  `,
			styles: [":host{display:none}.sheet{display:grid;grid-template-columns:auto 1fr auto;grid-template-areas:\"title title title\" \"body body body\" \"actions actions actions\";width:min(var(--sn-dialog-width),100vw - 2rem);max-height:calc(100vh - 2rem);overflow:auto}.sheet[data-family=macos]{max-height:calc(100vh - var(--sn-sheet-top, 0px) - 1rem)}.sheet{box-sizing:border-box;color:var(--sn-color-fg);font-family:var(--sn-font-sans);font-size:var(--sn-font-size);line-height:var(--sn-line-height);background:var(--sn-color-surface-solid);border-radius:var(--sn-radius-overlay);box-shadow:var(--sn-shadow-overlay);animation:sn-sheet-in calc(var(--sn-duration-fast) * 2) var(--sn-easing)}@media(prefers-reduced-motion:reduce){.sheet{animation:none}}.title{grid-area:title;margin:0;font-size:calc(var(--sn-font-size) * 1.08);font-weight:var(--sn-font-weight-strong)}.body{grid-area:body;display:flex;flex-direction:column;gap:.75rem;min-width:0}.actions{grid-area:actions;display:flex;justify-content:flex-end;gap:.5rem}.sheet.sheet .actions:not(:has(>:not(:empty))){display:none}.secondary{margin-inline-end:auto}.secondary,.cancel,.primary{display:grid}.secondary:empty,.cancel:empty,.primary:empty{display:none}@keyframes sn-sheet-in{0%{opacity:0;transform:scale(.96)}}@keyframes sn-sheet-down{0%{transform:translateY(-100%)}}.sheet[data-family=macos]{width:min(28rem,100vw - 2rem);gap:1rem;padding:var(--sn-dialog-padding);margin-top:.375rem;border:1px solid var(--sn-color-glass-border);background:var(--sn-color-acrylic);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));animation-name:sn-sheet-down}.sheet[data-family=macos] .title{font-weight:700}.sheet[data-skin=macc]{margin-top:0;border-top:0;border-radius:0 0 var(--sn-radius-overlay) var(--sn-radius-overlay)}.sheet[data-family=windows]{border:1px solid var(--sn-color-stroke)}.sheet[data-family=windows] .title{padding:var(--sn-dialog-padding) var(--sn-dialog-padding) .75rem;font-size:var(--sn-font-size-title)}.sheet[data-family=windows] .body{padding:0 var(--sn-dialog-padding) var(--sn-dialog-padding)}.sheet[data-family=windows] .actions{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;padding:var(--sn-dialog-padding);background:var(--sn-color-bg);border-top:1px solid var(--sn-color-stroke)}.sheet[data-family=windows] .primary{order:-2}.sheet[data-family=windows] .secondary{order:-1;margin-inline-end:0}.sheet[data-skin=w10] .actions{padding-top:0;background:none;border-top:0}.sheet[data-skin=gtk],.sheet[data-skin=web]{grid-template-areas:\"cancel title primary\" \"body body body\" \"secondary secondary secondary\"}.sheet[data-skin=gtk] .title,.sheet[data-skin=web] .title{grid-column:1/-1;grid-row:1;display:flex;align-items:center;justify-content:center;min-height:2.875rem;padding:0 6rem;font-weight:700;text-align:center}.sheet[data-skin=gtk] .body,.sheet[data-skin=web] .body{padding:.75rem var(--sn-dialog-padding) var(--sn-dialog-padding)}.sheet[data-skin=gtk] .actions,.sheet[data-skin=web] .actions{display:contents}.sheet[data-skin=gtk] .cancel,.sheet[data-skin=gtk] .primary,.sheet[data-skin=web] .cancel,.sheet[data-skin=web] .primary{grid-row:1;align-self:center;margin:0 .375rem}.sheet[data-skin=gtk] .cancel,.sheet[data-skin=web] .cancel{grid-column:1}.sheet[data-skin=gtk] .primary,.sheet[data-skin=web] .primary{grid-column:3}.sheet[data-skin=gtk] .secondary,.sheet[data-skin=web] .secondary{grid-area:secondary;justify-self:start;margin:0 var(--sn-dialog-padding) var(--sn-dialog-padding)}.sheet[data-skin=qt]{border:1px solid var(--sn-color-border)}.sheet[data-skin=qt] .title{padding:.375rem .75rem;font-size:var(--sn-font-size);text-align:center;background:var(--sn-color-surface);border-bottom:1px solid var(--sn-color-border)}.sheet[data-skin=qt] .body{padding:var(--sn-dialog-padding)}.sheet[data-skin=qt] .actions{padding:0 var(--sn-dialog-padding) var(--sn-dialog-padding)}.sheet[data-skin=qt] .primary{order:-1}.sheet[data-skin=cros]{gap:1rem;padding:var(--sn-dialog-padding)}.sheet[data-skin=cros] .title{font-size:1.5rem;font-weight:400}.sheet[data-skin=cros] .actions ::ng-deep [data-slot=button]{background:transparent;border-color:transparent;box-shadow:none;color:var(--sn-color-accent-text)}.sheet[data-skin=cros] .actions ::ng-deep [data-slot=button].text-destructive{color:var(--sn-color-danger)}.sheet[data-skin=cros] .actions{gap:.25rem}@media(forced-colors:active){.sheet{border:1px solid CanvasText}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		role: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "role",
				required: false
			}]
		}],
		panel: [{
			type: i0.ViewChild,
			args: ["panel", { isSignal: true }]
		}]
	}
});
let nextId$4 = 0;
var SnInspectorLayout = class SnInspectorLayout {
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnInspectorLayout,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: SnInspectorLayout,
		isStandalone: true,
		selector: "sn-inspector-layout",
		host: {
			attributes: { "data-slot": "sn-inspector-layout" },
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		ngImport: i0,
		template: `
    <div class="main"><ng-content /></div>
    <ng-content select="sn-inspector" />
  `,
		isInline: true,
		styles: [":host([data-slot=sn-inspector-layout]){position:relative;display:flex;min-block-size:0;container:sn-inspector-layout/inline-size}:host([data-slot=sn-inspector-layout]) .main{display:flex;flex-direction:column;flex:1;min-inline-size:0;overflow:auto}:host([data-slot=sn-inspector]){display:flex;flex-direction:column;flex:none;inline-size:17.5rem;box-sizing:border-box;overflow-y:auto;background:var(--sn-color-surface-solid);border-inline-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector][hidden]){display:none}header{display:flex;align-items:center;gap:.75rem;padding:1rem 1rem .5rem}h2{flex:1;min-inline-size:0;margin:0;font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong);overflow-wrap:anywhere}.preview{flex:none;font-size:2rem;color:var(--sn-color-accent-text)}:host([data-slot=sn-inspector]) .body{display:flex;flex-direction:column;gap:1rem;padding:.5rem 1rem 1rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector]){position:absolute;inset-block:0;inset-inline-end:0;z-index:1;max-inline-size:85%;box-shadow:var(--sn-shadow-overlay)}}:host([data-slot=sn-inspector-section]){display:block}h3{margin:0 0 .375rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector-section]) .rows{display:flex;flex-direction:column;gap:.5rem}:host([data-slot=sn-inspector-property]){display:flex;flex-direction:column;gap:.125rem}.label{font-size:var(--sn-font-size-small);color:var(--sn-color-fg-muted)}.value{overflow-wrap:anywhere}:host([data-slot=sn-inspector-property][data-family=macos]),:host([data-slot=sn-inspector-property][data-skin=qt]){display:grid;grid-template-columns:5.5rem 1fr;gap:.5rem;align-items:baseline}:host([data-slot=sn-inspector-property][data-family=macos]) .label,:host([data-slot=sn-inspector-property][data-skin=qt]) .label{font-size:inherit;text-align:end}:host([data-slot=sn-inspector-property][data-family=macos]) .label:after,:host([data-slot=sn-inspector-property][data-skin=qt]) .label:after{content:\":\"}:host([data-slot=sn-inspector][data-family=windows]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-family=windows]) header{padding:1.25rem 1.25rem .75rem}:host([data-slot=sn-inspector][data-family=windows]) h2{font-size:var(--sn-font-size-title)}:host([data-slot=sn-inspector][data-family=windows]) .preview{font-size:2.5rem}:host([data-slot=sn-inspector][data-family=windows]) .body{gap:1.25rem;padding:0 1.25rem 1.25rem}:host([data-slot=sn-inspector-section][data-family=windows]) h3{font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-family=macos]){inline-size:16.25rem;background:var(--sn-color-glass);border-inline-start-color:var(--sn-color-glass-border);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-slot=sn-inspector][data-family=macos]) .body{gap:.75rem}:host([data-slot=sn-inspector][data-skin=mac]){margin:.5rem .5rem .5rem 0;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-inspector-section][data-family=macos]){padding-block-start:.625rem;border-block-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector-section][data-family=macos]) h3{font-weight:700}:host([data-slot=sn-inspector-section][data-family=macos]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=gtk]),:host([data-slot=sn-inspector][data-family=web]){background:var(--sn-color-sidebar)}:host([data-slot=sn-inspector][data-skin=gtk]) header,:host([data-slot=sn-inspector][data-family=web]) header{justify-content:center;min-block-size:2.875rem;padding:0 .75rem}:host([data-slot=sn-inspector][data-skin=gtk]) h2,:host([data-slot=sn-inspector][data-family=web]) h2{flex:0 1 auto;font-weight:700;text-align:center}:host([data-slot=sn-inspector][data-skin=gtk]) .preview,:host([data-slot=sn-inspector][data-family=web]) .preview{font-size:1.25rem;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=gtk]) .body,:host([data-slot=sn-inspector][data-family=web]) .body{gap:1.5rem;padding:.75rem}:host([data-slot=sn-inspector-section][data-skin=gtk]) h3,:host([data-slot=sn-inspector-section][data-family=web]) h3{margin-block-end:.75rem;font-size:var(--sn-font-size);font-weight:700;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=qt]){background:var(--sn-color-bg);border-inline-start-color:var(--sn-color-border)}:host([data-slot=sn-inspector][data-skin=qt]) header{flex-direction:column;gap:.5rem;padding:1.5rem 1rem .75rem}:host([data-slot=sn-inspector][data-skin=qt]) h2{text-align:center}:host([data-slot=sn-inspector][data-skin=qt]) .preview{font-size:7rem;color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector][data-skin=qt]) .body{gap:.75rem}:host([data-slot=sn-inspector-section][data-skin=qt]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=cros]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-skin=cros]) header{padding:1.5rem 1.5rem 1rem}:host([data-slot=sn-inspector][data-skin=cros]) h2{font-size:1.375em;font-weight:400}:host([data-slot=sn-inspector][data-skin=cros]) .preview{font-size:1.5rem}:host([data-slot=sn-inspector][data-skin=cros]) .body{gap:1.5rem;padding:0 1.5rem 1.5rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector][data-skin=cros]){border-start-start-radius:var(--sn-radius-overlay);border-end-start-radius:var(--sn-radius-overlay)}}:host([data-slot=sn-inspector-section][data-skin=cros]) h3{font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-control)}.close{display:grid;place-items:center;flex:none;inline-size:2.5rem;block-size:2.5rem;margin:-.5rem -.5rem -.5rem 0;padding:0;border:0;border-radius:var(--sn-radius-pill);background:transparent;color:var(--sn-color-fg-muted)}.close svg{inline-size:1.25rem;block-size:1.25rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.close:hover{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}.close:focus-visible{outline:var(--sn-focus-outline);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-inspector]){border-inline-start:1px solid CanvasText}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnInspectorLayout,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-inspector-layout",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-inspector-layout",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    <div class="main"><ng-content /></div>
    <ng-content select="sn-inspector" />
  `,
			styles: [":host([data-slot=sn-inspector-layout]){position:relative;display:flex;min-block-size:0;container:sn-inspector-layout/inline-size}:host([data-slot=sn-inspector-layout]) .main{display:flex;flex-direction:column;flex:1;min-inline-size:0;overflow:auto}:host([data-slot=sn-inspector]){display:flex;flex-direction:column;flex:none;inline-size:17.5rem;box-sizing:border-box;overflow-y:auto;background:var(--sn-color-surface-solid);border-inline-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector][hidden]){display:none}header{display:flex;align-items:center;gap:.75rem;padding:1rem 1rem .5rem}h2{flex:1;min-inline-size:0;margin:0;font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong);overflow-wrap:anywhere}.preview{flex:none;font-size:2rem;color:var(--sn-color-accent-text)}:host([data-slot=sn-inspector]) .body{display:flex;flex-direction:column;gap:1rem;padding:.5rem 1rem 1rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector]){position:absolute;inset-block:0;inset-inline-end:0;z-index:1;max-inline-size:85%;box-shadow:var(--sn-shadow-overlay)}}:host([data-slot=sn-inspector-section]){display:block}h3{margin:0 0 .375rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector-section]) .rows{display:flex;flex-direction:column;gap:.5rem}:host([data-slot=sn-inspector-property]){display:flex;flex-direction:column;gap:.125rem}.label{font-size:var(--sn-font-size-small);color:var(--sn-color-fg-muted)}.value{overflow-wrap:anywhere}:host([data-slot=sn-inspector-property][data-family=macos]),:host([data-slot=sn-inspector-property][data-skin=qt]){display:grid;grid-template-columns:5.5rem 1fr;gap:.5rem;align-items:baseline}:host([data-slot=sn-inspector-property][data-family=macos]) .label,:host([data-slot=sn-inspector-property][data-skin=qt]) .label{font-size:inherit;text-align:end}:host([data-slot=sn-inspector-property][data-family=macos]) .label:after,:host([data-slot=sn-inspector-property][data-skin=qt]) .label:after{content:\":\"}:host([data-slot=sn-inspector][data-family=windows]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-family=windows]) header{padding:1.25rem 1.25rem .75rem}:host([data-slot=sn-inspector][data-family=windows]) h2{font-size:var(--sn-font-size-title)}:host([data-slot=sn-inspector][data-family=windows]) .preview{font-size:2.5rem}:host([data-slot=sn-inspector][data-family=windows]) .body{gap:1.25rem;padding:0 1.25rem 1.25rem}:host([data-slot=sn-inspector-section][data-family=windows]) h3{font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-family=macos]){inline-size:16.25rem;background:var(--sn-color-glass);border-inline-start-color:var(--sn-color-glass-border);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-slot=sn-inspector][data-family=macos]) .body{gap:.75rem}:host([data-slot=sn-inspector][data-skin=mac]){margin:.5rem .5rem .5rem 0;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-inspector-section][data-family=macos]){padding-block-start:.625rem;border-block-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector-section][data-family=macos]) h3{font-weight:700}:host([data-slot=sn-inspector-section][data-family=macos]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=gtk]),:host([data-slot=sn-inspector][data-family=web]){background:var(--sn-color-sidebar)}:host([data-slot=sn-inspector][data-skin=gtk]) header,:host([data-slot=sn-inspector][data-family=web]) header{justify-content:center;min-block-size:2.875rem;padding:0 .75rem}:host([data-slot=sn-inspector][data-skin=gtk]) h2,:host([data-slot=sn-inspector][data-family=web]) h2{flex:0 1 auto;font-weight:700;text-align:center}:host([data-slot=sn-inspector][data-skin=gtk]) .preview,:host([data-slot=sn-inspector][data-family=web]) .preview{font-size:1.25rem;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=gtk]) .body,:host([data-slot=sn-inspector][data-family=web]) .body{gap:1.5rem;padding:.75rem}:host([data-slot=sn-inspector-section][data-skin=gtk]) h3,:host([data-slot=sn-inspector-section][data-family=web]) h3{margin-block-end:.75rem;font-size:var(--sn-font-size);font-weight:700;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=qt]){background:var(--sn-color-bg);border-inline-start-color:var(--sn-color-border)}:host([data-slot=sn-inspector][data-skin=qt]) header{flex-direction:column;gap:.5rem;padding:1.5rem 1rem .75rem}:host([data-slot=sn-inspector][data-skin=qt]) h2{text-align:center}:host([data-slot=sn-inspector][data-skin=qt]) .preview{font-size:7rem;color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector][data-skin=qt]) .body{gap:.75rem}:host([data-slot=sn-inspector-section][data-skin=qt]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=cros]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-skin=cros]) header{padding:1.5rem 1.5rem 1rem}:host([data-slot=sn-inspector][data-skin=cros]) h2{font-size:1.375em;font-weight:400}:host([data-slot=sn-inspector][data-skin=cros]) .preview{font-size:1.5rem}:host([data-slot=sn-inspector][data-skin=cros]) .body{gap:1.5rem;padding:0 1.5rem 1.5rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector][data-skin=cros]){border-start-start-radius:var(--sn-radius-overlay);border-end-start-radius:var(--sn-radius-overlay)}}:host([data-slot=sn-inspector-section][data-skin=cros]) h3{font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-control)}.close{display:grid;place-items:center;flex:none;inline-size:2.5rem;block-size:2.5rem;margin:-.5rem -.5rem -.5rem 0;padding:0;border:0;border-radius:var(--sn-radius-pill);background:transparent;color:var(--sn-color-fg-muted)}.close svg{inline-size:1.25rem;block-size:1.25rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.close:hover{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}.close:focus-visible{outline:var(--sn-focus-outline);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-inspector]){border-inline-start:1px solid CanvasText}}\n"]
		}]
	}]
});
var SnInspector = class SnInspector {
	open = model(true, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	icon = input("", ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	headingId = `sn-inspector-${nextId$4++}`;
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnInspector,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnInspector,
		isStandalone: true,
		selector: "sn-inspector",
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { open: "openChange" },
		host: {
			attributes: {
				"data-slot": "sn-inspector",
				"role": "complementary"
			},
			properties: {
				"attr.aria-labelledby": "headingId",
				"attr.hidden": "open() ? null : \"\"",
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		ngImport: i0,
		template: `
    <header>
      @if (icon()) {
        <ng-icon class="preview" [name]="icon()" aria-hidden="true" />
      }
      <h2 [id]="headingId">{{ title() }}</h2>
      @if (skin() === 'cros') {
        <button type="button" class="close" aria-label="Close" (click)="open.set(false)">
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" /></svg>
        </button>
      }
    </header>
    <div class="body"><ng-content /></div>
  `,
		isInline: true,
		styles: [":host([data-slot=sn-inspector-layout]){position:relative;display:flex;min-block-size:0;container:sn-inspector-layout/inline-size}:host([data-slot=sn-inspector-layout]) .main{display:flex;flex-direction:column;flex:1;min-inline-size:0;overflow:auto}:host([data-slot=sn-inspector]){display:flex;flex-direction:column;flex:none;inline-size:17.5rem;box-sizing:border-box;overflow-y:auto;background:var(--sn-color-surface-solid);border-inline-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector][hidden]){display:none}header{display:flex;align-items:center;gap:.75rem;padding:1rem 1rem .5rem}h2{flex:1;min-inline-size:0;margin:0;font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong);overflow-wrap:anywhere}.preview{flex:none;font-size:2rem;color:var(--sn-color-accent-text)}:host([data-slot=sn-inspector]) .body{display:flex;flex-direction:column;gap:1rem;padding:.5rem 1rem 1rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector]){position:absolute;inset-block:0;inset-inline-end:0;z-index:1;max-inline-size:85%;box-shadow:var(--sn-shadow-overlay)}}:host([data-slot=sn-inspector-section]){display:block}h3{margin:0 0 .375rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector-section]) .rows{display:flex;flex-direction:column;gap:.5rem}:host([data-slot=sn-inspector-property]){display:flex;flex-direction:column;gap:.125rem}.label{font-size:var(--sn-font-size-small);color:var(--sn-color-fg-muted)}.value{overflow-wrap:anywhere}:host([data-slot=sn-inspector-property][data-family=macos]),:host([data-slot=sn-inspector-property][data-skin=qt]){display:grid;grid-template-columns:5.5rem 1fr;gap:.5rem;align-items:baseline}:host([data-slot=sn-inspector-property][data-family=macos]) .label,:host([data-slot=sn-inspector-property][data-skin=qt]) .label{font-size:inherit;text-align:end}:host([data-slot=sn-inspector-property][data-family=macos]) .label:after,:host([data-slot=sn-inspector-property][data-skin=qt]) .label:after{content:\":\"}:host([data-slot=sn-inspector][data-family=windows]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-family=windows]) header{padding:1.25rem 1.25rem .75rem}:host([data-slot=sn-inspector][data-family=windows]) h2{font-size:var(--sn-font-size-title)}:host([data-slot=sn-inspector][data-family=windows]) .preview{font-size:2.5rem}:host([data-slot=sn-inspector][data-family=windows]) .body{gap:1.25rem;padding:0 1.25rem 1.25rem}:host([data-slot=sn-inspector-section][data-family=windows]) h3{font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-family=macos]){inline-size:16.25rem;background:var(--sn-color-glass);border-inline-start-color:var(--sn-color-glass-border);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-slot=sn-inspector][data-family=macos]) .body{gap:.75rem}:host([data-slot=sn-inspector][data-skin=mac]){margin:.5rem .5rem .5rem 0;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-inspector-section][data-family=macos]){padding-block-start:.625rem;border-block-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector-section][data-family=macos]) h3{font-weight:700}:host([data-slot=sn-inspector-section][data-family=macos]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=gtk]),:host([data-slot=sn-inspector][data-family=web]){background:var(--sn-color-sidebar)}:host([data-slot=sn-inspector][data-skin=gtk]) header,:host([data-slot=sn-inspector][data-family=web]) header{justify-content:center;min-block-size:2.875rem;padding:0 .75rem}:host([data-slot=sn-inspector][data-skin=gtk]) h2,:host([data-slot=sn-inspector][data-family=web]) h2{flex:0 1 auto;font-weight:700;text-align:center}:host([data-slot=sn-inspector][data-skin=gtk]) .preview,:host([data-slot=sn-inspector][data-family=web]) .preview{font-size:1.25rem;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=gtk]) .body,:host([data-slot=sn-inspector][data-family=web]) .body{gap:1.5rem;padding:.75rem}:host([data-slot=sn-inspector-section][data-skin=gtk]) h3,:host([data-slot=sn-inspector-section][data-family=web]) h3{margin-block-end:.75rem;font-size:var(--sn-font-size);font-weight:700;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=qt]){background:var(--sn-color-bg);border-inline-start-color:var(--sn-color-border)}:host([data-slot=sn-inspector][data-skin=qt]) header{flex-direction:column;gap:.5rem;padding:1.5rem 1rem .75rem}:host([data-slot=sn-inspector][data-skin=qt]) h2{text-align:center}:host([data-slot=sn-inspector][data-skin=qt]) .preview{font-size:7rem;color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector][data-skin=qt]) .body{gap:.75rem}:host([data-slot=sn-inspector-section][data-skin=qt]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=cros]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-skin=cros]) header{padding:1.5rem 1.5rem 1rem}:host([data-slot=sn-inspector][data-skin=cros]) h2{font-size:1.375em;font-weight:400}:host([data-slot=sn-inspector][data-skin=cros]) .preview{font-size:1.5rem}:host([data-slot=sn-inspector][data-skin=cros]) .body{gap:1.5rem;padding:0 1.5rem 1.5rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector][data-skin=cros]){border-start-start-radius:var(--sn-radius-overlay);border-end-start-radius:var(--sn-radius-overlay)}}:host([data-slot=sn-inspector-section][data-skin=cros]) h3{font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-control)}.close{display:grid;place-items:center;flex:none;inline-size:2.5rem;block-size:2.5rem;margin:-.5rem -.5rem -.5rem 0;padding:0;border:0;border-radius:var(--sn-radius-pill);background:transparent;color:var(--sn-color-fg-muted)}.close svg{inline-size:1.25rem;block-size:1.25rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.close:hover{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}.close:focus-visible{outline:var(--sn-focus-outline);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-inspector]){border-inline-start:1px solid CanvasText}}\n"],
		dependencies: [{
			kind: "component",
			type: NgIcon,
			selector: "ng-icon",
			inputs: [
				"name",
				"svg",
				"size",
				"strokeWidth",
				"color"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnInspector,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-inspector",
			imports: [NgIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-inspector",
				role: "complementary",
				"[attr.aria-labelledby]": "headingId",
				"[attr.hidden]": "open() ? null : \"\"",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    <header>
      @if (icon()) {
        <ng-icon class="preview" [name]="icon()" aria-hidden="true" />
      }
      <h2 [id]="headingId">{{ title() }}</h2>
      @if (skin() === 'cros') {
        <button type="button" class="close" aria-label="Close" (click)="open.set(false)">
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8" /></svg>
        </button>
      }
    </header>
    <div class="body"><ng-content /></div>
  `,
			styles: [":host([data-slot=sn-inspector-layout]){position:relative;display:flex;min-block-size:0;container:sn-inspector-layout/inline-size}:host([data-slot=sn-inspector-layout]) .main{display:flex;flex-direction:column;flex:1;min-inline-size:0;overflow:auto}:host([data-slot=sn-inspector]){display:flex;flex-direction:column;flex:none;inline-size:17.5rem;box-sizing:border-box;overflow-y:auto;background:var(--sn-color-surface-solid);border-inline-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector][hidden]){display:none}header{display:flex;align-items:center;gap:.75rem;padding:1rem 1rem .5rem}h2{flex:1;min-inline-size:0;margin:0;font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong);overflow-wrap:anywhere}.preview{flex:none;font-size:2rem;color:var(--sn-color-accent-text)}:host([data-slot=sn-inspector]) .body{display:flex;flex-direction:column;gap:1rem;padding:.5rem 1rem 1rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector]){position:absolute;inset-block:0;inset-inline-end:0;z-index:1;max-inline-size:85%;box-shadow:var(--sn-shadow-overlay)}}:host([data-slot=sn-inspector-section]){display:block}h3{margin:0 0 .375rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector-section]) .rows{display:flex;flex-direction:column;gap:.5rem}:host([data-slot=sn-inspector-property]){display:flex;flex-direction:column;gap:.125rem}.label{font-size:var(--sn-font-size-small);color:var(--sn-color-fg-muted)}.value{overflow-wrap:anywhere}:host([data-slot=sn-inspector-property][data-family=macos]),:host([data-slot=sn-inspector-property][data-skin=qt]){display:grid;grid-template-columns:5.5rem 1fr;gap:.5rem;align-items:baseline}:host([data-slot=sn-inspector-property][data-family=macos]) .label,:host([data-slot=sn-inspector-property][data-skin=qt]) .label{font-size:inherit;text-align:end}:host([data-slot=sn-inspector-property][data-family=macos]) .label:after,:host([data-slot=sn-inspector-property][data-skin=qt]) .label:after{content:\":\"}:host([data-slot=sn-inspector][data-family=windows]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-family=windows]) header{padding:1.25rem 1.25rem .75rem}:host([data-slot=sn-inspector][data-family=windows]) h2{font-size:var(--sn-font-size-title)}:host([data-slot=sn-inspector][data-family=windows]) .preview{font-size:2.5rem}:host([data-slot=sn-inspector][data-family=windows]) .body{gap:1.25rem;padding:0 1.25rem 1.25rem}:host([data-slot=sn-inspector-section][data-family=windows]) h3{font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-family=macos]){inline-size:16.25rem;background:var(--sn-color-glass);border-inline-start-color:var(--sn-color-glass-border);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-slot=sn-inspector][data-family=macos]) .body{gap:.75rem}:host([data-slot=sn-inspector][data-skin=mac]){margin:.5rem .5rem .5rem 0;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-inspector-section][data-family=macos]){padding-block-start:.625rem;border-block-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector-section][data-family=macos]) h3{font-weight:700}:host([data-slot=sn-inspector-section][data-family=macos]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=gtk]),:host([data-slot=sn-inspector][data-family=web]){background:var(--sn-color-sidebar)}:host([data-slot=sn-inspector][data-skin=gtk]) header,:host([data-slot=sn-inspector][data-family=web]) header{justify-content:center;min-block-size:2.875rem;padding:0 .75rem}:host([data-slot=sn-inspector][data-skin=gtk]) h2,:host([data-slot=sn-inspector][data-family=web]) h2{flex:0 1 auto;font-weight:700;text-align:center}:host([data-slot=sn-inspector][data-skin=gtk]) .preview,:host([data-slot=sn-inspector][data-family=web]) .preview{font-size:1.25rem;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=gtk]) .body,:host([data-slot=sn-inspector][data-family=web]) .body{gap:1.5rem;padding:.75rem}:host([data-slot=sn-inspector-section][data-skin=gtk]) h3,:host([data-slot=sn-inspector-section][data-family=web]) h3{margin-block-end:.75rem;font-size:var(--sn-font-size);font-weight:700;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=qt]){background:var(--sn-color-bg);border-inline-start-color:var(--sn-color-border)}:host([data-slot=sn-inspector][data-skin=qt]) header{flex-direction:column;gap:.5rem;padding:1.5rem 1rem .75rem}:host([data-slot=sn-inspector][data-skin=qt]) h2{text-align:center}:host([data-slot=sn-inspector][data-skin=qt]) .preview{font-size:7rem;color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector][data-skin=qt]) .body{gap:.75rem}:host([data-slot=sn-inspector-section][data-skin=qt]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=cros]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-skin=cros]) header{padding:1.5rem 1.5rem 1rem}:host([data-slot=sn-inspector][data-skin=cros]) h2{font-size:1.375em;font-weight:400}:host([data-slot=sn-inspector][data-skin=cros]) .preview{font-size:1.5rem}:host([data-slot=sn-inspector][data-skin=cros]) .body{gap:1.5rem;padding:0 1.5rem 1.5rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector][data-skin=cros]){border-start-start-radius:var(--sn-radius-overlay);border-end-start-radius:var(--sn-radius-overlay)}}:host([data-slot=sn-inspector-section][data-skin=cros]) h3{font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-control)}.close{display:grid;place-items:center;flex:none;inline-size:2.5rem;block-size:2.5rem;margin:-.5rem -.5rem -.5rem 0;padding:0;border:0;border-radius:var(--sn-radius-pill);background:transparent;color:var(--sn-color-fg-muted)}.close svg{inline-size:1.25rem;block-size:1.25rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.close:hover{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}.close:focus-visible{outline:var(--sn-focus-outline);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-inspector]){border-inline-start:1px solid CanvasText}}\n"]
		}]
	}],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}]
	}
});
var SnInspectorSection = class SnInspectorSection {
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	headingId = `sn-inspector-section-${nextId$4++}`;
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnInspectorSection,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnInspectorSection,
		isStandalone: true,
		selector: "sn-inspector-section",
		inputs: { title: {
			classPropertyName: "title",
			publicName: "title",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: {
				"data-slot": "sn-inspector-section",
				"role": "group"
			},
			properties: {
				"attr.aria-labelledby": "title() ? headingId : null",
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		ngImport: i0,
		template: `
    @if (title()) {
      <h3 [id]="headingId">{{ title() }}</h3>
    }
    <div class="rows"><ng-content /></div>
  `,
		isInline: true,
		styles: [":host([data-slot=sn-inspector-layout]){position:relative;display:flex;min-block-size:0;container:sn-inspector-layout/inline-size}:host([data-slot=sn-inspector-layout]) .main{display:flex;flex-direction:column;flex:1;min-inline-size:0;overflow:auto}:host([data-slot=sn-inspector]){display:flex;flex-direction:column;flex:none;inline-size:17.5rem;box-sizing:border-box;overflow-y:auto;background:var(--sn-color-surface-solid);border-inline-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector][hidden]){display:none}header{display:flex;align-items:center;gap:.75rem;padding:1rem 1rem .5rem}h2{flex:1;min-inline-size:0;margin:0;font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong);overflow-wrap:anywhere}.preview{flex:none;font-size:2rem;color:var(--sn-color-accent-text)}:host([data-slot=sn-inspector]) .body{display:flex;flex-direction:column;gap:1rem;padding:.5rem 1rem 1rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector]){position:absolute;inset-block:0;inset-inline-end:0;z-index:1;max-inline-size:85%;box-shadow:var(--sn-shadow-overlay)}}:host([data-slot=sn-inspector-section]){display:block}h3{margin:0 0 .375rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector-section]) .rows{display:flex;flex-direction:column;gap:.5rem}:host([data-slot=sn-inspector-property]){display:flex;flex-direction:column;gap:.125rem}.label{font-size:var(--sn-font-size-small);color:var(--sn-color-fg-muted)}.value{overflow-wrap:anywhere}:host([data-slot=sn-inspector-property][data-family=macos]),:host([data-slot=sn-inspector-property][data-skin=qt]){display:grid;grid-template-columns:5.5rem 1fr;gap:.5rem;align-items:baseline}:host([data-slot=sn-inspector-property][data-family=macos]) .label,:host([data-slot=sn-inspector-property][data-skin=qt]) .label{font-size:inherit;text-align:end}:host([data-slot=sn-inspector-property][data-family=macos]) .label:after,:host([data-slot=sn-inspector-property][data-skin=qt]) .label:after{content:\":\"}:host([data-slot=sn-inspector][data-family=windows]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-family=windows]) header{padding:1.25rem 1.25rem .75rem}:host([data-slot=sn-inspector][data-family=windows]) h2{font-size:var(--sn-font-size-title)}:host([data-slot=sn-inspector][data-family=windows]) .preview{font-size:2.5rem}:host([data-slot=sn-inspector][data-family=windows]) .body{gap:1.25rem;padding:0 1.25rem 1.25rem}:host([data-slot=sn-inspector-section][data-family=windows]) h3{font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-family=macos]){inline-size:16.25rem;background:var(--sn-color-glass);border-inline-start-color:var(--sn-color-glass-border);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-slot=sn-inspector][data-family=macos]) .body{gap:.75rem}:host([data-slot=sn-inspector][data-skin=mac]){margin:.5rem .5rem .5rem 0;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-inspector-section][data-family=macos]){padding-block-start:.625rem;border-block-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector-section][data-family=macos]) h3{font-weight:700}:host([data-slot=sn-inspector-section][data-family=macos]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=gtk]),:host([data-slot=sn-inspector][data-family=web]){background:var(--sn-color-sidebar)}:host([data-slot=sn-inspector][data-skin=gtk]) header,:host([data-slot=sn-inspector][data-family=web]) header{justify-content:center;min-block-size:2.875rem;padding:0 .75rem}:host([data-slot=sn-inspector][data-skin=gtk]) h2,:host([data-slot=sn-inspector][data-family=web]) h2{flex:0 1 auto;font-weight:700;text-align:center}:host([data-slot=sn-inspector][data-skin=gtk]) .preview,:host([data-slot=sn-inspector][data-family=web]) .preview{font-size:1.25rem;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=gtk]) .body,:host([data-slot=sn-inspector][data-family=web]) .body{gap:1.5rem;padding:.75rem}:host([data-slot=sn-inspector-section][data-skin=gtk]) h3,:host([data-slot=sn-inspector-section][data-family=web]) h3{margin-block-end:.75rem;font-size:var(--sn-font-size);font-weight:700;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=qt]){background:var(--sn-color-bg);border-inline-start-color:var(--sn-color-border)}:host([data-slot=sn-inspector][data-skin=qt]) header{flex-direction:column;gap:.5rem;padding:1.5rem 1rem .75rem}:host([data-slot=sn-inspector][data-skin=qt]) h2{text-align:center}:host([data-slot=sn-inspector][data-skin=qt]) .preview{font-size:7rem;color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector][data-skin=qt]) .body{gap:.75rem}:host([data-slot=sn-inspector-section][data-skin=qt]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=cros]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-skin=cros]) header{padding:1.5rem 1.5rem 1rem}:host([data-slot=sn-inspector][data-skin=cros]) h2{font-size:1.375em;font-weight:400}:host([data-slot=sn-inspector][data-skin=cros]) .preview{font-size:1.5rem}:host([data-slot=sn-inspector][data-skin=cros]) .body{gap:1.5rem;padding:0 1.5rem 1.5rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector][data-skin=cros]){border-start-start-radius:var(--sn-radius-overlay);border-end-start-radius:var(--sn-radius-overlay)}}:host([data-slot=sn-inspector-section][data-skin=cros]) h3{font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-control)}.close{display:grid;place-items:center;flex:none;inline-size:2.5rem;block-size:2.5rem;margin:-.5rem -.5rem -.5rem 0;padding:0;border:0;border-radius:var(--sn-radius-pill);background:transparent;color:var(--sn-color-fg-muted)}.close svg{inline-size:1.25rem;block-size:1.25rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.close:hover{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}.close:focus-visible{outline:var(--sn-focus-outline);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-inspector]){border-inline-start:1px solid CanvasText}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnInspectorSection,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-inspector-section",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-inspector-section",
				role: "group",
				"[attr.aria-labelledby]": "title() ? headingId : null",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    @if (title()) {
      <h3 [id]="headingId">{{ title() }}</h3>
    }
    <div class="rows"><ng-content /></div>
  `,
			styles: [":host([data-slot=sn-inspector-layout]){position:relative;display:flex;min-block-size:0;container:sn-inspector-layout/inline-size}:host([data-slot=sn-inspector-layout]) .main{display:flex;flex-direction:column;flex:1;min-inline-size:0;overflow:auto}:host([data-slot=sn-inspector]){display:flex;flex-direction:column;flex:none;inline-size:17.5rem;box-sizing:border-box;overflow-y:auto;background:var(--sn-color-surface-solid);border-inline-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector][hidden]){display:none}header{display:flex;align-items:center;gap:.75rem;padding:1rem 1rem .5rem}h2{flex:1;min-inline-size:0;margin:0;font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong);overflow-wrap:anywhere}.preview{flex:none;font-size:2rem;color:var(--sn-color-accent-text)}:host([data-slot=sn-inspector]) .body{display:flex;flex-direction:column;gap:1rem;padding:.5rem 1rem 1rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector]){position:absolute;inset-block:0;inset-inline-end:0;z-index:1;max-inline-size:85%;box-shadow:var(--sn-shadow-overlay)}}:host([data-slot=sn-inspector-section]){display:block}h3{margin:0 0 .375rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector-section]) .rows{display:flex;flex-direction:column;gap:.5rem}:host([data-slot=sn-inspector-property]){display:flex;flex-direction:column;gap:.125rem}.label{font-size:var(--sn-font-size-small);color:var(--sn-color-fg-muted)}.value{overflow-wrap:anywhere}:host([data-slot=sn-inspector-property][data-family=macos]),:host([data-slot=sn-inspector-property][data-skin=qt]){display:grid;grid-template-columns:5.5rem 1fr;gap:.5rem;align-items:baseline}:host([data-slot=sn-inspector-property][data-family=macos]) .label,:host([data-slot=sn-inspector-property][data-skin=qt]) .label{font-size:inherit;text-align:end}:host([data-slot=sn-inspector-property][data-family=macos]) .label:after,:host([data-slot=sn-inspector-property][data-skin=qt]) .label:after{content:\":\"}:host([data-slot=sn-inspector][data-family=windows]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-family=windows]) header{padding:1.25rem 1.25rem .75rem}:host([data-slot=sn-inspector][data-family=windows]) h2{font-size:var(--sn-font-size-title)}:host([data-slot=sn-inspector][data-family=windows]) .preview{font-size:2.5rem}:host([data-slot=sn-inspector][data-family=windows]) .body{gap:1.25rem;padding:0 1.25rem 1.25rem}:host([data-slot=sn-inspector-section][data-family=windows]) h3{font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-family=macos]){inline-size:16.25rem;background:var(--sn-color-glass);border-inline-start-color:var(--sn-color-glass-border);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-slot=sn-inspector][data-family=macos]) .body{gap:.75rem}:host([data-slot=sn-inspector][data-skin=mac]){margin:.5rem .5rem .5rem 0;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-inspector-section][data-family=macos]){padding-block-start:.625rem;border-block-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector-section][data-family=macos]) h3{font-weight:700}:host([data-slot=sn-inspector-section][data-family=macos]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=gtk]),:host([data-slot=sn-inspector][data-family=web]){background:var(--sn-color-sidebar)}:host([data-slot=sn-inspector][data-skin=gtk]) header,:host([data-slot=sn-inspector][data-family=web]) header{justify-content:center;min-block-size:2.875rem;padding:0 .75rem}:host([data-slot=sn-inspector][data-skin=gtk]) h2,:host([data-slot=sn-inspector][data-family=web]) h2{flex:0 1 auto;font-weight:700;text-align:center}:host([data-slot=sn-inspector][data-skin=gtk]) .preview,:host([data-slot=sn-inspector][data-family=web]) .preview{font-size:1.25rem;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=gtk]) .body,:host([data-slot=sn-inspector][data-family=web]) .body{gap:1.5rem;padding:.75rem}:host([data-slot=sn-inspector-section][data-skin=gtk]) h3,:host([data-slot=sn-inspector-section][data-family=web]) h3{margin-block-end:.75rem;font-size:var(--sn-font-size);font-weight:700;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=qt]){background:var(--sn-color-bg);border-inline-start-color:var(--sn-color-border)}:host([data-slot=sn-inspector][data-skin=qt]) header{flex-direction:column;gap:.5rem;padding:1.5rem 1rem .75rem}:host([data-slot=sn-inspector][data-skin=qt]) h2{text-align:center}:host([data-slot=sn-inspector][data-skin=qt]) .preview{font-size:7rem;color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector][data-skin=qt]) .body{gap:.75rem}:host([data-slot=sn-inspector-section][data-skin=qt]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=cros]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-skin=cros]) header{padding:1.5rem 1.5rem 1rem}:host([data-slot=sn-inspector][data-skin=cros]) h2{font-size:1.375em;font-weight:400}:host([data-slot=sn-inspector][data-skin=cros]) .preview{font-size:1.5rem}:host([data-slot=sn-inspector][data-skin=cros]) .body{gap:1.5rem;padding:0 1.5rem 1.5rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector][data-skin=cros]){border-start-start-radius:var(--sn-radius-overlay);border-end-start-radius:var(--sn-radius-overlay)}}:host([data-slot=sn-inspector-section][data-skin=cros]) h3{font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-control)}.close{display:grid;place-items:center;flex:none;inline-size:2.5rem;block-size:2.5rem;margin:-.5rem -.5rem -.5rem 0;padding:0;border:0;border-radius:var(--sn-radius-pill);background:transparent;color:var(--sn-color-fg-muted)}.close svg{inline-size:1.25rem;block-size:1.25rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.close:hover{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}.close:focus-visible{outline:var(--sn-focus-outline);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-inspector]){border-inline-start:1px solid CanvasText}}\n"]
		}]
	}],
	propDecorators: { title: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "title",
			required: false
		}]
	}] }
});
var SnInspectorProperty = class SnInspectorProperty {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnInspectorProperty,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnInspectorProperty,
		isStandalone: true,
		selector: "sn-inspector-property",
		inputs: { label: {
			classPropertyName: "label",
			publicName: "label",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			attributes: { "data-slot": "sn-inspector-property" },
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		ngImport: i0,
		template: `
    <span class="label">{{ label() }}</span>
    <span class="value"><ng-content /></span>
  `,
		isInline: true,
		styles: [":host([data-slot=sn-inspector-layout]){position:relative;display:flex;min-block-size:0;container:sn-inspector-layout/inline-size}:host([data-slot=sn-inspector-layout]) .main{display:flex;flex-direction:column;flex:1;min-inline-size:0;overflow:auto}:host([data-slot=sn-inspector]){display:flex;flex-direction:column;flex:none;inline-size:17.5rem;box-sizing:border-box;overflow-y:auto;background:var(--sn-color-surface-solid);border-inline-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector][hidden]){display:none}header{display:flex;align-items:center;gap:.75rem;padding:1rem 1rem .5rem}h2{flex:1;min-inline-size:0;margin:0;font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong);overflow-wrap:anywhere}.preview{flex:none;font-size:2rem;color:var(--sn-color-accent-text)}:host([data-slot=sn-inspector]) .body{display:flex;flex-direction:column;gap:1rem;padding:.5rem 1rem 1rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector]){position:absolute;inset-block:0;inset-inline-end:0;z-index:1;max-inline-size:85%;box-shadow:var(--sn-shadow-overlay)}}:host([data-slot=sn-inspector-section]){display:block}h3{margin:0 0 .375rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector-section]) .rows{display:flex;flex-direction:column;gap:.5rem}:host([data-slot=sn-inspector-property]){display:flex;flex-direction:column;gap:.125rem}.label{font-size:var(--sn-font-size-small);color:var(--sn-color-fg-muted)}.value{overflow-wrap:anywhere}:host([data-slot=sn-inspector-property][data-family=macos]),:host([data-slot=sn-inspector-property][data-skin=qt]){display:grid;grid-template-columns:5.5rem 1fr;gap:.5rem;align-items:baseline}:host([data-slot=sn-inspector-property][data-family=macos]) .label,:host([data-slot=sn-inspector-property][data-skin=qt]) .label{font-size:inherit;text-align:end}:host([data-slot=sn-inspector-property][data-family=macos]) .label:after,:host([data-slot=sn-inspector-property][data-skin=qt]) .label:after{content:\":\"}:host([data-slot=sn-inspector][data-family=windows]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-family=windows]) header{padding:1.25rem 1.25rem .75rem}:host([data-slot=sn-inspector][data-family=windows]) h2{font-size:var(--sn-font-size-title)}:host([data-slot=sn-inspector][data-family=windows]) .preview{font-size:2.5rem}:host([data-slot=sn-inspector][data-family=windows]) .body{gap:1.25rem;padding:0 1.25rem 1.25rem}:host([data-slot=sn-inspector-section][data-family=windows]) h3{font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-family=macos]){inline-size:16.25rem;background:var(--sn-color-glass);border-inline-start-color:var(--sn-color-glass-border);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-slot=sn-inspector][data-family=macos]) .body{gap:.75rem}:host([data-slot=sn-inspector][data-skin=mac]){margin:.5rem .5rem .5rem 0;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-inspector-section][data-family=macos]){padding-block-start:.625rem;border-block-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector-section][data-family=macos]) h3{font-weight:700}:host([data-slot=sn-inspector-section][data-family=macos]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=gtk]),:host([data-slot=sn-inspector][data-family=web]){background:var(--sn-color-sidebar)}:host([data-slot=sn-inspector][data-skin=gtk]) header,:host([data-slot=sn-inspector][data-family=web]) header{justify-content:center;min-block-size:2.875rem;padding:0 .75rem}:host([data-slot=sn-inspector][data-skin=gtk]) h2,:host([data-slot=sn-inspector][data-family=web]) h2{flex:0 1 auto;font-weight:700;text-align:center}:host([data-slot=sn-inspector][data-skin=gtk]) .preview,:host([data-slot=sn-inspector][data-family=web]) .preview{font-size:1.25rem;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=gtk]) .body,:host([data-slot=sn-inspector][data-family=web]) .body{gap:1.5rem;padding:.75rem}:host([data-slot=sn-inspector-section][data-skin=gtk]) h3,:host([data-slot=sn-inspector-section][data-family=web]) h3{margin-block-end:.75rem;font-size:var(--sn-font-size);font-weight:700;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=qt]){background:var(--sn-color-bg);border-inline-start-color:var(--sn-color-border)}:host([data-slot=sn-inspector][data-skin=qt]) header{flex-direction:column;gap:.5rem;padding:1.5rem 1rem .75rem}:host([data-slot=sn-inspector][data-skin=qt]) h2{text-align:center}:host([data-slot=sn-inspector][data-skin=qt]) .preview{font-size:7rem;color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector][data-skin=qt]) .body{gap:.75rem}:host([data-slot=sn-inspector-section][data-skin=qt]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=cros]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-skin=cros]) header{padding:1.5rem 1.5rem 1rem}:host([data-slot=sn-inspector][data-skin=cros]) h2{font-size:1.375em;font-weight:400}:host([data-slot=sn-inspector][data-skin=cros]) .preview{font-size:1.5rem}:host([data-slot=sn-inspector][data-skin=cros]) .body{gap:1.5rem;padding:0 1.5rem 1.5rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector][data-skin=cros]){border-start-start-radius:var(--sn-radius-overlay);border-end-start-radius:var(--sn-radius-overlay)}}:host([data-slot=sn-inspector-section][data-skin=cros]) h3{font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-control)}.close{display:grid;place-items:center;flex:none;inline-size:2.5rem;block-size:2.5rem;margin:-.5rem -.5rem -.5rem 0;padding:0;border:0;border-radius:var(--sn-radius-pill);background:transparent;color:var(--sn-color-fg-muted)}.close svg{inline-size:1.25rem;block-size:1.25rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.close:hover{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}.close:focus-visible{outline:var(--sn-focus-outline);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-inspector]){border-inline-start:1px solid CanvasText}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnInspectorProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-inspector-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-inspector-property",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    <span class="label">{{ label() }}</span>
    <span class="value"><ng-content /></span>
  `,
			styles: [":host([data-slot=sn-inspector-layout]){position:relative;display:flex;min-block-size:0;container:sn-inspector-layout/inline-size}:host([data-slot=sn-inspector-layout]) .main{display:flex;flex-direction:column;flex:1;min-inline-size:0;overflow:auto}:host([data-slot=sn-inspector]){display:flex;flex-direction:column;flex:none;inline-size:17.5rem;box-sizing:border-box;overflow-y:auto;background:var(--sn-color-surface-solid);border-inline-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector][hidden]){display:none}header{display:flex;align-items:center;gap:.75rem;padding:1rem 1rem .5rem}h2{flex:1;min-inline-size:0;margin:0;font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-strong);overflow-wrap:anywhere}.preview{flex:none;font-size:2rem;color:var(--sn-color-accent-text)}:host([data-slot=sn-inspector]) .body{display:flex;flex-direction:column;gap:1rem;padding:.5rem 1rem 1rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector]){position:absolute;inset-block:0;inset-inline-end:0;z-index:1;max-inline-size:85%;box-shadow:var(--sn-shadow-overlay)}}:host([data-slot=sn-inspector-section]){display:block}h3{margin:0 0 .375rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector-section]) .rows{display:flex;flex-direction:column;gap:.5rem}:host([data-slot=sn-inspector-property]){display:flex;flex-direction:column;gap:.125rem}.label{font-size:var(--sn-font-size-small);color:var(--sn-color-fg-muted)}.value{overflow-wrap:anywhere}:host([data-slot=sn-inspector-property][data-family=macos]),:host([data-slot=sn-inspector-property][data-skin=qt]){display:grid;grid-template-columns:5.5rem 1fr;gap:.5rem;align-items:baseline}:host([data-slot=sn-inspector-property][data-family=macos]) .label,:host([data-slot=sn-inspector-property][data-skin=qt]) .label{font-size:inherit;text-align:end}:host([data-slot=sn-inspector-property][data-family=macos]) .label:after,:host([data-slot=sn-inspector-property][data-skin=qt]) .label:after{content:\":\"}:host([data-slot=sn-inspector][data-family=windows]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-family=windows]) header{padding:1.25rem 1.25rem .75rem}:host([data-slot=sn-inspector][data-family=windows]) h2{font-size:var(--sn-font-size-title)}:host([data-slot=sn-inspector][data-family=windows]) .preview{font-size:2.5rem}:host([data-slot=sn-inspector][data-family=windows]) .body{gap:1.25rem;padding:0 1.25rem 1.25rem}:host([data-slot=sn-inspector-section][data-family=windows]) h3{font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-family=macos]){inline-size:16.25rem;background:var(--sn-color-glass);border-inline-start-color:var(--sn-color-glass-border);-webkit-backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate));backdrop-filter:blur(var(--sn-material-blur)) saturate(var(--sn-material-saturate))}:host([data-slot=sn-inspector][data-family=macos]) .body{gap:.75rem}:host([data-slot=sn-inspector][data-skin=mac]){margin:.5rem .5rem .5rem 0;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-inspector-section][data-family=macos]){padding-block-start:.625rem;border-block-start:1px solid var(--sn-color-stroke)}:host([data-slot=sn-inspector-section][data-family=macos]) h3{font-weight:700}:host([data-slot=sn-inspector-section][data-family=macos]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=gtk]),:host([data-slot=sn-inspector][data-family=web]){background:var(--sn-color-sidebar)}:host([data-slot=sn-inspector][data-skin=gtk]) header,:host([data-slot=sn-inspector][data-family=web]) header{justify-content:center;min-block-size:2.875rem;padding:0 .75rem}:host([data-slot=sn-inspector][data-skin=gtk]) h2,:host([data-slot=sn-inspector][data-family=web]) h2{flex:0 1 auto;font-weight:700;text-align:center}:host([data-slot=sn-inspector][data-skin=gtk]) .preview,:host([data-slot=sn-inspector][data-family=web]) .preview{font-size:1.25rem;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=gtk]) .body,:host([data-slot=sn-inspector][data-family=web]) .body{gap:1.5rem;padding:.75rem}:host([data-slot=sn-inspector-section][data-skin=gtk]) h3,:host([data-slot=sn-inspector-section][data-family=web]) h3{margin-block-end:.75rem;font-size:var(--sn-font-size);font-weight:700;color:var(--sn-color-fg)}:host([data-slot=sn-inspector][data-skin=qt]){background:var(--sn-color-bg);border-inline-start-color:var(--sn-color-border)}:host([data-slot=sn-inspector][data-skin=qt]) header{flex-direction:column;gap:.5rem;padding:1.5rem 1rem .75rem}:host([data-slot=sn-inspector][data-skin=qt]) h2{text-align:center}:host([data-slot=sn-inspector][data-skin=qt]) .preview{font-size:7rem;color:var(--sn-color-fg-muted)}:host([data-slot=sn-inspector][data-skin=qt]) .body{gap:.75rem}:host([data-slot=sn-inspector-section][data-skin=qt]) .rows{gap:.25rem}:host([data-slot=sn-inspector][data-skin=cros]){inline-size:20rem;background:var(--sn-color-surface)}:host([data-slot=sn-inspector][data-skin=cros]) header{padding:1.5rem 1.5rem 1rem}:host([data-slot=sn-inspector][data-skin=cros]) h2{font-size:1.375em;font-weight:400}:host([data-slot=sn-inspector][data-skin=cros]) .preview{font-size:1.5rem}:host([data-slot=sn-inspector][data-skin=cros]) .body{gap:1.5rem;padding:0 1.5rem 1.5rem}@container sn-inspector-layout (max-width: 40rem){:host([data-slot=sn-inspector][data-skin=cros]){border-start-start-radius:var(--sn-radius-overlay);border-end-start-radius:var(--sn-radius-overlay)}}:host([data-slot=sn-inspector-section][data-skin=cros]) h3{font-size:var(--sn-font-size);font-weight:var(--sn-font-weight-control)}.close{display:grid;place-items:center;flex:none;inline-size:2.5rem;block-size:2.5rem;margin:-.5rem -.5rem -.5rem 0;padding:0;border:0;border-radius:var(--sn-radius-pill);background:transparent;color:var(--sn-color-fg-muted)}.close svg{inline-size:1.25rem;block-size:1.25rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.close:hover{background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}.close:focus-visible{outline:var(--sn-focus-outline);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-inspector]){border-inline-start:1px solid CanvasText}}\n"]
		}]
	}],
	propDecorators: { label: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "label",
			required: true
		}]
	}] }
});
const SnInspectorImports = [
	SnInspectorLayout,
	SnInspector,
	SnInspectorSection,
	SnInspectorProperty
];
let nextId$3 = 0;
var SnSidebarNav = class SnSidebarNav {
	items = contentChildren(forwardRef(() => SnSidebarItem), {
		...ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {},
		descendants: true
	});
	focused = signal(null, ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	tabStop = computed(() => {
		const items = this.items();
		const focused = this.focused();
		if (focused && items.includes(focused)) return focused;
		return items.find((i) => i.active()) ?? items[0] ?? null;
	}, ...ngDevMode ? [{ debugName: "tabStop" }] : /* istanbul ignore next */ []);
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	setFocused(item) {
		this.focused.set(item);
	}
	onKeydown(event) {
		const items = this.items();
		if (!items.length || event.altKey || event.ctrlKey || event.metaKey) return;
		const current = items.findIndex((i) => i.element.contains(event.target));
		const index = nextIndex(event.key, current, items.length);
		if (index === null) return;
		event.preventDefault();
		items[index].element.focus();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnSidebarNav,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.5",
		type: SnSidebarNav,
		isStandalone: true,
		selector: "sn-sidebar-nav",
		host: {
			attributes: {
				"data-slot": "sn-sidebar-nav",
				"role": "navigation"
			},
			listeners: { "keydown": "onKeydown($event)" },
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			},
			classAttribute: "sn-sidebar"
		},
		queries: [{
			propertyName: "items",
			predicate: i0.forwardRef(() => SnSidebarItem),
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `<ng-content />`,
		isInline: true,
		styles: [":host([data-slot=sn-sidebar-nav]){display:flex;flex-direction:column;gap:.125rem;flex:none;inline-size:14.5rem;padding:.5rem;box-sizing:border-box;overflow-y:auto}:host([data-slot=sn-sidebar-section]){display:flex;flex-direction:column;gap:.125rem}:host([data-slot=sn-sidebar-section]) .heading{padding:.75rem .75rem .25rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-item]){position:relative;display:flex;align-items:center;gap:.75em;box-sizing:border-box;inline-size:100%;min-block-size:var(--sn-list-item-height);margin:0;padding:0 .75em;border:0;border-radius:var(--sn-list-item-radius);background:transparent;color:var(--sn-color-fg);font:inherit;text-align:start;text-decoration:none;cursor:default;transition:background-color var(--sn-duration-fast) var(--sn-easing)}:host([data-slot=sn-sidebar-item]:focus-visible){outline:var(--sn-focus-outline);outline-offset:-2px;box-shadow:var(--sn-focus-shadow)}:host([data-slot=sn-sidebar-item]:hover){background:color-mix(in srgb,var(--sn-color-fg) 6%,transparent)}:host([data-slot=sn-sidebar-item][data-active]){background:var(--sn-selection-bg);color:var(--sn-selection-fg)}:host([data-slot=sn-sidebar-item][data-active]):before{content:\"\";position:absolute;inset-inline-start:0;top:50%;inline-size:3px;block-size:1em;translate:0 -50%;border-radius:2px;background:var(--sn-selection-indicator)}.icon{flex:none;font-size:1.15em}.label{flex:1;min-inline-size:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.badge{flex:none;font-size:var(--sn-font-size-small);font-variant-numeric:tabular-nums;color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-section][data-family=windows]) .heading{padding:.875rem .75rem .375rem;font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-sidebar-item][data-family=windows]) .badge{min-inline-size:1rem;padding:0 .3125rem;box-sizing:border-box;border-radius:var(--sn-radius-pill);background:var(--sn-color-primary);color:var(--sn-color-primary-fg);line-height:1rem;text-align:center}:host([data-slot=sn-sidebar-item][data-skin=w10][data-active]):before{top:0;bottom:0;inline-size:.25rem;block-size:auto;translate:none;border-radius:0;background:var(--sn-color-primary)}:host([data-slot=sn-sidebar-nav][data-skin=w10]){padding-inline:0}:host([data-slot=sn-sidebar-nav][data-family=macos]){padding:.75rem .5rem}:host([data-slot=sn-sidebar-nav][data-skin=mac]){margin:.5rem 0 .5rem .5rem;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-sidebar-section][data-family=macos]) .heading{padding:.75rem .625rem .25rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-family=macos]){gap:.5em;padding-inline:.625em}:host([data-slot=sn-sidebar-item][data-family=macos]) .icon{color:var(--sn-color-accent-text)}:host([data-slot=sn-sidebar-nav][data-skin=gtk]),:host([data-slot=sn-sidebar-nav][data-family=web]){padding:.375rem}:host([data-slot=sn-sidebar-section][data-skin=gtk]) .heading,:host([data-slot=sn-sidebar-section][data-family=web]) .heading{padding:.75rem .75rem .375rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-skin=qt]:hover){background:color-mix(in srgb,var(--sn-color-primary) 12%,transparent);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]){background:var(--sn-row-selected-bg);color:var(--sn-row-selected-fg);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]) .badge{color:inherit}:host([data-slot=sn-sidebar-section][data-skin=qt]) .heading{padding:.625rem .5rem .25rem;font-weight:400}:host([data-slot=sn-sidebar-nav][data-skin=cros]){padding:.75rem}:host([data-slot=sn-sidebar-section][data-skin=cros]) .heading{padding:1.125rem 1rem .5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]){padding-inline:1rem 1.5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]) .badge{font-size:inherit;color:inherit}@media(forced-colors:active){:host([data-slot=sn-sidebar-item][data-active]){background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-slot=sn-sidebar-item][data-active]):before{background:HighlightText!important}:host([data-slot=sn-sidebar-item]:focus-visible){outline:2px solid CanvasText}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnSidebarNav,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-sidebar-nav",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-sidebar-nav",
				class: "sn-sidebar",
				role: "navigation",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()",
				"(keydown)": "onKeydown($event)"
			},
			template: `<ng-content />`,
			styles: [":host([data-slot=sn-sidebar-nav]){display:flex;flex-direction:column;gap:.125rem;flex:none;inline-size:14.5rem;padding:.5rem;box-sizing:border-box;overflow-y:auto}:host([data-slot=sn-sidebar-section]){display:flex;flex-direction:column;gap:.125rem}:host([data-slot=sn-sidebar-section]) .heading{padding:.75rem .75rem .25rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-item]){position:relative;display:flex;align-items:center;gap:.75em;box-sizing:border-box;inline-size:100%;min-block-size:var(--sn-list-item-height);margin:0;padding:0 .75em;border:0;border-radius:var(--sn-list-item-radius);background:transparent;color:var(--sn-color-fg);font:inherit;text-align:start;text-decoration:none;cursor:default;transition:background-color var(--sn-duration-fast) var(--sn-easing)}:host([data-slot=sn-sidebar-item]:focus-visible){outline:var(--sn-focus-outline);outline-offset:-2px;box-shadow:var(--sn-focus-shadow)}:host([data-slot=sn-sidebar-item]:hover){background:color-mix(in srgb,var(--sn-color-fg) 6%,transparent)}:host([data-slot=sn-sidebar-item][data-active]){background:var(--sn-selection-bg);color:var(--sn-selection-fg)}:host([data-slot=sn-sidebar-item][data-active]):before{content:\"\";position:absolute;inset-inline-start:0;top:50%;inline-size:3px;block-size:1em;translate:0 -50%;border-radius:2px;background:var(--sn-selection-indicator)}.icon{flex:none;font-size:1.15em}.label{flex:1;min-inline-size:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.badge{flex:none;font-size:var(--sn-font-size-small);font-variant-numeric:tabular-nums;color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-section][data-family=windows]) .heading{padding:.875rem .75rem .375rem;font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-sidebar-item][data-family=windows]) .badge{min-inline-size:1rem;padding:0 .3125rem;box-sizing:border-box;border-radius:var(--sn-radius-pill);background:var(--sn-color-primary);color:var(--sn-color-primary-fg);line-height:1rem;text-align:center}:host([data-slot=sn-sidebar-item][data-skin=w10][data-active]):before{top:0;bottom:0;inline-size:.25rem;block-size:auto;translate:none;border-radius:0;background:var(--sn-color-primary)}:host([data-slot=sn-sidebar-nav][data-skin=w10]){padding-inline:0}:host([data-slot=sn-sidebar-nav][data-family=macos]){padding:.75rem .5rem}:host([data-slot=sn-sidebar-nav][data-skin=mac]){margin:.5rem 0 .5rem .5rem;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-sidebar-section][data-family=macos]) .heading{padding:.75rem .625rem .25rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-family=macos]){gap:.5em;padding-inline:.625em}:host([data-slot=sn-sidebar-item][data-family=macos]) .icon{color:var(--sn-color-accent-text)}:host([data-slot=sn-sidebar-nav][data-skin=gtk]),:host([data-slot=sn-sidebar-nav][data-family=web]){padding:.375rem}:host([data-slot=sn-sidebar-section][data-skin=gtk]) .heading,:host([data-slot=sn-sidebar-section][data-family=web]) .heading{padding:.75rem .75rem .375rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-skin=qt]:hover){background:color-mix(in srgb,var(--sn-color-primary) 12%,transparent);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]){background:var(--sn-row-selected-bg);color:var(--sn-row-selected-fg);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]) .badge{color:inherit}:host([data-slot=sn-sidebar-section][data-skin=qt]) .heading{padding:.625rem .5rem .25rem;font-weight:400}:host([data-slot=sn-sidebar-nav][data-skin=cros]){padding:.75rem}:host([data-slot=sn-sidebar-section][data-skin=cros]) .heading{padding:1.125rem 1rem .5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]){padding-inline:1rem 1.5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]) .badge{font-size:inherit;color:inherit}@media(forced-colors:active){:host([data-slot=sn-sidebar-item][data-active]){background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-slot=sn-sidebar-item][data-active]):before{background:HighlightText!important}:host([data-slot=sn-sidebar-item]:focus-visible){outline:2px solid CanvasText}}\n"]
		}]
	}],
	propDecorators: { items: [{
		type: i0.ContentChildren,
		args: [forwardRef(() => SnSidebarItem), {
			descendants: true,
			isSignal: true
		}]
	}] }
});
function nextIndex(key, current, count) {
	switch (key) {
		case "ArrowDown": return current < 0 ? 0 : Math.min(current + 1, count - 1);
		case "ArrowUp": return current < 0 ? count - 1 : Math.max(current - 1, 0);
		case "Home": return 0;
		case "End": return count - 1;
		default: return null;
	}
}
var SnSidebarSection = class SnSidebarSection {
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	headingId = `sn-sidebar-section-${nextId$3++}`;
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnSidebarSection,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnSidebarSection,
		isStandalone: true,
		selector: "sn-sidebar-section",
		inputs: { title: {
			classPropertyName: "title",
			publicName: "title",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: {
				"data-slot": "sn-sidebar-section",
				"role": "group"
			},
			properties: {
				"attr.aria-labelledby": "title() ? headingId : null",
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		ngImport: i0,
		template: `
    @if (title()) {
      <div class="heading" [id]="headingId">{{ title() }}</div>
    }
    <ng-content />
  `,
		isInline: true,
		styles: [":host([data-slot=sn-sidebar-nav]){display:flex;flex-direction:column;gap:.125rem;flex:none;inline-size:14.5rem;padding:.5rem;box-sizing:border-box;overflow-y:auto}:host([data-slot=sn-sidebar-section]){display:flex;flex-direction:column;gap:.125rem}:host([data-slot=sn-sidebar-section]) .heading{padding:.75rem .75rem .25rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-item]){position:relative;display:flex;align-items:center;gap:.75em;box-sizing:border-box;inline-size:100%;min-block-size:var(--sn-list-item-height);margin:0;padding:0 .75em;border:0;border-radius:var(--sn-list-item-radius);background:transparent;color:var(--sn-color-fg);font:inherit;text-align:start;text-decoration:none;cursor:default;transition:background-color var(--sn-duration-fast) var(--sn-easing)}:host([data-slot=sn-sidebar-item]:focus-visible){outline:var(--sn-focus-outline);outline-offset:-2px;box-shadow:var(--sn-focus-shadow)}:host([data-slot=sn-sidebar-item]:hover){background:color-mix(in srgb,var(--sn-color-fg) 6%,transparent)}:host([data-slot=sn-sidebar-item][data-active]){background:var(--sn-selection-bg);color:var(--sn-selection-fg)}:host([data-slot=sn-sidebar-item][data-active]):before{content:\"\";position:absolute;inset-inline-start:0;top:50%;inline-size:3px;block-size:1em;translate:0 -50%;border-radius:2px;background:var(--sn-selection-indicator)}.icon{flex:none;font-size:1.15em}.label{flex:1;min-inline-size:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.badge{flex:none;font-size:var(--sn-font-size-small);font-variant-numeric:tabular-nums;color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-section][data-family=windows]) .heading{padding:.875rem .75rem .375rem;font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-sidebar-item][data-family=windows]) .badge{min-inline-size:1rem;padding:0 .3125rem;box-sizing:border-box;border-radius:var(--sn-radius-pill);background:var(--sn-color-primary);color:var(--sn-color-primary-fg);line-height:1rem;text-align:center}:host([data-slot=sn-sidebar-item][data-skin=w10][data-active]):before{top:0;bottom:0;inline-size:.25rem;block-size:auto;translate:none;border-radius:0;background:var(--sn-color-primary)}:host([data-slot=sn-sidebar-nav][data-skin=w10]){padding-inline:0}:host([data-slot=sn-sidebar-nav][data-family=macos]){padding:.75rem .5rem}:host([data-slot=sn-sidebar-nav][data-skin=mac]){margin:.5rem 0 .5rem .5rem;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-sidebar-section][data-family=macos]) .heading{padding:.75rem .625rem .25rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-family=macos]){gap:.5em;padding-inline:.625em}:host([data-slot=sn-sidebar-item][data-family=macos]) .icon{color:var(--sn-color-accent-text)}:host([data-slot=sn-sidebar-nav][data-skin=gtk]),:host([data-slot=sn-sidebar-nav][data-family=web]){padding:.375rem}:host([data-slot=sn-sidebar-section][data-skin=gtk]) .heading,:host([data-slot=sn-sidebar-section][data-family=web]) .heading{padding:.75rem .75rem .375rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-skin=qt]:hover){background:color-mix(in srgb,var(--sn-color-primary) 12%,transparent);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]){background:var(--sn-row-selected-bg);color:var(--sn-row-selected-fg);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]) .badge{color:inherit}:host([data-slot=sn-sidebar-section][data-skin=qt]) .heading{padding:.625rem .5rem .25rem;font-weight:400}:host([data-slot=sn-sidebar-nav][data-skin=cros]){padding:.75rem}:host([data-slot=sn-sidebar-section][data-skin=cros]) .heading{padding:1.125rem 1rem .5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]){padding-inline:1rem 1.5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]) .badge{font-size:inherit;color:inherit}@media(forced-colors:active){:host([data-slot=sn-sidebar-item][data-active]){background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-slot=sn-sidebar-item][data-active]):before{background:HighlightText!important}:host([data-slot=sn-sidebar-item]:focus-visible){outline:2px solid CanvasText}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnSidebarSection,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-sidebar-section",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-sidebar-section",
				role: "group",
				"[attr.aria-labelledby]": "title() ? headingId : null",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    @if (title()) {
      <div class="heading" [id]="headingId">{{ title() }}</div>
    }
    <ng-content />
  `,
			styles: [":host([data-slot=sn-sidebar-nav]){display:flex;flex-direction:column;gap:.125rem;flex:none;inline-size:14.5rem;padding:.5rem;box-sizing:border-box;overflow-y:auto}:host([data-slot=sn-sidebar-section]){display:flex;flex-direction:column;gap:.125rem}:host([data-slot=sn-sidebar-section]) .heading{padding:.75rem .75rem .25rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-item]){position:relative;display:flex;align-items:center;gap:.75em;box-sizing:border-box;inline-size:100%;min-block-size:var(--sn-list-item-height);margin:0;padding:0 .75em;border:0;border-radius:var(--sn-list-item-radius);background:transparent;color:var(--sn-color-fg);font:inherit;text-align:start;text-decoration:none;cursor:default;transition:background-color var(--sn-duration-fast) var(--sn-easing)}:host([data-slot=sn-sidebar-item]:focus-visible){outline:var(--sn-focus-outline);outline-offset:-2px;box-shadow:var(--sn-focus-shadow)}:host([data-slot=sn-sidebar-item]:hover){background:color-mix(in srgb,var(--sn-color-fg) 6%,transparent)}:host([data-slot=sn-sidebar-item][data-active]){background:var(--sn-selection-bg);color:var(--sn-selection-fg)}:host([data-slot=sn-sidebar-item][data-active]):before{content:\"\";position:absolute;inset-inline-start:0;top:50%;inline-size:3px;block-size:1em;translate:0 -50%;border-radius:2px;background:var(--sn-selection-indicator)}.icon{flex:none;font-size:1.15em}.label{flex:1;min-inline-size:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.badge{flex:none;font-size:var(--sn-font-size-small);font-variant-numeric:tabular-nums;color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-section][data-family=windows]) .heading{padding:.875rem .75rem .375rem;font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-sidebar-item][data-family=windows]) .badge{min-inline-size:1rem;padding:0 .3125rem;box-sizing:border-box;border-radius:var(--sn-radius-pill);background:var(--sn-color-primary);color:var(--sn-color-primary-fg);line-height:1rem;text-align:center}:host([data-slot=sn-sidebar-item][data-skin=w10][data-active]):before{top:0;bottom:0;inline-size:.25rem;block-size:auto;translate:none;border-radius:0;background:var(--sn-color-primary)}:host([data-slot=sn-sidebar-nav][data-skin=w10]){padding-inline:0}:host([data-slot=sn-sidebar-nav][data-family=macos]){padding:.75rem .5rem}:host([data-slot=sn-sidebar-nav][data-skin=mac]){margin:.5rem 0 .5rem .5rem;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-sidebar-section][data-family=macos]) .heading{padding:.75rem .625rem .25rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-family=macos]){gap:.5em;padding-inline:.625em}:host([data-slot=sn-sidebar-item][data-family=macos]) .icon{color:var(--sn-color-accent-text)}:host([data-slot=sn-sidebar-nav][data-skin=gtk]),:host([data-slot=sn-sidebar-nav][data-family=web]){padding:.375rem}:host([data-slot=sn-sidebar-section][data-skin=gtk]) .heading,:host([data-slot=sn-sidebar-section][data-family=web]) .heading{padding:.75rem .75rem .375rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-skin=qt]:hover){background:color-mix(in srgb,var(--sn-color-primary) 12%,transparent);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]){background:var(--sn-row-selected-bg);color:var(--sn-row-selected-fg);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]) .badge{color:inherit}:host([data-slot=sn-sidebar-section][data-skin=qt]) .heading{padding:.625rem .5rem .25rem;font-weight:400}:host([data-slot=sn-sidebar-nav][data-skin=cros]){padding:.75rem}:host([data-slot=sn-sidebar-section][data-skin=cros]) .heading{padding:1.125rem 1rem .5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]){padding-inline:1rem 1.5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]) .badge{font-size:inherit;color:inherit}@media(forced-colors:active){:host([data-slot=sn-sidebar-item][data-active]){background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-slot=sn-sidebar-item][data-active]):before{background:HighlightText!important}:host([data-slot=sn-sidebar-item]:focus-visible){outline:2px solid CanvasText}}\n"]
		}]
	}],
	propDecorators: { title: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "title",
			required: false
		}]
	}] }
});
var SnSidebarItem = class SnSidebarItem {
	active = input(false, {
		...ngDevMode ? { debugName: "active" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	icon = input("", ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	badge = input("", ...ngDevMode ? [{ debugName: "badge" }] : /* istanbul ignore next */ []);
	element = inject(ElementRef).nativeElement;
	nav = inject(SnSidebarNav, { optional: true });
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnSidebarItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnSidebarItem,
		isStandalone: true,
		selector: "a[snSidebarItem], button[snSidebarItem]",
		inputs: {
			active: {
				classPropertyName: "active",
				publicName: "active",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			badge: {
				classPropertyName: "badge",
				publicName: "badge",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "sn-sidebar-item" },
			listeners: { "focus": "nav?.setFocused(this)" },
			properties: {
				"attr.aria-current": "active() ? 'page' : null",
				"attr.data-active": "active() ? '' : null",
				"attr.tabindex": "nav?.tabStop() === this ? 0 : nav ? -1 : null",
				"attr.type": "element.localName === 'button' ? 'button' : null",
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			},
			classAttribute: "sn-list-item"
		},
		ngImport: i0,
		template: `
    @if (icon()) {
      <ng-icon class="icon" [name]="icon()" aria-hidden="true" />
    }
    <span class="label"><ng-content /></span>
    @if (badge()) {
      <span class="badge">{{ badge() }}</span>
    }
  `,
		isInline: true,
		styles: [":host([data-slot=sn-sidebar-nav]){display:flex;flex-direction:column;gap:.125rem;flex:none;inline-size:14.5rem;padding:.5rem;box-sizing:border-box;overflow-y:auto}:host([data-slot=sn-sidebar-section]){display:flex;flex-direction:column;gap:.125rem}:host([data-slot=sn-sidebar-section]) .heading{padding:.75rem .75rem .25rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-item]){position:relative;display:flex;align-items:center;gap:.75em;box-sizing:border-box;inline-size:100%;min-block-size:var(--sn-list-item-height);margin:0;padding:0 .75em;border:0;border-radius:var(--sn-list-item-radius);background:transparent;color:var(--sn-color-fg);font:inherit;text-align:start;text-decoration:none;cursor:default;transition:background-color var(--sn-duration-fast) var(--sn-easing)}:host([data-slot=sn-sidebar-item]:focus-visible){outline:var(--sn-focus-outline);outline-offset:-2px;box-shadow:var(--sn-focus-shadow)}:host([data-slot=sn-sidebar-item]:hover){background:color-mix(in srgb,var(--sn-color-fg) 6%,transparent)}:host([data-slot=sn-sidebar-item][data-active]){background:var(--sn-selection-bg);color:var(--sn-selection-fg)}:host([data-slot=sn-sidebar-item][data-active]):before{content:\"\";position:absolute;inset-inline-start:0;top:50%;inline-size:3px;block-size:1em;translate:0 -50%;border-radius:2px;background:var(--sn-selection-indicator)}.icon{flex:none;font-size:1.15em}.label{flex:1;min-inline-size:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.badge{flex:none;font-size:var(--sn-font-size-small);font-variant-numeric:tabular-nums;color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-section][data-family=windows]) .heading{padding:.875rem .75rem .375rem;font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-sidebar-item][data-family=windows]) .badge{min-inline-size:1rem;padding:0 .3125rem;box-sizing:border-box;border-radius:var(--sn-radius-pill);background:var(--sn-color-primary);color:var(--sn-color-primary-fg);line-height:1rem;text-align:center}:host([data-slot=sn-sidebar-item][data-skin=w10][data-active]):before{top:0;bottom:0;inline-size:.25rem;block-size:auto;translate:none;border-radius:0;background:var(--sn-color-primary)}:host([data-slot=sn-sidebar-nav][data-skin=w10]){padding-inline:0}:host([data-slot=sn-sidebar-nav][data-family=macos]){padding:.75rem .5rem}:host([data-slot=sn-sidebar-nav][data-skin=mac]){margin:.5rem 0 .5rem .5rem;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-sidebar-section][data-family=macos]) .heading{padding:.75rem .625rem .25rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-family=macos]){gap:.5em;padding-inline:.625em}:host([data-slot=sn-sidebar-item][data-family=macos]) .icon{color:var(--sn-color-accent-text)}:host([data-slot=sn-sidebar-nav][data-skin=gtk]),:host([data-slot=sn-sidebar-nav][data-family=web]){padding:.375rem}:host([data-slot=sn-sidebar-section][data-skin=gtk]) .heading,:host([data-slot=sn-sidebar-section][data-family=web]) .heading{padding:.75rem .75rem .375rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-skin=qt]:hover){background:color-mix(in srgb,var(--sn-color-primary) 12%,transparent);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]){background:var(--sn-row-selected-bg);color:var(--sn-row-selected-fg);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]) .badge{color:inherit}:host([data-slot=sn-sidebar-section][data-skin=qt]) .heading{padding:.625rem .5rem .25rem;font-weight:400}:host([data-slot=sn-sidebar-nav][data-skin=cros]){padding:.75rem}:host([data-slot=sn-sidebar-section][data-skin=cros]) .heading{padding:1.125rem 1rem .5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]){padding-inline:1rem 1.5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]) .badge{font-size:inherit;color:inherit}@media(forced-colors:active){:host([data-slot=sn-sidebar-item][data-active]){background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-slot=sn-sidebar-item][data-active]):before{background:HighlightText!important}:host([data-slot=sn-sidebar-item]:focus-visible){outline:2px solid CanvasText}}\n"],
		dependencies: [{
			kind: "component",
			type: NgIcon,
			selector: "ng-icon",
			inputs: [
				"name",
				"svg",
				"size",
				"strokeWidth",
				"color"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnSidebarItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "a[snSidebarItem], button[snSidebarItem]",
			imports: [NgIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-sidebar-item",
				class: "sn-list-item",
				"[attr.aria-current]": "active() ? 'page' : null",
				"[attr.data-active]": "active() ? '' : null",
				"[attr.tabindex]": "nav?.tabStop() === this ? 0 : nav ? -1 : null",
				"[attr.type]": "element.localName === 'button' ? 'button' : null",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()",
				"(focus)": "nav?.setFocused(this)"
			},
			template: `
    @if (icon()) {
      <ng-icon class="icon" [name]="icon()" aria-hidden="true" />
    }
    <span class="label"><ng-content /></span>
    @if (badge()) {
      <span class="badge">{{ badge() }}</span>
    }
  `,
			styles: [":host([data-slot=sn-sidebar-nav]){display:flex;flex-direction:column;gap:.125rem;flex:none;inline-size:14.5rem;padding:.5rem;box-sizing:border-box;overflow-y:auto}:host([data-slot=sn-sidebar-section]){display:flex;flex-direction:column;gap:.125rem}:host([data-slot=sn-sidebar-section]) .heading{padding:.75rem .75rem .25rem;font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong);color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-item]){position:relative;display:flex;align-items:center;gap:.75em;box-sizing:border-box;inline-size:100%;min-block-size:var(--sn-list-item-height);margin:0;padding:0 .75em;border:0;border-radius:var(--sn-list-item-radius);background:transparent;color:var(--sn-color-fg);font:inherit;text-align:start;text-decoration:none;cursor:default;transition:background-color var(--sn-duration-fast) var(--sn-easing)}:host([data-slot=sn-sidebar-item]:focus-visible){outline:var(--sn-focus-outline);outline-offset:-2px;box-shadow:var(--sn-focus-shadow)}:host([data-slot=sn-sidebar-item]:hover){background:color-mix(in srgb,var(--sn-color-fg) 6%,transparent)}:host([data-slot=sn-sidebar-item][data-active]){background:var(--sn-selection-bg);color:var(--sn-selection-fg)}:host([data-slot=sn-sidebar-item][data-active]):before{content:\"\";position:absolute;inset-inline-start:0;top:50%;inline-size:3px;block-size:1em;translate:0 -50%;border-radius:2px;background:var(--sn-selection-indicator)}.icon{flex:none;font-size:1.15em}.label{flex:1;min-inline-size:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.badge{flex:none;font-size:var(--sn-font-size-small);font-variant-numeric:tabular-nums;color:var(--sn-color-fg-muted)}:host([data-slot=sn-sidebar-section][data-family=windows]) .heading{padding:.875rem .75rem .375rem;font-size:var(--sn-font-size);color:var(--sn-color-fg)}:host([data-slot=sn-sidebar-item][data-family=windows]) .badge{min-inline-size:1rem;padding:0 .3125rem;box-sizing:border-box;border-radius:var(--sn-radius-pill);background:var(--sn-color-primary);color:var(--sn-color-primary-fg);line-height:1rem;text-align:center}:host([data-slot=sn-sidebar-item][data-skin=w10][data-active]):before{top:0;bottom:0;inline-size:.25rem;block-size:auto;translate:none;border-radius:0;background:var(--sn-color-primary)}:host([data-slot=sn-sidebar-nav][data-skin=w10]){padding-inline:0}:host([data-slot=sn-sidebar-nav][data-family=macos]){padding:.75rem .5rem}:host([data-slot=sn-sidebar-nav][data-skin=mac]){margin:.5rem 0 .5rem .5rem;border:1px solid var(--sn-color-glass-border);border-radius:var(--sn-radius-window);box-shadow:inset 0 1px 0 var(--sn-color-glass-highlight)}:host([data-slot=sn-sidebar-section][data-family=macos]) .heading{padding:.75rem .625rem .25rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-family=macos]){gap:.5em;padding-inline:.625em}:host([data-slot=sn-sidebar-item][data-family=macos]) .icon{color:var(--sn-color-accent-text)}:host([data-slot=sn-sidebar-nav][data-skin=gtk]),:host([data-slot=sn-sidebar-nav][data-family=web]){padding:.375rem}:host([data-slot=sn-sidebar-section][data-skin=gtk]) .heading,:host([data-slot=sn-sidebar-section][data-family=web]) .heading{padding:.75rem .75rem .375rem;font-weight:700}:host([data-slot=sn-sidebar-item][data-skin=qt]:hover){background:color-mix(in srgb,var(--sn-color-primary) 12%,transparent);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]){background:var(--sn-row-selected-bg);color:var(--sn-row-selected-fg);box-shadow:inset 0 0 0 1px var(--sn-color-primary)}:host([data-slot=sn-sidebar-item][data-skin=qt][data-active]) .badge{color:inherit}:host([data-slot=sn-sidebar-section][data-skin=qt]) .heading{padding:.625rem .5rem .25rem;font-weight:400}:host([data-slot=sn-sidebar-nav][data-skin=cros]){padding:.75rem}:host([data-slot=sn-sidebar-section][data-skin=cros]) .heading{padding:1.125rem 1rem .5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]){padding-inline:1rem 1.5rem;font-weight:var(--sn-font-weight-control)}:host([data-slot=sn-sidebar-item][data-skin=cros]) .badge{font-size:inherit;color:inherit}@media(forced-colors:active){:host([data-slot=sn-sidebar-item][data-active]){background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-slot=sn-sidebar-item][data-active]):before{background:HighlightText!important}:host([data-slot=sn-sidebar-item]:focus-visible){outline:2px solid CanvasText}}\n"]
		}]
	}],
	propDecorators: {
		active: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "active",
				required: false
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		badge: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "badge",
				required: false
			}]
		}]
	}
});
const SnSidebarNavImports = [
	SnSidebarNav,
	SnSidebarSection,
	SnSidebarItem
];
let nextId$2 = 0;
var SnAssistantPage = class SnAssistantPage {
	template = inject(TemplateRef);
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	canContinue = input(true, {
		...ngDevMode ? { debugName: "canContinue" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnAssistantPage,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnAssistantPage,
		isStandalone: true,
		selector: "ng-template[snAssistantPage]",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			canContinue: {
				classPropertyName: "canContinue",
				publicName: "canContinue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnAssistantPage,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[snAssistantPage]" }]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		canContinue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canContinue",
				required: false
			}]
		}]
	}
});
const LABELS = {
	windows: {
		back: "Back",
		next: "Next",
		finish: "Finish",
		cancel: "Cancel"
	},
	macos: {
		back: "Go Back",
		next: "Continue",
		finish: "Done",
		cancel: "Cancel"
	},
	linux: {
		back: "Back",
		next: "Next",
		finish: "Done",
		cancel: "Cancel"
	},
	chromeos: {
		back: "Back",
		next: "Next",
		finish: "Done",
		cancel: "Cancel"
	},
	web: {
		back: "Back",
		next: "Next",
		finish: "Done",
		cancel: "Cancel"
	}
};
var SnAssistant = class SnAssistant {
	step = model(0, ...ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []);
	cancelable = input(true, {
		...ngDevMode ? { debugName: "cancelable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	backLabel = input("", ...ngDevMode ? [{ debugName: "backLabel" }] : /* istanbul ignore next */ []);
	nextLabel = input("", ...ngDevMode ? [{ debugName: "nextLabel" }] : /* istanbul ignore next */ []);
	finishLabel = input("", ...ngDevMode ? [{ debugName: "finishLabel" }] : /* istanbul ignore next */ []);
	cancelLabel = input("", ...ngDevMode ? [{ debugName: "cancelLabel" }] : /* istanbul ignore next */ []);
	progressLabel = input("Step {current} of {total}", ...ngDevMode ? [{ debugName: "progressLabel" }] : /* istanbul ignore next */ []);
	finish = output();
	cancel = output();
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	words = computed(() => LABELS[this.family()], ...ngDevMode ? [{ debugName: "words" }] : /* istanbul ignore next */ []);
	pages = contentChildren(SnAssistantPage, ...ngDevMode ? [{ debugName: "pages" }] : /* istanbul ignore next */ []);
	current = computed(() => Math.min(Math.max(this.step(), 0), Math.max(this.pages().length - 1, 0)), ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	page = computed(() => this.pages()[this.current()] ?? null, ...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	last = computed(() => this.current() >= this.pages().length - 1, ...ngDevMode ? [{ debugName: "last" }] : /* istanbul ignore next */ []);
	showDots = computed(() => (this.skin() === "gtk" || this.skin() === "cros" || this.family() === "web") && this.pages().length > 1, ...ngDevMode ? [{ debugName: "showDots" }] : /* istanbul ignore next */ []);
	progressText = computed(() => this.progressLabel().replace("{current}", String(this.current() + 1)).replace("{total}", String(this.pages().length)), ...ngDevMode ? [{ debugName: "progressText" }] : /* istanbul ignore next */ []);
	headingId = `sn-assistant-heading-${nextId$2++}`;
	heading = viewChild.required("heading", ...ngDevMode ? [{ debugName: "heading" }] : /* istanbul ignore next */ []);
	host = inject(ElementRef).nativeElement;
	constructor() {
		let first = true;
		afterRenderEffect(() => {
			this.current();
			if (first) {
				first = false;
				return;
			}
			untracked(() => {
				const active = this.host.ownerDocument.activeElement;
				if (!active || active === this.host.ownerDocument.body || this.host.contains(active)) this.heading().nativeElement.focus();
			});
		});
	}
	next() {
		if (!this.page()?.canContinue()) return;
		if (this.last()) this.finish.emit();
		else this.step.set(this.current() + 1);
	}
	back() {
		if (this.current() > 0) this.step.set(this.current() - 1);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnAssistant,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnAssistant,
		isStandalone: true,
		selector: "sn-assistant",
		inputs: {
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cancelable: {
				classPropertyName: "cancelable",
				publicName: "cancelable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			backLabel: {
				classPropertyName: "backLabel",
				publicName: "backLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			nextLabel: {
				classPropertyName: "nextLabel",
				publicName: "nextLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			finishLabel: {
				classPropertyName: "finishLabel",
				publicName: "finishLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cancelLabel: {
				classPropertyName: "cancelLabel",
				publicName: "cancelLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			progressLabel: {
				classPropertyName: "progressLabel",
				publicName: "progressLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			step: "stepChange",
			finish: "finish",
			cancel: "cancel"
		},
		host: {
			attributes: { "data-slot": "sn-assistant" },
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		queries: [{
			propertyName: "pages",
			predicate: SnAssistantPage,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "heading",
			first: true,
			predicate: ["heading"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @if (skin() === 'qt') {
      <ol class="steps">
        @for (page of pages(); track page; let i = $index) {
          <li [attr.aria-current]="i === current() ? 'step' : null" [attr.data-done]="i < current() ? '' : null">{{ page.title() }}</li>
        }
      </ol>
    }
    <div class="main">
      <div class="head">
        @if (family() === 'windows' && pages().length > 1) {
          <span class="progress">{{ progressText() }}</span>
        }
        <h2 #heading class="page-title" tabindex="-1" [id]="headingId">{{ page()?.title() }}</h2>
      </div>
      <div class="page" role="group" [attr.aria-labelledby]="headingId">
        @if (page(); as p) {
          <ng-container [ngTemplateOutlet]="p.template" />
        }
      </div>
      @if (showDots()) {
        <div class="dots" aria-hidden="true">
          @for (page of pages(); track page; let i = $index) {
            <span class="dot" [attr.data-current]="i === current() ? '' : null"></span>
          }
        </div>
      }
      <div class="nav">
        @if (cancelable()) {
          <button type="button" data-slot="button" class="sn-assistant-button cancel border-border" (click)="cancel.emit()">
            {{ cancelLabel() || words().cancel }}
          </button>
        }
        @if (current() > 0) {
          <button type="button" data-slot="button" class="sn-assistant-button back border-border" (click)="back()">
            {{ backLabel() || words().back }}
          </button>
        }
        <button
          type="button"
          data-slot="button"
          class="sn-assistant-button next bg-primary"
          [disabled]="!page()?.canContinue()"
          (click)="next()"
        >
          {{ last() ? finishLabel() || words().finish : nextLabel() || words().next }}
        </button>
      </div>
    </div>
  `,
		isInline: true,
		styles: ["@charset \"UTF-8\";:host{display:flex;gap:1.5rem;min-width:0;color:var(--sn-color-fg);font-family:var(--sn-font-sans);font-size:var(--sn-font-size);line-height:var(--sn-line-height)}.main{display:grid;grid-template-areas:\"head\" \"page\" \"dots\" \"nav\";grid-template-rows:auto 1fr auto auto;flex:1;gap:1rem;min-width:0}.head{grid-area:head;display:flex;flex-direction:column;gap:.25rem}.page-title{margin:0;font-size:var(--sn-font-size-title);font-weight:var(--sn-font-weight-strong);outline:none}.progress{color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small)}.page{grid-area:page;display:flex;flex-direction:column;gap:.75rem;min-width:0}.dots{grid-area:dots;display:flex;justify-content:center;gap:.5rem}.dot{width:.4375rem;height:.4375rem;border-radius:50%;background:color-mix(in srgb,var(--sn-color-fg) 25%,transparent)}.dot[data-current]{background:var(--sn-color-fg)}.nav{grid-area:nav;display:flex;justify-content:flex-end;gap:.5rem}@layer spartan-native.base{.sn-assistant-button{display:inline-flex;align-items:center;justify-content:center;min-height:var(--sn-control-height);padding-inline:var(--sn-control-padding-x, .75rem);border:1px solid var(--sn-color-border);border-radius:var(--sn-radius-control);background:var(--sn-color-control, var(--sn-color-bg));color:var(--sn-color-fg);font:inherit;font-weight:var(--sn-font-weight-control);white-space:nowrap}.sn-assistant-button.bg-primary{border-color:transparent;background:var(--sn-color-primary);color:var(--sn-color-primary-fg)}.sn-assistant-button:disabled{opacity:.5}.sn-assistant-button:focus-visible{outline:var(--sn-focus-outline);outline-offset:var(--sn-focus-offset)}}:host([data-family=windows]) .back{order:1}:host([data-family=windows]) .next{order:2}:host([data-family=windows]) .cancel{order:3;margin-inline-start:.5rem}:host([data-family=macos]) .head{align-items:center;text-align:center}:host([data-family=macos]) .page-title{font-size:calc(var(--sn-font-size) * 1.85);font-weight:700}:host([data-family=macos]) .cancel{margin-inline-end:auto}:host([data-skin=gtk]) .main,:host([data-family=web]) .main{grid-template-areas:\"nav\" \"page\" \"dots\";grid-template-rows:auto 1fr auto}:host([data-skin=gtk]) .head,:host([data-family=web]) .head{grid-area:nav;align-items:center;align-self:center;pointer-events:none}:host([data-skin=gtk]) .page-title,:host([data-family=web]) .page-title{font-size:var(--sn-font-size);font-weight:700}:host([data-skin=gtk]) .nav,:host([data-family=web]) .nav{justify-content:space-between}:host([data-skin=gtk]) .cancel:has(+.back),:host([data-family=web]) .cancel:has(+.back){display:none}:host([data-skin=gtk]) .next,:host([data-family=web]) .next{margin-inline-start:auto}.steps{display:none}:host([data-skin=qt]) .steps{display:flex;flex-direction:column;gap:.375rem;margin:0;padding:.75rem 1.5rem .75rem 0;border-inline-end:1px solid var(--sn-color-border);list-style:none;color:var(--sn-color-fg-muted)}:host([data-skin=qt]) .steps [aria-current=step]{color:var(--sn-color-fg);font-weight:var(--sn-font-weight-strong)}:host([data-skin=qt]) .steps [data-done]:before{content:\"\\2713  \"}:host([data-skin=qt]) .back{order:1}:host([data-skin=qt]) .next{order:2}:host([data-skin=qt]) .cancel{order:3}:host([data-skin=cros]) .page-title{font-size:1.75rem;font-weight:400}:host([data-skin=cros]) .cancel{margin-inline-end:auto}\n"],
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnAssistant,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-assistant",
			imports: [NgTemplateOutlet],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-assistant",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: `
    @if (skin() === 'qt') {
      <ol class="steps">
        @for (page of pages(); track page; let i = $index) {
          <li [attr.aria-current]="i === current() ? 'step' : null" [attr.data-done]="i < current() ? '' : null">{{ page.title() }}</li>
        }
      </ol>
    }
    <div class="main">
      <div class="head">
        @if (family() === 'windows' && pages().length > 1) {
          <span class="progress">{{ progressText() }}</span>
        }
        <h2 #heading class="page-title" tabindex="-1" [id]="headingId">{{ page()?.title() }}</h2>
      </div>
      <div class="page" role="group" [attr.aria-labelledby]="headingId">
        @if (page(); as p) {
          <ng-container [ngTemplateOutlet]="p.template" />
        }
      </div>
      @if (showDots()) {
        <div class="dots" aria-hidden="true">
          @for (page of pages(); track page; let i = $index) {
            <span class="dot" [attr.data-current]="i === current() ? '' : null"></span>
          }
        </div>
      }
      <div class="nav">
        @if (cancelable()) {
          <button type="button" data-slot="button" class="sn-assistant-button cancel border-border" (click)="cancel.emit()">
            {{ cancelLabel() || words().cancel }}
          </button>
        }
        @if (current() > 0) {
          <button type="button" data-slot="button" class="sn-assistant-button back border-border" (click)="back()">
            {{ backLabel() || words().back }}
          </button>
        }
        <button
          type="button"
          data-slot="button"
          class="sn-assistant-button next bg-primary"
          [disabled]="!page()?.canContinue()"
          (click)="next()"
        >
          {{ last() ? finishLabel() || words().finish : nextLabel() || words().next }}
        </button>
      </div>
    </div>
  `,
			styles: ["@charset \"UTF-8\";:host{display:flex;gap:1.5rem;min-width:0;color:var(--sn-color-fg);font-family:var(--sn-font-sans);font-size:var(--sn-font-size);line-height:var(--sn-line-height)}.main{display:grid;grid-template-areas:\"head\" \"page\" \"dots\" \"nav\";grid-template-rows:auto 1fr auto auto;flex:1;gap:1rem;min-width:0}.head{grid-area:head;display:flex;flex-direction:column;gap:.25rem}.page-title{margin:0;font-size:var(--sn-font-size-title);font-weight:var(--sn-font-weight-strong);outline:none}.progress{color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small)}.page{grid-area:page;display:flex;flex-direction:column;gap:.75rem;min-width:0}.dots{grid-area:dots;display:flex;justify-content:center;gap:.5rem}.dot{width:.4375rem;height:.4375rem;border-radius:50%;background:color-mix(in srgb,var(--sn-color-fg) 25%,transparent)}.dot[data-current]{background:var(--sn-color-fg)}.nav{grid-area:nav;display:flex;justify-content:flex-end;gap:.5rem}@layer spartan-native.base{.sn-assistant-button{display:inline-flex;align-items:center;justify-content:center;min-height:var(--sn-control-height);padding-inline:var(--sn-control-padding-x, .75rem);border:1px solid var(--sn-color-border);border-radius:var(--sn-radius-control);background:var(--sn-color-control, var(--sn-color-bg));color:var(--sn-color-fg);font:inherit;font-weight:var(--sn-font-weight-control);white-space:nowrap}.sn-assistant-button.bg-primary{border-color:transparent;background:var(--sn-color-primary);color:var(--sn-color-primary-fg)}.sn-assistant-button:disabled{opacity:.5}.sn-assistant-button:focus-visible{outline:var(--sn-focus-outline);outline-offset:var(--sn-focus-offset)}}:host([data-family=windows]) .back{order:1}:host([data-family=windows]) .next{order:2}:host([data-family=windows]) .cancel{order:3;margin-inline-start:.5rem}:host([data-family=macos]) .head{align-items:center;text-align:center}:host([data-family=macos]) .page-title{font-size:calc(var(--sn-font-size) * 1.85);font-weight:700}:host([data-family=macos]) .cancel{margin-inline-end:auto}:host([data-skin=gtk]) .main,:host([data-family=web]) .main{grid-template-areas:\"nav\" \"page\" \"dots\";grid-template-rows:auto 1fr auto}:host([data-skin=gtk]) .head,:host([data-family=web]) .head{grid-area:nav;align-items:center;align-self:center;pointer-events:none}:host([data-skin=gtk]) .page-title,:host([data-family=web]) .page-title{font-size:var(--sn-font-size);font-weight:700}:host([data-skin=gtk]) .nav,:host([data-family=web]) .nav{justify-content:space-between}:host([data-skin=gtk]) .cancel:has(+.back),:host([data-family=web]) .cancel:has(+.back){display:none}:host([data-skin=gtk]) .next,:host([data-family=web]) .next{margin-inline-start:auto}.steps{display:none}:host([data-skin=qt]) .steps{display:flex;flex-direction:column;gap:.375rem;margin:0;padding:.75rem 1.5rem .75rem 0;border-inline-end:1px solid var(--sn-color-border);list-style:none;color:var(--sn-color-fg-muted)}:host([data-skin=qt]) .steps [aria-current=step]{color:var(--sn-color-fg);font-weight:var(--sn-font-weight-strong)}:host([data-skin=qt]) .steps [data-done]:before{content:\"\\2713  \"}:host([data-skin=qt]) .back{order:1}:host([data-skin=qt]) .next{order:2}:host([data-skin=qt]) .cancel{order:3}:host([data-skin=cros]) .page-title{font-size:1.75rem;font-weight:400}:host([data-skin=cros]) .cancel{margin-inline-end:auto}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["stepChange"]
		}],
		cancelable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cancelable",
				required: false
			}]
		}],
		backLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "backLabel",
				required: false
			}]
		}],
		nextLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "nextLabel",
				required: false
			}]
		}],
		finishLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "finishLabel",
				required: false
			}]
		}],
		cancelLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cancelLabel",
				required: false
			}]
		}],
		progressLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "progressLabel",
				required: false
			}]
		}],
		finish: [{
			type: i0.Output,
			args: ["finish"]
		}],
		cancel: [{
			type: i0.Output,
			args: ["cancel"]
		}],
		pages: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => SnAssistantPage), { isSignal: true }]
		}],
		heading: [{
			type: i0.ViewChild,
			args: ["heading", { isSignal: true }]
		}]
	}
});
const SnAssistantImports = [SnAssistant, SnAssistantPage];
var SnChecklist = class SnChecklist {
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnChecklist,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: SnChecklist,
		isStandalone: true,
		selector: "sn-checklist",
		host: {
			attributes: {
				"data-slot": "sn-checklist",
				"role": "list"
			},
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()"
			}
		},
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		styles: [":host([data-slot=sn-checklist]){display:flex;flex-direction:column;counter-reset:sn-checklist;color:var(--sn-color-fg)}:host([data-slot=sn-checklist-item]){display:grid;grid-template-columns:auto 1fr auto;align-items:start;gap:.75rem;padding-block:.75rem;counter-increment:sn-checklist}:host([data-slot=sn-checklist]) ::ng-deep>[data-slot=sn-checklist-item]+[data-slot=sn-checklist-item]{border-top:1px solid var(--sn-color-border)}.marker{display:grid;place-items:center;width:1.5rem;height:1.5rem;border:1.5px solid var(--sn-color-border);border-radius:50%;color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong)}.marker:empty:before{content:counter(sn-checklist)}.marker svg{width:1rem;height:1rem;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}:host([data-done]) .marker{border-color:var(--sn-color-success, var(--sn-color-primary));background:var(--sn-color-success, var(--sn-color-primary));color:var(--sn-color-success-fg, var(--sn-color-primary-fg))}.text{display:flex;flex-direction:column;gap:.125rem;min-width:0}.title{font-weight:var(--sn-font-weight-strong)}:host([data-done]) .title{color:var(--sn-color-fg-muted)}.state{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}.description{color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small)}.description:empty{display:none}.action:empty{display:none}:host([data-done]:not([data-keep-action])) .action{display:none}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnChecklist,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-checklist",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-checklist",
				role: "list",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()"
			},
			template: "<ng-content />",
			styles: [":host([data-slot=sn-checklist]){display:flex;flex-direction:column;counter-reset:sn-checklist;color:var(--sn-color-fg)}:host([data-slot=sn-checklist-item]){display:grid;grid-template-columns:auto 1fr auto;align-items:start;gap:.75rem;padding-block:.75rem;counter-increment:sn-checklist}:host([data-slot=sn-checklist]) ::ng-deep>[data-slot=sn-checklist-item]+[data-slot=sn-checklist-item]{border-top:1px solid var(--sn-color-border)}.marker{display:grid;place-items:center;width:1.5rem;height:1.5rem;border:1.5px solid var(--sn-color-border);border-radius:50%;color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong)}.marker:empty:before{content:counter(sn-checklist)}.marker svg{width:1rem;height:1rem;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}:host([data-done]) .marker{border-color:var(--sn-color-success, var(--sn-color-primary));background:var(--sn-color-success, var(--sn-color-primary));color:var(--sn-color-success-fg, var(--sn-color-primary-fg))}.text{display:flex;flex-direction:column;gap:.125rem;min-width:0}.title{font-weight:var(--sn-font-weight-strong)}:host([data-done]) .title{color:var(--sn-color-fg-muted)}.state{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}.description{color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small)}.description:empty{display:none}.action:empty{display:none}:host([data-done]:not([data-keep-action])) .action{display:none}\n"]
		}]
	}]
});
var SnChecklistItem = class SnChecklistItem {
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	done = input(false, {
		...ngDevMode ? { debugName: "done" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	keepAction = input(false, {
		...ngDevMode ? { debugName: "keepAction" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	doneLabel = input("done", ...ngDevMode ? [{ debugName: "doneLabel" }] : /* istanbul ignore next */ []);
	todoLabel = input("to do", ...ngDevMode ? [{ debugName: "todoLabel" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnChecklistItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnChecklistItem,
		isStandalone: true,
		selector: "sn-checklist-item",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			done: {
				classPropertyName: "done",
				publicName: "done",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			keepAction: {
				classPropertyName: "keepAction",
				publicName: "keepAction",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			doneLabel: {
				classPropertyName: "doneLabel",
				publicName: "doneLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			todoLabel: {
				classPropertyName: "todoLabel",
				publicName: "todoLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: {
				"data-slot": "sn-checklist-item",
				"role": "listitem"
			},
			properties: {
				"attr.data-done": "done() ? \"\" : null",
				"attr.data-keep-action": "keepAction() ? \"\" : null"
			}
		},
		ngImport: i0,
		template: `
    <span class="marker" aria-hidden="true">
      @if (done()) {
        <svg viewBox="0 0 16 16"><path d="M3.5 8.5l3 3 6-7" /></svg>
      }
    </span>
    <div class="text">
      <span class="title">{{ title() }}<span class="state"> ({{ done() ? doneLabel() : todoLabel() }})</span></span>
      <div class="description"><ng-content /></div>
    </div>
    <div class="action"><ng-content select="[snChecklistAction]" /></div>
  `,
		isInline: true,
		styles: [":host([data-slot=sn-checklist]){display:flex;flex-direction:column;counter-reset:sn-checklist;color:var(--sn-color-fg)}:host([data-slot=sn-checklist-item]){display:grid;grid-template-columns:auto 1fr auto;align-items:start;gap:.75rem;padding-block:.75rem;counter-increment:sn-checklist}:host([data-slot=sn-checklist]) ::ng-deep>[data-slot=sn-checklist-item]+[data-slot=sn-checklist-item]{border-top:1px solid var(--sn-color-border)}.marker{display:grid;place-items:center;width:1.5rem;height:1.5rem;border:1.5px solid var(--sn-color-border);border-radius:50%;color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong)}.marker:empty:before{content:counter(sn-checklist)}.marker svg{width:1rem;height:1rem;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}:host([data-done]) .marker{border-color:var(--sn-color-success, var(--sn-color-primary));background:var(--sn-color-success, var(--sn-color-primary));color:var(--sn-color-success-fg, var(--sn-color-primary-fg))}.text{display:flex;flex-direction:column;gap:.125rem;min-width:0}.title{font-weight:var(--sn-font-weight-strong)}:host([data-done]) .title{color:var(--sn-color-fg-muted)}.state{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}.description{color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small)}.description:empty{display:none}.action:empty{display:none}:host([data-done]:not([data-keep-action])) .action{display:none}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnChecklistItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-checklist-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-checklist-item",
				role: "listitem",
				"[attr.data-done]": "done() ? \"\" : null",
				"[attr.data-keep-action]": "keepAction() ? \"\" : null"
			},
			template: `
    <span class="marker" aria-hidden="true">
      @if (done()) {
        <svg viewBox="0 0 16 16"><path d="M3.5 8.5l3 3 6-7" /></svg>
      }
    </span>
    <div class="text">
      <span class="title">{{ title() }}<span class="state"> ({{ done() ? doneLabel() : todoLabel() }})</span></span>
      <div class="description"><ng-content /></div>
    </div>
    <div class="action"><ng-content select="[snChecklistAction]" /></div>
  `,
			styles: [":host([data-slot=sn-checklist]){display:flex;flex-direction:column;counter-reset:sn-checklist;color:var(--sn-color-fg)}:host([data-slot=sn-checklist-item]){display:grid;grid-template-columns:auto 1fr auto;align-items:start;gap:.75rem;padding-block:.75rem;counter-increment:sn-checklist}:host([data-slot=sn-checklist]) ::ng-deep>[data-slot=sn-checklist-item]+[data-slot=sn-checklist-item]{border-top:1px solid var(--sn-color-border)}.marker{display:grid;place-items:center;width:1.5rem;height:1.5rem;border:1.5px solid var(--sn-color-border);border-radius:50%;color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small);font-weight:var(--sn-font-weight-strong)}.marker:empty:before{content:counter(sn-checklist)}.marker svg{width:1rem;height:1rem;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}:host([data-done]) .marker{border-color:var(--sn-color-success, var(--sn-color-primary));background:var(--sn-color-success, var(--sn-color-primary));color:var(--sn-color-success-fg, var(--sn-color-primary-fg))}.text{display:flex;flex-direction:column;gap:.125rem;min-width:0}.title{font-weight:var(--sn-font-weight-strong)}:host([data-done]) .title{color:var(--sn-color-fg-muted)}.state{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}.description{color:var(--sn-color-fg-muted);font-size:var(--sn-font-size-small)}.description:empty{display:none}.action:empty{display:none}:host([data-done]:not([data-keep-action])) .action{display:none}\n"]
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		done: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "done",
				required: false
			}]
		}],
		keepAction: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "keepAction",
				required: false
			}]
		}],
		doneLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "doneLabel",
				required: false
			}]
		}],
		todoLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "todoLabel",
				required: false
			}]
		}]
	}
});
const SnChecklistImports = [SnChecklist, SnChecklistItem];
var SnSplitButtonMenu = class SnSplitButtonMenu {
	template = inject(TemplateRef);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnSplitButtonMenu,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: SnSplitButtonMenu,
		isStandalone: true,
		selector: "ng-template[snSplitButtonMenu]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnSplitButtonMenu,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[snSplitButtonMenu]" }]
	}]
});
const VARIANT_CLASS = {
	standard: "border-border",
	accent: "bg-primary"
};
var SnSplitButton = class SnSplitButton {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	icon = input("", ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	variant = input("standard", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	small = input(false, {
		...ngDevMode ? { debugName: "small" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	menuLabel = input("More options", ...ngDevMode ? [{ debugName: "menuLabel" }] : /* istanbul ignore next */ []);
	triggered = output();
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	menu = contentChild(SnSplitButtonMenu, ...ngDevMode ? [{ debugName: "menu" }] : /* istanbul ignore next */ []);
	trigger = viewChild.required(CdkMenuTrigger, ...ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []);
	partClass = computed(() => [VARIANT_CLASS[this.variant()], this.small() ? "h-8" : ""].join(" ").trim(), ...ngDevMode ? [{ debugName: "partClass" }] : /* istanbul ignore next */ []);
	menuPosition = [
		{
			originX: "end",
			originY: "bottom",
			overlayX: "end",
			overlayY: "top",
			offsetY: 4
		},
		{
			originX: "end",
			originY: "top",
			overlayX: "end",
			overlayY: "bottom",
			offsetY: -4
		},
		{
			originX: "start",
			originY: "bottom",
			overlayX: "start",
			overlayY: "top",
			offsetY: 4
		}
	];
	open() {
		if (!this.menu() || this.disabled()) return;
		const trigger = this.trigger();
		trigger.open();
		trigger.getMenu()?.focusFirstItem("keyboard");
	}
	onActionKeydown(event) {
		if (event.key !== "ArrowDown" || event.ctrlKey || event.metaKey || event.shiftKey) return;
		if (this.family() === "windows" && !event.altKey) return;
		event.preventDefault();
		this.open();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnSplitButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnSplitButton,
		isStandalone: true,
		selector: "sn-split-button",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			small: {
				classPropertyName: "small",
				publicName: "small",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			menuLabel: {
				classPropertyName: "menuLabel",
				publicName: "menuLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { triggered: "triggered" },
		host: {
			attributes: {
				"data-slot": "sn-split-button",
				"role": "group"
			},
			properties: {
				"attr.aria-label": "label()",
				"attr.data-family": "family()",
				"attr.data-skin": "skin()",
				"attr.data-variant": "variant()",
				"attr.data-disabled": "disabled() ? '' : null"
			}
		},
		queries: [{
			propertyName: "menu",
			first: true,
			predicate: SnSplitButtonMenu,
			descendants: true,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "trigger",
			first: true,
			predicate: CdkMenuTrigger,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <button
      type="button"
      data-slot="button"
      class="action"
      [class]="partClass()"
      [disabled]="disabled()"
      (click)="triggered.emit()"
      (keydown)="onActionKeydown($event)"
    >
      @if (icon()) {
        <ng-icon [name]="icon()" aria-hidden="true" />
      }
      <span class="label">{{ label() }}</span>
    </button>
    <button
      type="button"
      data-slot="button"
      class="arrow"
      [class]="partClass()"
      [disabled]="disabled() || !menu()"
      [attr.aria-label]="menuLabel()"
      [attr.title]="menuLabel()"
      [cdkMenuTriggerFor]="menu()?.template ?? null"
      [cdkMenuPosition]="menuPosition"
    >
      <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 6l4 4 4-4" /></svg>
    </button>
  `,
		isInline: true,
		styles: [":host{display:inline-flex;align-items:stretch;vertical-align:middle;flex:none}@layer spartan-native.base{button{position:relative;display:inline-flex;align-items:center;justify-content:center;gap:.5em;margin:0;font:inherit;white-space:nowrap;cursor:default;-webkit-user-select:none;user-select:none}button:focus-visible{z-index:1}button>ng-icon{flex:none;font-size:1.125em}}.arrow{padding-inline:.5em}.arrow svg{width:1em;height:1em;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round}:host(:not([data-family=chromeos])) .action{border-start-end-radius:0;border-end-end-radius:0}:host(:not([data-family=chromeos])) .arrow{margin-inline-start:-1px;border-start-start-radius:0;border-end-start-radius:0}:host(:not([data-family=chromeos])) :is(.action,.arrow):hover{z-index:1}:host([data-variant=accent]:not([data-family=chromeos])) .arrow:before{content:\"\";position:absolute;inset-block:.375em;inset-inline-start:0;width:1px;background:currentColor;opacity:.35}:host([data-family=macos]) .arrow{padding-inline:.375em}:host([data-family=linux]:not([data-skin=qt])) .arrow,:host([data-family=web]) .arrow{padding-inline:.4375em}:host([data-skin=qt]) .arrow{padding-inline:.25em}:host([data-skin=qt]) .arrow svg{width:.75em;height:.75em}:host([data-family=chromeos]){gap:2px}:host([data-family=chromeos]) .action{border-start-end-radius:.25rem;border-end-end-radius:.25rem;padding-inline-end:.75rem}:host([data-family=chromeos]) .arrow{border-start-start-radius:.25rem;border-end-start-radius:.25rem;padding-inline:.75rem .875rem}@media(forced-colors:active){button{border:1px solid ButtonText}.arrow:before{background:ButtonText}}\n"],
		dependencies: [{
			kind: "directive",
			type: CdkMenuTrigger,
			selector: "[cdkMenuTriggerFor]",
			inputs: [
				"cdkMenuTriggerFor",
				"cdkMenuPosition",
				"cdkMenuTriggerData",
				"cdkMenuTriggerTransformOriginOn"
			],
			outputs: ["cdkMenuOpened", "cdkMenuClosed"],
			exportAs: ["cdkMenuTriggerFor"]
		}, {
			kind: "component",
			type: NgIcon,
			selector: "ng-icon",
			inputs: [
				"name",
				"svg",
				"size",
				"strokeWidth",
				"color"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnSplitButton,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-split-button",
			imports: [CdkMenuTrigger, NgIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-split-button",
				role: "group",
				"[attr.aria-label]": "label()",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()",
				"[attr.data-variant]": "variant()",
				"[attr.data-disabled]": "disabled() ? '' : null"
			},
			template: `
    <button
      type="button"
      data-slot="button"
      class="action"
      [class]="partClass()"
      [disabled]="disabled()"
      (click)="triggered.emit()"
      (keydown)="onActionKeydown($event)"
    >
      @if (icon()) {
        <ng-icon [name]="icon()" aria-hidden="true" />
      }
      <span class="label">{{ label() }}</span>
    </button>
    <button
      type="button"
      data-slot="button"
      class="arrow"
      [class]="partClass()"
      [disabled]="disabled() || !menu()"
      [attr.aria-label]="menuLabel()"
      [attr.title]="menuLabel()"
      [cdkMenuTriggerFor]="menu()?.template ?? null"
      [cdkMenuPosition]="menuPosition"
    >
      <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 6l4 4 4-4" /></svg>
    </button>
  `,
			styles: [":host{display:inline-flex;align-items:stretch;vertical-align:middle;flex:none}@layer spartan-native.base{button{position:relative;display:inline-flex;align-items:center;justify-content:center;gap:.5em;margin:0;font:inherit;white-space:nowrap;cursor:default;-webkit-user-select:none;user-select:none}button:focus-visible{z-index:1}button>ng-icon{flex:none;font-size:1.125em}}.arrow{padding-inline:.5em}.arrow svg{width:1em;height:1em;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round}:host(:not([data-family=chromeos])) .action{border-start-end-radius:0;border-end-end-radius:0}:host(:not([data-family=chromeos])) .arrow{margin-inline-start:-1px;border-start-start-radius:0;border-end-start-radius:0}:host(:not([data-family=chromeos])) :is(.action,.arrow):hover{z-index:1}:host([data-variant=accent]:not([data-family=chromeos])) .arrow:before{content:\"\";position:absolute;inset-block:.375em;inset-inline-start:0;width:1px;background:currentColor;opacity:.35}:host([data-family=macos]) .arrow{padding-inline:.375em}:host([data-family=linux]:not([data-skin=qt])) .arrow,:host([data-family=web]) .arrow{padding-inline:.4375em}:host([data-skin=qt]) .arrow{padding-inline:.25em}:host([data-skin=qt]) .arrow svg{width:.75em;height:.75em}:host([data-family=chromeos]){gap:2px}:host([data-family=chromeos]) .action{border-start-end-radius:.25rem;border-end-end-radius:.25rem;padding-inline-end:.75rem}:host([data-family=chromeos]) .arrow{border-start-start-radius:.25rem;border-end-start-radius:.25rem;padding-inline:.75rem .875rem}@media(forced-colors:active){button{border:1px solid ButtonText}.arrow:before{background:ButtonText}}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		small: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "small",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		menuLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "menuLabel",
				required: false
			}]
		}],
		triggered: [{
			type: i0.Output,
			args: ["triggered"]
		}],
		menu: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => SnSplitButtonMenu), { isSignal: true }]
		}],
		trigger: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => CdkMenuTrigger), { isSignal: true }]
		}]
	}
});
const SnSplitButtonImports = [SnSplitButton, SnSplitButtonMenu];
let nextId$1 = 0;
const PLUS_MINUS = [
	"gtk",
	"cros",
	"web"
];
const REPEAT_DELAY_MS = 400;
const REPEAT_INTERVAL_MS = 60;
function evaluateNumberExpression(text) {
	const tokens = text.replace(/,/g, ".").match(/\d*\.?\d+(?:e[+-]?\d+)?|[-+*/()]|\S/gi);
	if (!tokens) return null;
	let pos = 0;
	const peek = () => tokens[pos];
	const primary = () => {
		const token = tokens[pos++];
		if (token === "-") return -primary();
		if (token === "+") return primary();
		if (token === "(") {
			const value = sum();
			if (tokens[pos++] !== ")") throw new Error("missing )");
			return value;
		}
		const value = Number(token);
		if (token === void 0 || !/^[\d.]/.test(token) || Number.isNaN(value)) throw new Error(`unexpected ${token}`);
		return value;
	};
	const product = () => {
		let value = primary();
		while (peek() === "*" || peek() === "/") value = tokens[pos++] === "*" ? value * primary() : value / primary();
		return value;
	};
	const sum = () => {
		let value = product();
		while (peek() === "+" || peek() === "-") value = tokens[pos++] === "+" ? value + product() : value - product();
		return value;
	};
	try {
		const value = sum();
		return pos === tokens.length && Number.isFinite(value) ? value : null;
	} catch {
		return null;
	}
}
function decimalsOf(n) {
	const [, fraction = ""] = String(n).split(".");
	return fraction.length;
}
var SnNumberBox = class SnNumberBox {
	value = model(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	min = input(null, {
		...ngDevMode ? { debugName: "min" } : /* istanbul ignore next */ {},
		transform: optionalNumber
	});
	max = input(null, {
		...ngDevMode ? { debugName: "max" } : /* istanbul ignore next */ {},
		transform: optionalNumber
	});
	step = input(1, {
		...ngDevMode ? { debugName: "step" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	largeStep = input(null, {
		...ngDevMode ? { debugName: "largeStep" } : /* istanbul ignore next */ {},
		transform: optionalNumber
	});
	decimals = input(null, {
		...ngDevMode ? { debugName: "decimals" } : /* istanbul ignore next */ {},
		transform: optionalNumber
	});
	spinButtons = input(true, {
		...ngDevMode ? { debugName: "spinButtons" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	acceptsExpression = input(true, {
		...ngDevMode ? { debugName: "acceptsExpression" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	placeholder = input("", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	inputId = input(`sn-number-box-${nextId$1++}`, ...ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []);
	ariaLabel = input("", ...ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	glyphs = computed(() => PLUS_MINUS.includes(this.skin()) ? "plus-minus" : "chevrons", ...ngDevMode ? [{ debugName: "glyphs" }] : /* istanbul ignore next */ []);
	formDisabled = signal(false, ...ngDevMode ? [{ debugName: "formDisabled" }] : /* istanbul ignore next */ []);
	isDisabled = computed(() => this.disabled() || this.formDisabled(), ...ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []);
	draft = linkedSignal(() => this.format(this.value()), ...ngDevMode ? [{ debugName: "draft" }] : /* istanbul ignore next */ []);
	invalid = computed(() => {
		const text = this.draft().trim();
		return text !== "" && this.parse(text) === null;
	}, ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	atMin = computed(() => this.bound(this.min(), (v, b) => v <= b), ...ngDevMode ? [{ debugName: "atMin" }] : /* istanbul ignore next */ []);
	atMax = computed(() => this.bound(this.max(), (v, b) => v >= b), ...ngDevMode ? [{ debugName: "atMax" }] : /* istanbul ignore next */ []);
	field = viewChild.required("field", ...ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []);
	repeatTimer;
	onChange = () => {};
	onTouched = () => {};
	constructor() {
		inject(DestroyRef).onDestroy(() => this.release());
	}
	stepBy(steps, size = this.step()) {
		if (this.isDisabled()) return;
		this.commit();
		const current = this.value();
		const base = current ?? (steps > 0 ? this.min() ?? 0 : this.max() ?? 0);
		const precision = Math.max(decimalsOf(base), decimalsOf(size));
		const next = current === null ? base : Number((base + steps * size).toFixed(precision));
		this.set(next);
	}
	commit() {
		const text = this.draft().trim();
		if (text === "") return this.set(null);
		const parsed = this.parse(text);
		if (parsed === null) return this.show(this.format(this.value()));
		this.set(parsed);
	}
	focus() {
		this.field().nativeElement.focus();
	}
	onInput(event) {
		this.draft.set(event.target.value);
	}
	onKeydown(event) {
		if (event.altKey || event.ctrlKey || event.metaKey) return;
		const large = this.largeStep() ?? this.step() * 10;
		switch (event.key) {
			case "ArrowUp":
				this.stepBy(1);
				break;
			case "ArrowDown":
				this.stepBy(-1);
				break;
			case "PageUp":
				this.stepBy(1, large);
				break;
			case "PageDown":
				this.stepBy(-1, large);
				break;
			case "Home":
				if (this.min() === null) return;
				this.set(this.min());
				break;
			case "End":
				if (this.max() === null) return;
				this.set(this.max());
				break;
			case "Enter":
				this.commit();
				return;
			case "Escape": {
				const formatted = this.format(this.value());
				if (this.draft() === formatted) return;
				this.show(formatted);
				break;
			}
			default: return;
		}
		event.preventDefault();
	}
	onWheel(event) {
		if (event.deltaY === 0 || this.field().nativeElement !== this.field().nativeElement.ownerDocument.activeElement) return;
		event.preventDefault();
		this.stepBy(event.deltaY < 0 ? 1 : -1);
	}
	press(event, steps) {
		if (event.button !== 0) return;
		event.preventDefault();
		this.field().nativeElement.focus();
		this.release();
		this.stepBy(steps);
		const repeat = () => {
			this.stepBy(steps);
			this.repeatTimer = setTimeout(repeat, REPEAT_INTERVAL_MS);
		};
		this.repeatTimer = setTimeout(repeat, REPEAT_DELAY_MS);
	}
	release() {
		clearTimeout(this.repeatTimer);
		this.repeatTimer = void 0;
	}
	writeValue(value) {
		this.value.set(typeof value === "number" && Number.isFinite(value) ? value : null);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(disabled) {
		this.formDisabled.set(disabled);
	}
	set(value) {
		let next = value;
		if (next !== null) {
			const min = this.min();
			const max = this.max();
			if (min !== null) next = Math.max(min, next);
			if (max !== null) next = Math.min(max, next);
			const decimals = this.decimals();
			if (decimals !== null) next = Number(next.toFixed(decimals));
		}
		this.show(this.format(next));
		if (next === this.value()) return;
		this.value.set(next);
		this.onChange(next);
	}
	show(text) {
		this.draft.set(text);
		const field = this.field().nativeElement;
		if (field.value !== text) field.value = text;
	}
	parse(text) {
		if (this.acceptsExpression()) return evaluateNumberExpression(text);
		const n = Number(text.replace(",", "."));
		return text !== "" && Number.isFinite(n) ? n : null;
	}
	format(value) {
		if (value === null) return "";
		const decimals = this.decimals();
		return decimals === null ? String(value) : value.toFixed(decimals);
	}
	bound(bound, reached) {
		const value = this.value();
		return bound !== null && value !== null && reached(value, bound);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnNumberBox,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnNumberBox,
		isStandalone: true,
		selector: "sn-number-box",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			largeStep: {
				classPropertyName: "largeStep",
				publicName: "largeStep",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimals: {
				classPropertyName: "decimals",
				publicName: "decimals",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			spinButtons: {
				classPropertyName: "spinButtons",
				publicName: "spinButtons",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			acceptsExpression: {
				classPropertyName: "acceptsExpression",
				publicName: "acceptsExpression",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			inputId: {
				classPropertyName: "inputId",
				publicName: "inputId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ariaLabel: {
				classPropertyName: "ariaLabel",
				publicName: "ariaLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: {
			attributes: { "data-slot": "sn-number-box" },
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()",
				"attr.data-disabled": "isDisabled() ? '' : null",
				"attr.data-spin": "spinButtons() ? glyphs() : null"
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => SnNumberBox),
			multi: true
		}],
		viewQueries: [{
			propertyName: "field",
			first: true,
			predicate: ["field"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <input
      #field
      data-slot="input"
      type="text"
      inputmode="decimal"
      autocomplete="off"
      role="spinbutton"
      [id]="inputId()"
      [attr.aria-label]="ariaLabel() || null"
      [attr.aria-valuenow]="value()"
      [attr.aria-valuemin]="min()"
      [attr.aria-valuemax]="max()"
      [attr.aria-invalid]="invalid() || null"
      [attr.placeholder]="placeholder() || null"
      [disabled]="isDisabled()"
      [value]="draft()"
      (input)="onInput($event)"
      (keydown)="onKeydown($event)"
      (blur)="commit(); onTouched()"
      (wheel)="onWheel($event)"
    />
    @if (spinButtons()) {
      <span class="spin" aria-hidden="true">
        <button
          type="button"
          class="up"
          tabindex="-1"
          [disabled]="isDisabled() || atMax()"
          (pointerdown)="press($event, 1)"
          (pointerup)="release()"
          (pointerleave)="release()"
          (pointercancel)="release()"
        >
          @if (glyphs() === 'plus-minus') {
            <svg viewBox="0 0 16 16"><path d="M3.5 8h9M8 3.5v9" /></svg>
          } @else {
            <svg viewBox="0 0 16 16"><path d="M4 10l4-4 4 4" /></svg>
          }
        </button>
        <button
          type="button"
          class="down"
          tabindex="-1"
          [disabled]="isDisabled() || atMin()"
          (pointerdown)="press($event, -1)"
          (pointerup)="release()"
          (pointerleave)="release()"
          (pointercancel)="release()"
        >
          @if (glyphs() === 'plus-minus') {
            <svg viewBox="0 0 16 16"><path d="M3.5 8h9" /></svg>
          } @else {
            <svg viewBox="0 0 16 16"><path d="M4 6l4 4 4-4" /></svg>
          }
        </button>
      </span>
    }
  `,
		isInline: true,
		styles: [":host{position:relative;display:inline-flex;align-items:center;gap:.25rem;inline-size:9rem;max-inline-size:100%;vertical-align:middle}input{flex:1;min-inline-size:0;inline-size:100%;box-sizing:border-box;margin:0;font-variant-numeric:tabular-nums}@layer spartan-native.base{input{font:inherit;color:var(--sn-color-fg)}input:disabled{opacity:.5}}.spin{display:flex;flex:none;-webkit-user-select:none;user-select:none}.spin button{all:unset;box-sizing:border-box;display:grid;place-items:center;color:var(--sn-color-fg-muted);cursor:default}.spin button:hover:not(:disabled){background:var(--sn-color-hover);color:var(--sn-color-fg)}.spin button:active:not(:disabled){background:color-mix(in srgb,var(--sn-color-fg) 12%,transparent)}.spin button:disabled{opacity:.35}.spin button svg{width:.875rem;height:.875rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round}:host(:not([data-family=macos])) .spin{position:absolute;inset-block:0;inset-inline-end:0;align-items:center}:host([data-family=windows][data-spin]) input{padding-inline-end:4.25rem}:host([data-family=windows][data-spin]) .spin{gap:.125rem;padding-inline-end:.25rem}:host([data-family=windows][data-spin]) .spin button{inline-size:1.875rem;block-size:calc(100% - .5rem);border-radius:var(--sn-radius-control)}:host([data-skin=w10]) .spin button{border-radius:0}:host([data-family=macos]) .spin{flex-direction:column;inline-size:1.125rem;block-size:var(--sn-input-height);border-radius:.375rem;overflow:hidden;background:var(--sn-color-surface);box-shadow:0 0 0 .5px var(--sn-color-stroke),0 1px 1px color-mix(in srgb,black 10%,transparent)}:host([data-family=macos]) .spin button{flex:1;color:var(--sn-color-fg)}:host([data-family=macos]) .spin button svg{width:.625rem;height:.625rem;stroke-width:2}:host([data-family=macos]) .spin button+button{border-top:.5px solid var(--sn-color-stroke)}:host([data-skin=mac]) .spin{border-radius:var(--sn-radius-pill);background:var(--sn-color-control);box-shadow:none}:host([data-skin=mac]) .spin button+button{border-top:0}:host([data-family=linux]:not([data-skin=qt])[data-spin]),:host([data-family=web][data-spin]){inline-size:10rem}:host([data-family=linux]:not([data-skin=qt])[data-spin]) input,:host([data-family=web][data-spin]) input{padding-inline-end:5rem}:host([data-family=linux]:not([data-skin=qt])[data-spin]) .spin,:host([data-family=web][data-spin]) .spin{flex-direction:row-reverse}:host([data-family=linux]:not([data-skin=qt])[data-spin]) .spin button,:host([data-family=web][data-spin]) .spin button{inline-size:2.5rem;block-size:100%;color:var(--sn-color-fg);border-inline-start:1px solid color-mix(in srgb,var(--sn-color-fg) 10%,transparent)}:host([data-family=linux]:not([data-skin=qt])[data-spin]) .spin button.up,:host([data-family=web][data-spin]) .spin button.up{border-start-end-radius:var(--sn-radius-input);border-end-end-radius:var(--sn-radius-input)}:host([data-skin=qt][data-spin]) input{padding-inline-end:1.75rem}:host([data-skin=qt][data-spin]) .spin{flex-direction:column;inset-block:1px;inset-inline-end:1px}:host([data-skin=qt][data-spin]) .spin button{flex:1;inline-size:1.375rem;color:var(--sn-color-fg)}:host([data-skin=qt][data-spin]) .spin button svg{width:.6875rem;height:.6875rem;stroke-width:2}:host([data-skin=qt][data-spin]) .spin button:hover:not(:disabled){background:transparent;color:var(--sn-color-primary)}:host([data-family=chromeos][data-spin]){inline-size:10rem}:host([data-family=chromeos][data-spin]) input{padding-inline-end:5rem}:host([data-family=chromeos][data-spin]) .spin{flex-direction:row-reverse;padding-inline-end:.25rem}:host([data-family=chromeos][data-spin]) .spin button{inline-size:2.25rem;block-size:2.25rem;border-radius:50%}:host([data-family=chromeos][data-spin]) .spin button svg{width:1.125rem;height:1.125rem}:host([data-family=chromeos][data-spin]) .spin button:hover:not(:disabled){background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}@media(forced-colors:active){.spin button{color:ButtonText!important}.spin button:hover:not(:disabled){background:Highlight!important;color:HighlightText!important}.spin button:disabled{color:GrayText!important;opacity:1}:host([data-family=macos]) .spin{border:1px solid ButtonText}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnNumberBox,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-number-box",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => SnNumberBox),
				multi: true
			}],
			host: {
				"data-slot": "sn-number-box",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()",
				"[attr.data-disabled]": "isDisabled() ? '' : null",
				"[attr.data-spin]": "spinButtons() ? glyphs() : null"
			},
			template: `
    <input
      #field
      data-slot="input"
      type="text"
      inputmode="decimal"
      autocomplete="off"
      role="spinbutton"
      [id]="inputId()"
      [attr.aria-label]="ariaLabel() || null"
      [attr.aria-valuenow]="value()"
      [attr.aria-valuemin]="min()"
      [attr.aria-valuemax]="max()"
      [attr.aria-invalid]="invalid() || null"
      [attr.placeholder]="placeholder() || null"
      [disabled]="isDisabled()"
      [value]="draft()"
      (input)="onInput($event)"
      (keydown)="onKeydown($event)"
      (blur)="commit(); onTouched()"
      (wheel)="onWheel($event)"
    />
    @if (spinButtons()) {
      <span class="spin" aria-hidden="true">
        <button
          type="button"
          class="up"
          tabindex="-1"
          [disabled]="isDisabled() || atMax()"
          (pointerdown)="press($event, 1)"
          (pointerup)="release()"
          (pointerleave)="release()"
          (pointercancel)="release()"
        >
          @if (glyphs() === 'plus-minus') {
            <svg viewBox="0 0 16 16"><path d="M3.5 8h9M8 3.5v9" /></svg>
          } @else {
            <svg viewBox="0 0 16 16"><path d="M4 10l4-4 4 4" /></svg>
          }
        </button>
        <button
          type="button"
          class="down"
          tabindex="-1"
          [disabled]="isDisabled() || atMin()"
          (pointerdown)="press($event, -1)"
          (pointerup)="release()"
          (pointerleave)="release()"
          (pointercancel)="release()"
        >
          @if (glyphs() === 'plus-minus') {
            <svg viewBox="0 0 16 16"><path d="M3.5 8h9" /></svg>
          } @else {
            <svg viewBox="0 0 16 16"><path d="M4 6l4 4 4-4" /></svg>
          }
        </button>
      </span>
    }
  `,
			styles: [":host{position:relative;display:inline-flex;align-items:center;gap:.25rem;inline-size:9rem;max-inline-size:100%;vertical-align:middle}input{flex:1;min-inline-size:0;inline-size:100%;box-sizing:border-box;margin:0;font-variant-numeric:tabular-nums}@layer spartan-native.base{input{font:inherit;color:var(--sn-color-fg)}input:disabled{opacity:.5}}.spin{display:flex;flex:none;-webkit-user-select:none;user-select:none}.spin button{all:unset;box-sizing:border-box;display:grid;place-items:center;color:var(--sn-color-fg-muted);cursor:default}.spin button:hover:not(:disabled){background:var(--sn-color-hover);color:var(--sn-color-fg)}.spin button:active:not(:disabled){background:color-mix(in srgb,var(--sn-color-fg) 12%,transparent)}.spin button:disabled{opacity:.35}.spin button svg{width:.875rem;height:.875rem;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round}:host(:not([data-family=macos])) .spin{position:absolute;inset-block:0;inset-inline-end:0;align-items:center}:host([data-family=windows][data-spin]) input{padding-inline-end:4.25rem}:host([data-family=windows][data-spin]) .spin{gap:.125rem;padding-inline-end:.25rem}:host([data-family=windows][data-spin]) .spin button{inline-size:1.875rem;block-size:calc(100% - .5rem);border-radius:var(--sn-radius-control)}:host([data-skin=w10]) .spin button{border-radius:0}:host([data-family=macos]) .spin{flex-direction:column;inline-size:1.125rem;block-size:var(--sn-input-height);border-radius:.375rem;overflow:hidden;background:var(--sn-color-surface);box-shadow:0 0 0 .5px var(--sn-color-stroke),0 1px 1px color-mix(in srgb,black 10%,transparent)}:host([data-family=macos]) .spin button{flex:1;color:var(--sn-color-fg)}:host([data-family=macos]) .spin button svg{width:.625rem;height:.625rem;stroke-width:2}:host([data-family=macos]) .spin button+button{border-top:.5px solid var(--sn-color-stroke)}:host([data-skin=mac]) .spin{border-radius:var(--sn-radius-pill);background:var(--sn-color-control);box-shadow:none}:host([data-skin=mac]) .spin button+button{border-top:0}:host([data-family=linux]:not([data-skin=qt])[data-spin]),:host([data-family=web][data-spin]){inline-size:10rem}:host([data-family=linux]:not([data-skin=qt])[data-spin]) input,:host([data-family=web][data-spin]) input{padding-inline-end:5rem}:host([data-family=linux]:not([data-skin=qt])[data-spin]) .spin,:host([data-family=web][data-spin]) .spin{flex-direction:row-reverse}:host([data-family=linux]:not([data-skin=qt])[data-spin]) .spin button,:host([data-family=web][data-spin]) .spin button{inline-size:2.5rem;block-size:100%;color:var(--sn-color-fg);border-inline-start:1px solid color-mix(in srgb,var(--sn-color-fg) 10%,transparent)}:host([data-family=linux]:not([data-skin=qt])[data-spin]) .spin button.up,:host([data-family=web][data-spin]) .spin button.up{border-start-end-radius:var(--sn-radius-input);border-end-end-radius:var(--sn-radius-input)}:host([data-skin=qt][data-spin]) input{padding-inline-end:1.75rem}:host([data-skin=qt][data-spin]) .spin{flex-direction:column;inset-block:1px;inset-inline-end:1px}:host([data-skin=qt][data-spin]) .spin button{flex:1;inline-size:1.375rem;color:var(--sn-color-fg)}:host([data-skin=qt][data-spin]) .spin button svg{width:.6875rem;height:.6875rem;stroke-width:2}:host([data-skin=qt][data-spin]) .spin button:hover:not(:disabled){background:transparent;color:var(--sn-color-primary)}:host([data-family=chromeos][data-spin]){inline-size:10rem}:host([data-family=chromeos][data-spin]) input{padding-inline-end:5rem}:host([data-family=chromeos][data-spin]) .spin{flex-direction:row-reverse;padding-inline-end:.25rem}:host([data-family=chromeos][data-spin]) .spin button{inline-size:2.25rem;block-size:2.25rem;border-radius:50%}:host([data-family=chromeos][data-spin]) .spin button svg{width:1.125rem;height:1.125rem}:host([data-family=chromeos][data-spin]) .spin button:hover:not(:disabled){background:color-mix(in srgb,var(--sn-color-fg) 8%,transparent)}@media(forced-colors:active){.spin button{color:ButtonText!important}.spin button:hover:not(:disabled){background:Highlight!important;color:HighlightText!important}.spin button:disabled{color:GrayText!important;opacity:1}:host([data-family=macos]) .spin{border:1px solid ButtonText}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		largeStep: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "largeStep",
				required: false
			}]
		}],
		decimals: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decimals",
				required: false
			}]
		}],
		spinButtons: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "spinButtons",
				required: false
			}]
		}],
		acceptsExpression: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "acceptsExpression",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		inputId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inputId",
				required: false
			}]
		}],
		ariaLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		field: [{
			type: i0.ViewChild,
			args: ["field", { isSignal: true }]
		}]
	}
});
function optionalNumber(value) {
	if (value === null || value === void 0 || value === "") return null;
	const n = numberAttribute(value, NaN);
	return Number.isNaN(n) ? null : n;
}
const TYPEAHEAD_RESET_MS = 600;
const PAGE = 10;
const TRIANGLE = [
	"mac",
	"macc",
	"gtk",
	"web"
];
function domOrder(a, b) {
	if (a.element === b.element) return 0;
	return a.element.compareDocumentPosition(b.element) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
}
var SnTree = class SnTree {
	multiple = input(false, ...ngDevMode ? [{ debugName: "multiple" }] : /* istanbul ignore next */ []);
	selection = model([], ...ngDevMode ? [{ debugName: "selection" }] : /* istanbul ignore next */ []);
	activated = output();
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	triangle = computed(() => TRIANGLE.includes(this.skin()), ...ngDevMode ? [{ debugName: "triangle" }] : /* istanbul ignore next */ []);
	dir = inject(Directionality, { optional: true });
	injector = inject(Injector);
	registered = signal([], ...ngDevMode ? [{ debugName: "registered" }] : /* istanbul ignore next */ []);
	orderVersion = signal(0, ...ngDevMode ? [{ debugName: "orderVersion" }] : /* istanbul ignore next */ []);
	orderPending = false;
	ordered = computed(() => {
		this.orderVersion();
		return [...this.registered()].sort(domOrder);
	}, ...ngDevMode ? [{ debugName: "ordered" }] : /* istanbul ignore next */ []);
	visible = computed(() => this.ordered().filter((item) => item.isVisible()), ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	visibleKeys = computed(() => this.visible().map((i) => i.value()), ...ngDevMode ? [{ debugName: "visibleKeys" }] : /* istanbul ignore next */ []);
	cursor = signal({
		anchor: null,
		active: null
	}, ...ngDevMode ? [{ debugName: "cursor" }] : /* istanbul ignore next */ []);
	selectedSet = computed(() => new Set(this.selection()), ...ngDevMode ? [{ debugName: "selectedSet" }] : /* istanbul ignore next */ []);
	tabStop = computed(() => {
		const visible = this.visible();
		const active = this.cursor().active;
		const selected = this.selectedSet();
		return visible.find((i) => i.value() === active) ?? visible.find((i) => selected.has(i.value())) ?? visible[0] ?? null;
	}, ...ngDevMode ? [{ debugName: "tabStop" }] : /* istanbul ignore next */ []);
	typeahead = "";
	typeaheadTimer;
	constructor() {
		effect(() => {
			const keys = this.registered().map((i) => i.value());
			if (keys.some((k) => k === void 0)) return;
			untracked(() => {
				const present = new Set(keys);
				const kept = this.selection().filter((k) => present.has(k));
				if (kept.length !== this.selection().length) this.selection.set(kept);
				const { anchor, active } = this.cursor();
				if (anchor !== null && !present.has(anchor) || active !== null && !present.has(active)) this.cursor.set({
					anchor: present.has(anchor) ? anchor : null,
					active: present.has(active) ? active : null
				});
			});
		});
		inject(DestroyRef).onDestroy(() => clearTimeout(this.typeaheadTimer));
	}
	register(item) {
		this.registered.update((items) => [...items, item]);
		this.reorder();
	}
	unregister(item) {
		this.registered.update((items) => items.filter((i) => i !== item));
	}
	childrenOf(parent) {
		return this.ordered().filter((i) => i.parent === parent);
	}
	isSelected(key) {
		return this.selectedSet().has(key);
	}
	focused(item) {
		if (this.cursor().active !== item.value()) this.cursor.update((c) => ({
			...c,
			active: item.value()
		}));
	}
	click(item, event) {
		const keys = this.visibleKeys();
		this.apply(selectionClick(this.state(), keys, item.value(), this.modifiers(event), this.multiple()));
	}
	activate(item) {
		this.activated.emit(item.value());
	}
	collapsed(item) {
		const inside = (key) => key !== null && item.descendants().some((d) => d.value() === key);
		const { active } = this.cursor();
		if (!inside(active)) return;
		const hadSelection = this.selection().some(inside);
		const keys = this.visibleKeys();
		const index = keys.indexOf(item.value());
		if (hadSelection && !this.multiple()) this.apply(selectionMoveTo(this.state(), keys, index, {}, false));
		else this.cursor.update((c) => ({
			...c,
			active: item.value()
		}));
		item.element.focus();
	}
	onKeydown(event) {
		const item = this.registered().find((i) => i.element === event.target);
		if (!item) return;
		this.orderVersion.update((v) => v + 1);
		this.cursor.update((c) => ({
			...c,
			active: item.value()
		}));
		const keys = this.visibleKeys();
		const state = this.state();
		const mods = this.modifiers(event);
		const multiple = this.multiple();
		const rtl = this.dir?.value === "rtl";
		const mac = this.family() === "macos";
		let next = null;
		switch (event.key) {
			case "ArrowDown":
				next = mac && event.metaKey ? selectionMoveTo(state, keys, keys.length - 1, { range: mods.range }, multiple) : selectionMoveBy(state, keys, 1, mods, multiple);
				break;
			case "ArrowUp":
				next = mac && event.metaKey ? selectionMoveTo(state, keys, 0, { range: mods.range }, multiple) : selectionMoveBy(state, keys, -1, mods, multiple);
				break;
			case "Home":
				next = selectionMoveTo(state, keys, 0, mods, multiple);
				break;
			case "End":
				next = selectionMoveTo(state, keys, keys.length - 1, mods, multiple);
				break;
			case "PageDown":
				next = selectionMoveBy(state, keys, PAGE, mods, multiple);
				break;
			case "PageUp":
				next = selectionMoveBy(state, keys, -10, mods, multiple);
				break;
			case "ArrowRight":
			case "ArrowLeft": {
				const opening = event.key === "ArrowRight" !== rtl;
				if (event.altKey || event.ctrlKey || event.metaKey) return;
				if (opening) {
					if (item.hasChildren() && !item.expanded()) item.setExpanded(true);
					else if (item.expanded()) {
						const first = item.children()[0];
						if (first) next = selectionMoveTo(state, keys, keys.indexOf(first.value()), {}, multiple);
					}
				} else if (item.expanded() && item.hasChildren()) item.setExpanded(false);
				else if (item.parent) next = selectionMoveTo(state, keys, keys.indexOf(item.parent.value()), {}, multiple);
				if (!next) {
					event.preventDefault();
					return;
				}
				break;
			}
			case "*":
				for (const sibling of this.childrenOf(item.parent)) if (sibling.hasChildren()) sibling.setExpanded(true);
				event.preventDefault();
				return;
			case "Enter":
				this.activated.emit(item.value());
				event.preventDefault();
				return;
			case " ":
				if (this.typeahead) return this.onTypeahead(event, keys);
				next = selectionToggleActive(state, keys, mods, multiple);
				break;
			default:
				if ((event.key === "a" || event.key === "A") && mods.toggle && !event.altKey) {
					if (!multiple) return;
					next = selectionAll(state, keys, multiple);
					break;
				}
				return this.onTypeahead(event, keys);
		}
		event.preventDefault();
		this.apply(next);
	}
	onTypeahead(event, keys) {
		if (event.key.length !== 1 || event.ctrlKey || event.metaKey || event.altKey) return;
		event.preventDefault();
		clearTimeout(this.typeaheadTimer);
		this.typeahead += event.key;
		this.typeaheadTimer = setTimeout(() => this.typeahead = "", TYPEAHEAD_RESET_MS);
		const visible = this.visible();
		const current = keys.indexOf(this.cursor().active);
		const index = typeaheadIndex(visible.map((i) => i.label()), this.typeahead, current);
		if (index >= 0) this.apply(selectionMoveTo(this.state(), keys, index, {}, this.multiple()));
	}
	state() {
		return {
			selected: this.selection(),
			...this.cursor()
		};
	}
	apply(next) {
		this.cursor.set({
			anchor: next.anchor,
			active: next.active
		});
		const prev = this.selection();
		if (prev.length !== next.selected.length || prev.some((k, i) => k !== next.selected[i])) this.selection.set(next.selected);
		const target = this.visible().find((i) => i.value() === next.active);
		if (target && target.element !== target.element.ownerDocument.activeElement) target.element.focus();
	}
	modifiers(event) {
		return {
			range: event.shiftKey,
			toggle: this.family() === "macos" ? event.metaKey : event.ctrlKey
		};
	}
	reorder() {
		if (this.orderPending) return;
		this.orderPending = true;
		afterNextRender(() => {
			this.orderPending = false;
			this.orderVersion.update((v) => v + 1);
		}, { injector: this.injector });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnTree,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnTree,
		isStandalone: true,
		selector: "sn-tree",
		inputs: {
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selection: {
				classPropertyName: "selection",
				publicName: "selection",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selection: "selectionChange",
			activated: "activated"
		},
		host: {
			attributes: {
				"data-slot": "sn-tree",
				"role": "tree"
			},
			listeners: { "keydown": "onKeydown($event)" },
			properties: {
				"attr.aria-multiselectable": "multiple() || null",
				"attr.data-family": "family()",
				"attr.data-skin": "skin()",
				"attr.data-triangle": "triangle() ? '' : null"
			}
		},
		ngImport: i0,
		template: `<ng-content />`,
		isInline: true,
		styles: [":host([data-slot=sn-tree]){--sn-tree-indent: 1rem;--sn-tree-row-height: var(--sn-row-height);--sn-tree-row-inset: .25rem;--sn-tree-radius: var(--sn-list-item-radius);--sn-tree-expander: 1.25rem;--sn-tree-glyph: .75rem;--sn-tree-icon: 1rem;--sn-tree-selected-bg: var(--sn-row-selected-bg);--sn-tree-selected-fg: var(--sn-row-selected-fg);display:block;padding-block:.25rem;color:var(--sn-color-fg);cursor:default;-webkit-user-select:none;user-select:none}:host([data-slot=sn-tree]:not(:focus-within)){--sn-tree-selected-bg: var(--sn-row-selected-bg-unfocused);--sn-tree-selected-fg: var(--sn-row-selected-fg-unfocused)}:host([data-slot=sn-tree][data-skin=win]){--sn-tree-row-inset: .25rem}:host([data-slot=sn-tree][data-skin=w10]){--sn-tree-row-inset: 0px;--sn-tree-row-height: 2rem}:host([data-slot=sn-tree][data-family=macos]){--sn-tree-row-inset: .625rem;--sn-tree-expander: 1rem;--sn-tree-glyph: .8125rem}:host([data-slot=sn-tree][data-skin=gtk]),:host([data-slot=sn-tree][data-skin=web]){--sn-tree-indent: 1.125rem;--sn-tree-row-height: 2.125rem;--sn-tree-row-inset: .375rem;--sn-tree-glyph: .875rem}:host([data-slot=sn-tree][data-skin=qt]){--sn-tree-indent: 1.25rem;--sn-tree-row-height: 1.875rem;--sn-tree-row-inset: .25rem;--sn-tree-icon: 1.375rem}:host([data-slot=sn-tree][data-family=chromeos]){--sn-tree-row-height: 2.5rem;--sn-tree-row-inset: .5rem;--sn-tree-expander: 1.5rem;--sn-tree-glyph: 1rem;--sn-tree-icon: 1.25rem}:host([data-slot=sn-tree-item]){display:block;outline:none}.row{position:relative;display:flex;align-items:center;gap:.375rem;box-sizing:border-box;min-block-size:var(--sn-tree-row-height);margin-inline:var(--sn-tree-row-inset);padding-inline:calc(.25rem + var(--sn-tree-level, 0) * var(--sn-tree-indent)) .5rem;border-radius:var(--sn-tree-radius);white-space:nowrap;transition:background-color var(--sn-duration-fast) var(--sn-easing)}.row:hover{background:var(--sn-color-hover)}.expander{display:grid;place-items:center;flex:none;inline-size:var(--sn-tree-expander);block-size:var(--sn-tree-expander);color:var(--sn-color-fg-muted)}.expander svg{width:var(--sn-tree-glyph);height:var(--sn-tree-glyph);fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;transition:rotate var(--sn-duration-fast) var(--sn-easing)}.expander .fill{fill:currentColor;stroke:none}:host([data-slot=sn-tree-item]:dir(rtl)) .expander svg{scale:-1 1}:host([data-slot=sn-tree-item][data-expanded])>.row .expander svg{rotate:90deg}:host([data-slot=sn-tree-item][data-expanded]:dir(rtl))>.row .expander svg{rotate:-90deg}.icon{flex:none;font-size:var(--sn-tree-icon);color:var(--sn-color-fg-muted)}.label{flex:1;min-inline-size:0;overflow:hidden;text-overflow:ellipsis}.children[hidden]{display:none}:host([data-slot=sn-tree-item][data-selected])>.row{background:var(--sn-tree-selected-bg);color:var(--sn-tree-selected-fg)}:host([data-slot=sn-tree-item][data-selected])>.row .expander,:host([data-slot=sn-tree-item][data-selected])>.row .icon{color:inherit}:host([data-slot=sn-tree-item][data-selected])>.row:before{content:\"\";position:absolute;inset-inline-start:0;top:50%;inline-size:3px;block-size:1em;translate:0 -50%;border-radius:2px;background:var(--sn-row-selected-indicator)}:host([data-slot=sn-tree-item]:focus-visible)>.row{outline:var(--sn-row-focus-ring);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-tree-item][data-selected])>.row{background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-slot=sn-tree-item][data-selected])>.row:before{background:HighlightText!important}:host([data-slot=sn-tree-item]:focus-visible)>.row{outline:2px solid CanvasText}.expander{color:CanvasText}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnTree,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-tree",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-tree",
				role: "tree",
				"[attr.aria-multiselectable]": "multiple() || null",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()",
				"[attr.data-triangle]": "triangle() ? '' : null",
				"(keydown)": "onKeydown($event)"
			},
			template: `<ng-content />`,
			styles: [":host([data-slot=sn-tree]){--sn-tree-indent: 1rem;--sn-tree-row-height: var(--sn-row-height);--sn-tree-row-inset: .25rem;--sn-tree-radius: var(--sn-list-item-radius);--sn-tree-expander: 1.25rem;--sn-tree-glyph: .75rem;--sn-tree-icon: 1rem;--sn-tree-selected-bg: var(--sn-row-selected-bg);--sn-tree-selected-fg: var(--sn-row-selected-fg);display:block;padding-block:.25rem;color:var(--sn-color-fg);cursor:default;-webkit-user-select:none;user-select:none}:host([data-slot=sn-tree]:not(:focus-within)){--sn-tree-selected-bg: var(--sn-row-selected-bg-unfocused);--sn-tree-selected-fg: var(--sn-row-selected-fg-unfocused)}:host([data-slot=sn-tree][data-skin=win]){--sn-tree-row-inset: .25rem}:host([data-slot=sn-tree][data-skin=w10]){--sn-tree-row-inset: 0px;--sn-tree-row-height: 2rem}:host([data-slot=sn-tree][data-family=macos]){--sn-tree-row-inset: .625rem;--sn-tree-expander: 1rem;--sn-tree-glyph: .8125rem}:host([data-slot=sn-tree][data-skin=gtk]),:host([data-slot=sn-tree][data-skin=web]){--sn-tree-indent: 1.125rem;--sn-tree-row-height: 2.125rem;--sn-tree-row-inset: .375rem;--sn-tree-glyph: .875rem}:host([data-slot=sn-tree][data-skin=qt]){--sn-tree-indent: 1.25rem;--sn-tree-row-height: 1.875rem;--sn-tree-row-inset: .25rem;--sn-tree-icon: 1.375rem}:host([data-slot=sn-tree][data-family=chromeos]){--sn-tree-row-height: 2.5rem;--sn-tree-row-inset: .5rem;--sn-tree-expander: 1.5rem;--sn-tree-glyph: 1rem;--sn-tree-icon: 1.25rem}:host([data-slot=sn-tree-item]){display:block;outline:none}.row{position:relative;display:flex;align-items:center;gap:.375rem;box-sizing:border-box;min-block-size:var(--sn-tree-row-height);margin-inline:var(--sn-tree-row-inset);padding-inline:calc(.25rem + var(--sn-tree-level, 0) * var(--sn-tree-indent)) .5rem;border-radius:var(--sn-tree-radius);white-space:nowrap;transition:background-color var(--sn-duration-fast) var(--sn-easing)}.row:hover{background:var(--sn-color-hover)}.expander{display:grid;place-items:center;flex:none;inline-size:var(--sn-tree-expander);block-size:var(--sn-tree-expander);color:var(--sn-color-fg-muted)}.expander svg{width:var(--sn-tree-glyph);height:var(--sn-tree-glyph);fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;transition:rotate var(--sn-duration-fast) var(--sn-easing)}.expander .fill{fill:currentColor;stroke:none}:host([data-slot=sn-tree-item]:dir(rtl)) .expander svg{scale:-1 1}:host([data-slot=sn-tree-item][data-expanded])>.row .expander svg{rotate:90deg}:host([data-slot=sn-tree-item][data-expanded]:dir(rtl))>.row .expander svg{rotate:-90deg}.icon{flex:none;font-size:var(--sn-tree-icon);color:var(--sn-color-fg-muted)}.label{flex:1;min-inline-size:0;overflow:hidden;text-overflow:ellipsis}.children[hidden]{display:none}:host([data-slot=sn-tree-item][data-selected])>.row{background:var(--sn-tree-selected-bg);color:var(--sn-tree-selected-fg)}:host([data-slot=sn-tree-item][data-selected])>.row .expander,:host([data-slot=sn-tree-item][data-selected])>.row .icon{color:inherit}:host([data-slot=sn-tree-item][data-selected])>.row:before{content:\"\";position:absolute;inset-inline-start:0;top:50%;inline-size:3px;block-size:1em;translate:0 -50%;border-radius:2px;background:var(--sn-row-selected-indicator)}:host([data-slot=sn-tree-item]:focus-visible)>.row{outline:var(--sn-row-focus-ring);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-tree-item][data-selected])>.row{background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-slot=sn-tree-item][data-selected])>.row:before{background:HighlightText!important}:host([data-slot=sn-tree-item]:focus-visible)>.row{outline:2px solid CanvasText}.expander{color:CanvasText}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		selection: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selection",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectionChange"]
		}],
		activated: [{
			type: i0.Output,
			args: ["activated"]
		}]
	}
});
var SnTreeItem = class SnTreeItem {
	value = input(void 0, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	icon = input("", ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	expanded = model(false, ...ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []);
	expandable = input(false, ...ngDevMode ? [{ debugName: "expandable" }] : /* istanbul ignore next */ []);
	element = inject(ElementRef).nativeElement;
	tree = inject(SnTree);
	parent = inject(SnTreeItem, {
		optional: true,
		skipSelf: true
	});
	level = computed(() => this.parent ? this.parent.level() + 1 : 1, ...ngDevMode ? [{ debugName: "level" }] : /* istanbul ignore next */ []);
	children = computed(() => this.tree.childrenOf(this), ...ngDevMode ? [{ debugName: "children" }] : /* istanbul ignore next */ []);
	hasChildren = computed(() => this.expandable() || this.children().length > 0, ...ngDevMode ? [{ debugName: "hasChildren" }] : /* istanbul ignore next */ []);
	selected = computed(() => this.tree.isSelected(this.value()), ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	isVisible = computed(() => !this.parent || this.parent.expanded() && this.parent.isVisible(), ...ngDevMode ? [{ debugName: "isVisible" }] : /* istanbul ignore next */ []);
	constructor() {
		this.tree.register(this);
		inject(DestroyRef).onDestroy(() => this.tree.unregister(this));
	}
	descendants() {
		return this.children().flatMap((c) => [c, ...c.descendants()]);
	}
	setExpanded(open) {
		if (this.expanded() === open) return;
		this.expanded.set(open);
		if (!open) this.tree.collapsed(this);
	}
	onMouseDown(event) {
		if (event.shiftKey) event.preventDefault();
	}
	onExpanderClick(event) {
		if (!this.hasChildren()) return;
		event.stopPropagation();
		this.setExpanded(!this.expanded());
		this.element.focus();
	}
	onDoubleClick() {
		if (this.hasChildren()) this.setExpanded(!this.expanded());
		else this.tree.activate(this);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnTreeItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnTreeItem,
		isStandalone: true,
		selector: "sn-tree-item",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			expanded: {
				classPropertyName: "expanded",
				publicName: "expanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			expandable: {
				classPropertyName: "expandable",
				publicName: "expandable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { expanded: "expandedChange" },
		host: {
			attributes: {
				"data-slot": "sn-tree-item",
				"role": "treeitem"
			},
			listeners: { "focus": "tree.focused(this)" },
			properties: {
				"attr.aria-level": "level()",
				"attr.aria-expanded": "hasChildren() ? expanded() : null",
				"attr.aria-selected": "selected()",
				"attr.aria-label": "label()",
				"attr.tabindex": "tree.tabStop() === this ? 0 : -1",
				"attr.data-selected": "selected() ? '' : null",
				"attr.data-expanded": "hasChildren() && expanded() ? '' : null",
				"style.--sn-tree-level": "level() - 1"
			}
		},
		ngImport: i0,
		template: `
    <div class="row" (mousedown)="onMouseDown($event)" (click)="tree.click(this, $event)" (dblclick)="onDoubleClick()">
      <span class="expander" (click)="onExpanderClick($event)" (dblclick)="$event.stopPropagation()">
        @if (hasChildren()) {
          @if (tree.triangle()) {
            <svg viewBox="0 0 16 16" aria-hidden="true"><path class="fill" d="M6 4.5v7l5-3.5z" /></svg>
          } @else {
            <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6 4l4 4-4 4" /></svg>
          }
        }
      </span>
      @if (icon()) {
        <ng-icon class="icon" [name]="icon()" aria-hidden="true" />
      }
      <span class="label">{{ label() }}</span>
      <ng-content select="[snTreeItemEnd]" />
    </div>
    <div role="group" class="children" [hidden]="!expanded()">
      <ng-content />
    </div>
  `,
		isInline: true,
		styles: [":host([data-slot=sn-tree]){--sn-tree-indent: 1rem;--sn-tree-row-height: var(--sn-row-height);--sn-tree-row-inset: .25rem;--sn-tree-radius: var(--sn-list-item-radius);--sn-tree-expander: 1.25rem;--sn-tree-glyph: .75rem;--sn-tree-icon: 1rem;--sn-tree-selected-bg: var(--sn-row-selected-bg);--sn-tree-selected-fg: var(--sn-row-selected-fg);display:block;padding-block:.25rem;color:var(--sn-color-fg);cursor:default;-webkit-user-select:none;user-select:none}:host([data-slot=sn-tree]:not(:focus-within)){--sn-tree-selected-bg: var(--sn-row-selected-bg-unfocused);--sn-tree-selected-fg: var(--sn-row-selected-fg-unfocused)}:host([data-slot=sn-tree][data-skin=win]){--sn-tree-row-inset: .25rem}:host([data-slot=sn-tree][data-skin=w10]){--sn-tree-row-inset: 0px;--sn-tree-row-height: 2rem}:host([data-slot=sn-tree][data-family=macos]){--sn-tree-row-inset: .625rem;--sn-tree-expander: 1rem;--sn-tree-glyph: .8125rem}:host([data-slot=sn-tree][data-skin=gtk]),:host([data-slot=sn-tree][data-skin=web]){--sn-tree-indent: 1.125rem;--sn-tree-row-height: 2.125rem;--sn-tree-row-inset: .375rem;--sn-tree-glyph: .875rem}:host([data-slot=sn-tree][data-skin=qt]){--sn-tree-indent: 1.25rem;--sn-tree-row-height: 1.875rem;--sn-tree-row-inset: .25rem;--sn-tree-icon: 1.375rem}:host([data-slot=sn-tree][data-family=chromeos]){--sn-tree-row-height: 2.5rem;--sn-tree-row-inset: .5rem;--sn-tree-expander: 1.5rem;--sn-tree-glyph: 1rem;--sn-tree-icon: 1.25rem}:host([data-slot=sn-tree-item]){display:block;outline:none}.row{position:relative;display:flex;align-items:center;gap:.375rem;box-sizing:border-box;min-block-size:var(--sn-tree-row-height);margin-inline:var(--sn-tree-row-inset);padding-inline:calc(.25rem + var(--sn-tree-level, 0) * var(--sn-tree-indent)) .5rem;border-radius:var(--sn-tree-radius);white-space:nowrap;transition:background-color var(--sn-duration-fast) var(--sn-easing)}.row:hover{background:var(--sn-color-hover)}.expander{display:grid;place-items:center;flex:none;inline-size:var(--sn-tree-expander);block-size:var(--sn-tree-expander);color:var(--sn-color-fg-muted)}.expander svg{width:var(--sn-tree-glyph);height:var(--sn-tree-glyph);fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;transition:rotate var(--sn-duration-fast) var(--sn-easing)}.expander .fill{fill:currentColor;stroke:none}:host([data-slot=sn-tree-item]:dir(rtl)) .expander svg{scale:-1 1}:host([data-slot=sn-tree-item][data-expanded])>.row .expander svg{rotate:90deg}:host([data-slot=sn-tree-item][data-expanded]:dir(rtl))>.row .expander svg{rotate:-90deg}.icon{flex:none;font-size:var(--sn-tree-icon);color:var(--sn-color-fg-muted)}.label{flex:1;min-inline-size:0;overflow:hidden;text-overflow:ellipsis}.children[hidden]{display:none}:host([data-slot=sn-tree-item][data-selected])>.row{background:var(--sn-tree-selected-bg);color:var(--sn-tree-selected-fg)}:host([data-slot=sn-tree-item][data-selected])>.row .expander,:host([data-slot=sn-tree-item][data-selected])>.row .icon{color:inherit}:host([data-slot=sn-tree-item][data-selected])>.row:before{content:\"\";position:absolute;inset-inline-start:0;top:50%;inline-size:3px;block-size:1em;translate:0 -50%;border-radius:2px;background:var(--sn-row-selected-indicator)}:host([data-slot=sn-tree-item]:focus-visible)>.row{outline:var(--sn-row-focus-ring);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-tree-item][data-selected])>.row{background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-slot=sn-tree-item][data-selected])>.row:before{background:HighlightText!important}:host([data-slot=sn-tree-item]:focus-visible)>.row{outline:2px solid CanvasText}.expander{color:CanvasText}}\n"],
		dependencies: [{
			kind: "component",
			type: NgIcon,
			selector: "ng-icon",
			inputs: [
				"name",
				"svg",
				"size",
				"strokeWidth",
				"color"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnTreeItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-tree-item",
			imports: [NgIcon],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-tree-item",
				role: "treeitem",
				"[attr.aria-level]": "level()",
				"[attr.aria-expanded]": "hasChildren() ? expanded() : null",
				"[attr.aria-selected]": "selected()",
				"[attr.aria-label]": "label()",
				"[attr.tabindex]": "tree.tabStop() === this ? 0 : -1",
				"[attr.data-selected]": "selected() ? '' : null",
				"[attr.data-expanded]": "hasChildren() && expanded() ? '' : null",
				"[style.--sn-tree-level]": "level() - 1",
				"(focus)": "tree.focused(this)"
			},
			template: `
    <div class="row" (mousedown)="onMouseDown($event)" (click)="tree.click(this, $event)" (dblclick)="onDoubleClick()">
      <span class="expander" (click)="onExpanderClick($event)" (dblclick)="$event.stopPropagation()">
        @if (hasChildren()) {
          @if (tree.triangle()) {
            <svg viewBox="0 0 16 16" aria-hidden="true"><path class="fill" d="M6 4.5v7l5-3.5z" /></svg>
          } @else {
            <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6 4l4 4-4 4" /></svg>
          }
        }
      </span>
      @if (icon()) {
        <ng-icon class="icon" [name]="icon()" aria-hidden="true" />
      }
      <span class="label">{{ label() }}</span>
      <ng-content select="[snTreeItemEnd]" />
    </div>
    <div role="group" class="children" [hidden]="!expanded()">
      <ng-content />
    </div>
  `,
			styles: [":host([data-slot=sn-tree]){--sn-tree-indent: 1rem;--sn-tree-row-height: var(--sn-row-height);--sn-tree-row-inset: .25rem;--sn-tree-radius: var(--sn-list-item-radius);--sn-tree-expander: 1.25rem;--sn-tree-glyph: .75rem;--sn-tree-icon: 1rem;--sn-tree-selected-bg: var(--sn-row-selected-bg);--sn-tree-selected-fg: var(--sn-row-selected-fg);display:block;padding-block:.25rem;color:var(--sn-color-fg);cursor:default;-webkit-user-select:none;user-select:none}:host([data-slot=sn-tree]:not(:focus-within)){--sn-tree-selected-bg: var(--sn-row-selected-bg-unfocused);--sn-tree-selected-fg: var(--sn-row-selected-fg-unfocused)}:host([data-slot=sn-tree][data-skin=win]){--sn-tree-row-inset: .25rem}:host([data-slot=sn-tree][data-skin=w10]){--sn-tree-row-inset: 0px;--sn-tree-row-height: 2rem}:host([data-slot=sn-tree][data-family=macos]){--sn-tree-row-inset: .625rem;--sn-tree-expander: 1rem;--sn-tree-glyph: .8125rem}:host([data-slot=sn-tree][data-skin=gtk]),:host([data-slot=sn-tree][data-skin=web]){--sn-tree-indent: 1.125rem;--sn-tree-row-height: 2.125rem;--sn-tree-row-inset: .375rem;--sn-tree-glyph: .875rem}:host([data-slot=sn-tree][data-skin=qt]){--sn-tree-indent: 1.25rem;--sn-tree-row-height: 1.875rem;--sn-tree-row-inset: .25rem;--sn-tree-icon: 1.375rem}:host([data-slot=sn-tree][data-family=chromeos]){--sn-tree-row-height: 2.5rem;--sn-tree-row-inset: .5rem;--sn-tree-expander: 1.5rem;--sn-tree-glyph: 1rem;--sn-tree-icon: 1.25rem}:host([data-slot=sn-tree-item]){display:block;outline:none}.row{position:relative;display:flex;align-items:center;gap:.375rem;box-sizing:border-box;min-block-size:var(--sn-tree-row-height);margin-inline:var(--sn-tree-row-inset);padding-inline:calc(.25rem + var(--sn-tree-level, 0) * var(--sn-tree-indent)) .5rem;border-radius:var(--sn-tree-radius);white-space:nowrap;transition:background-color var(--sn-duration-fast) var(--sn-easing)}.row:hover{background:var(--sn-color-hover)}.expander{display:grid;place-items:center;flex:none;inline-size:var(--sn-tree-expander);block-size:var(--sn-tree-expander);color:var(--sn-color-fg-muted)}.expander svg{width:var(--sn-tree-glyph);height:var(--sn-tree-glyph);fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;transition:rotate var(--sn-duration-fast) var(--sn-easing)}.expander .fill{fill:currentColor;stroke:none}:host([data-slot=sn-tree-item]:dir(rtl)) .expander svg{scale:-1 1}:host([data-slot=sn-tree-item][data-expanded])>.row .expander svg{rotate:90deg}:host([data-slot=sn-tree-item][data-expanded]:dir(rtl))>.row .expander svg{rotate:-90deg}.icon{flex:none;font-size:var(--sn-tree-icon);color:var(--sn-color-fg-muted)}.label{flex:1;min-inline-size:0;overflow:hidden;text-overflow:ellipsis}.children[hidden]{display:none}:host([data-slot=sn-tree-item][data-selected])>.row{background:var(--sn-tree-selected-bg);color:var(--sn-tree-selected-fg)}:host([data-slot=sn-tree-item][data-selected])>.row .expander,:host([data-slot=sn-tree-item][data-selected])>.row .icon{color:inherit}:host([data-slot=sn-tree-item][data-selected])>.row:before{content:\"\";position:absolute;inset-inline-start:0;top:50%;inline-size:3px;block-size:1em;translate:0 -50%;border-radius:2px;background:var(--sn-row-selected-indicator)}:host([data-slot=sn-tree-item]:focus-visible)>.row{outline:var(--sn-row-focus-ring);outline-offset:-2px}@media(forced-colors:active){:host([data-slot=sn-tree-item][data-selected])>.row{background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}:host([data-slot=sn-tree-item][data-selected])>.row:before{background:HighlightText!important}:host([data-slot=sn-tree-item]:focus-visible)>.row{outline:2px solid CanvasText}.expander{color:CanvasText}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		expanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expanded",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["expandedChange"]
		}],
		expandable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expandable",
				required: false
			}]
		}]
	}
});
const SnTreeImports = [SnTree, SnTreeItem];
let nextId = 0;
const ROLE_ID = "sn-role-";
function toHostMenu(items, actions = /* @__PURE__ */ new Map()) {
	const convert = (list) => list.map((item) => {
		const { action, submenu, ...rest } = item;
		let id = rest.id;
		if (action && !id) id = `sn-menu-${nextId++}`;
		if (id && action) actions.set(id, item);
		return {
			...rest,
			...id ? { id } : {},
			...submenu ? { submenu: convert(submenu) } : {}
		};
	});
	return {
		menu: convert(items),
		actions
	};
}
function tidyMenu(items) {
	const out = [];
	for (const item of items) {
		if (item.type === "separator") {
			if (out.length && out[out.length - 1].type !== "separator") out.push(item);
			continue;
		}
		if (item.submenu) {
			const submenu = tidyMenu(item.submenu);
			if (!submenu.length) continue;
			out.push({
				...item,
				submenu
			});
			continue;
		}
		out.push(item);
	}
	while (out.length && out[out.length - 1].type === "separator") out.pop();
	return out;
}
const MAC_APP_MENU_ROLES = [
	"appMenu",
	"hide",
	"hideOthers",
	"showAll"
];
function inPageMenu(items, family, window = {}, run = runEditCommand) {
	const mac = family === "macos";
	const role = (r, label) => {
		const edit = (command, text, accelerator) => ({
			label: label ?? text,
			accelerator,
			action: () => run(command),
			id: `${ROLE_ID}${command}`
		});
		switch (r) {
			case "undo": return edit("undo", "Undo", "mod+z");
			case "redo": return edit("redo", "Redo", mac ? "mod+shift+z" : "mod+y");
			case "cut": return edit("cut", "Cut", "mod+x");
			case "copy": return edit("copy", "Copy", "mod+c");
			case "paste": return edit("paste", "Paste", "mod+v");
			case "selectAll": return edit("selectAll", mac ? "Select All" : "Select all", "mod+a");
			case "minimize": return {
				label: label ?? "Minimize",
				accelerator: mac ? "mod+m" : void 0,
				enabled: !!window.minimize,
				action: () => window.minimize?.()
			};
			case "zoom": return {
				label: label ?? (mac ? "Zoom" : "Maximize"),
				enabled: !!window.toggleMaximize,
				action: () => window.toggleMaximize?.()
			};
			case "close": return {
				label: label ?? (mac ? "Close Window" : "Close"),
				accelerator: mac ? "mod+w" : "ctrl+w",
				enabled: !!window.close,
				action: () => window.close?.()
			};
			case "quit": return window.close ? {
				label: label ?? (mac ? "Quit" : "Exit"),
				accelerator: mac ? "mod+q" : void 0,
				action: () => window.close?.()
			} : null;
			case "toggleFullscreen": return {
				label: label ?? (mac ? "Enter Full Screen" : "Full screen"),
				accelerator: mac ? "ctrl+mod+f" : "f11",
				action: toggleFullscreen
			};
			case "editMenu": return {
				label: label ?? "Edit",
				submenu: [
					"undo",
					"redo",
					null,
					"cut",
					"copy",
					"paste",
					"selectAll"
				].map((x) => x ? role(x) : { type: "separator" })
			};
			case "windowMenu": return {
				label: label ?? "Window",
				submenu: [
					role("minimize"),
					role("zoom"),
					{ type: "separator" },
					role("close")
				].filter((x) => !!x)
			};
			default: return null;
		}
	};
	const convert = (list) => list.flatMap((item) => {
		if (item.role) {
			if (MAC_APP_MENU_ROLES.includes(item.role)) return [];
			if (item.action) return [{
				...item,
				role: void 0
			}];
			const replaced = role(item.role, item.label);
			return replaced ? [{
				...replaced,
				enabled: item.enabled === false ? false : replaced.enabled
			}] : [];
		}
		return [item.submenu ? {
			...item,
			submenu: convert(item.submenu)
		} : item];
	});
	return tidyMenu(convert(items));
}
function runEditCommand(command) {
	if (command === "paste" && navigator.clipboard?.readText) {
		navigator.clipboard.readText().then((text) => document.execCommand("insertText", false, text), () => void 0);
		return;
	}
	document.execCommand(command);
}
function toggleFullscreen() {
	if (document.fullscreenElement) document.exitFullscreen?.();
	else document.documentElement.requestFullscreen?.();
}
function matchesAccelerator(event, accelerator, family) {
	const parts = accelerator.toLowerCase().split("+").map((p) => p.trim());
	const key = parts.pop();
	if (!key) return false;
	const mac = family === "macos";
	const wants = {
		ctrl: parts.includes("ctrl") || !mac && parts.includes("mod"),
		meta: parts.includes("meta") || mac && parts.includes("mod"),
		alt: parts.includes("alt"),
		shift: parts.includes("shift")
	};
	if (event.ctrlKey !== wants.ctrl || event.metaKey !== wants.meta || event.altKey !== wants.alt || event.shiftKey !== wants.shift) return false;
	const NAMES = {
		enter: "enter",
		escape: "escape",
		backspace: "backspace",
		delete: "delete",
		tab: "tab",
		space: " ",
		up: "arrowup",
		down: "arrowdown",
		left: "arrowleft",
		right: "arrowright",
		home: "home",
		end: "end"
	};
	const pressed = event.key.toLowerCase();
	if (NAMES[key]) return pressed === NAMES[key];
	return pressed === key || event.code.toLowerCase() === `key${key}` || event.code.toLowerCase() === `digit${key}`;
}
function itemsWithAccelerators(items) {
	return items.flatMap((item) => [...item.action && item.accelerator && item.type !== "separator" && !item.id?.startsWith(ROLE_ID) ? [item] : [], ...item.submenu ? itemsWithAccelerators(item.submenu) : []]);
}
var SnNativeMenus = class SnNativeMenus {
	theme = inject(SpartanNativeTheme, { optional: true });
	host = this.theme?.menus;
	appActions = /* @__PURE__ */ new Map();
	contextActions = /* @__PURE__ */ new Map();
	off = null;
	constructor() {
		inject(DestroyRef).onDestroy(() => this.off?.());
	}
	get canSetApplicationMenu() {
		return !!this.host?.setApplicationMenu && this.theme?.capabilities.nativeMenus !== "none";
	}
	get canShowContextMenu() {
		return !!this.host?.showContextMenu && this.theme?.capabilities.nativeMenus !== "none";
	}
	async setApplicationMenu(items) {
		if (!this.canSetApplicationMenu) return;
		this.listen();
		const { menu, actions } = toHostMenu(items);
		this.appActions.clear();
		actions.forEach((item, id) => this.appActions.set(id, item));
		await this.host.setApplicationMenu(menu);
	}
	async showContextMenu(items, position) {
		if (!this.canShowContextMenu) return;
		this.listen();
		const { menu, actions } = toHostMenu(items);
		this.contextActions.clear();
		actions.forEach((item, id) => this.contextActions.set(id, item));
		await this.host.showContextMenu(menu, position);
	}
	listen() {
		this.off ??= this.host.onAction((id) => {
			const item = this.contextActions.get(id) ?? this.appActions.get(id);
			if (item && item.enabled !== false) item.action?.();
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnNativeMenus,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnNativeMenus,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnNativeMenus,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var SnMenubar = class SnMenubar {
	menu = input.required(...ngDevMode ? [{ debugName: "menu" }] : /* istanbul ignore next */ []);
	native = input("auto", ...ngDevMode ? [{ debugName: "native" }] : /* istanbul ignore next */ []);
	ariaLabel = input("Application menu", ...ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	skin = injectSkin();
	family = computed(() => skinFamily(this.skin()), ...ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []);
	platform = injectPlatformFamily();
	menus = inject(SnNativeMenus);
	hostWindow = inject(SpartanNativeTheme, { optional: true })?.window;
	element = inject(ElementRef).nativeElement;
	bar = viewChild(CdkMenuBar, {
		...ngDevMode ? { debugName: "bar" } : /* istanbul ignore next */ {},
		read: ElementRef
	});
	isNative = computed(() => {
		const mode = this.native();
		if (mode === "never" || !this.menus.canSetApplicationMenu) return false;
		return mode === "always" || this.platform() === "macos";
	}, ...ngDevMode ? [{ debugName: "isNative" }] : /* istanbul ignore next */ []);
	pageMenu = computed(() => inPageMenu(this.menu(), this.platform(), {
		minimize: this.hostWindow?.minimize && (() => void this.hostWindow.minimize()),
		toggleMaximize: this.hostWindow?.toggleMaximize && (() => void this.hostWindow.toggleMaximize()),
		close: this.hostWindow?.close && (() => void this.hostWindow.close())
	}), ...ngDevMode ? [{ debugName: "pageMenu" }] : /* istanbul ignore next */ []);
	accelerated = computed(() => itemsWithAccelerators(this.pageMenu()), ...ngDevMode ? [{ debugName: "accelerated" }] : /* istanbul ignore next */ []);
	lastFocus = null;
	restoreFocus = () => this.lastFocus?.isConnected && this.lastFocus.focus();
	constructor() {
		let sent = false;
		effect(() => {
			if (!this.isNative()) return;
			const menu = this.menu();
			sent = true;
			untracked(() => void this.menus.setApplicationMenu(menu));
		});
		inject(DestroyRef).onDestroy(() => {
			if (sent) this.menus.setApplicationMenu([]);
		});
	}
	onDocumentKeydown(event) {
		if (this.isNative() || event.defaultPrevented || event.repeat) return;
		if (event.key === "F10" && !event.shiftKey && !event.ctrlKey && !event.altKey && !event.metaKey && this.platform() !== "macos") {
			const first = this.bar()?.nativeElement.querySelector("[data-slot=\"menubar-trigger\"]:not([aria-disabled=\"true\"])");
			if (first) {
				event.preventDefault();
				first.focus();
			}
			return;
		}
		const family = this.platform();
		const item = this.accelerated().find((i) => i.enabled !== false && matchesAccelerator(event, i.accelerator, family));
		if (!item) return;
		event.preventDefault();
		item.action?.();
	}
	onDocumentFocusin(event) {
		const target = event.target;
		if (!target || this.element.contains(target)) return;
		if (target.closest(".cdk-overlay-container")) return;
		this.lastFocus = target;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnMenubar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: SnMenubar,
		isStandalone: true,
		selector: "sn-menubar",
		inputs: {
			menu: {
				classPropertyName: "menu",
				publicName: "menu",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			native: {
				classPropertyName: "native",
				publicName: "native",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ariaLabel: {
				classPropertyName: "ariaLabel",
				publicName: "ariaLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "sn-menubar" },
			listeners: {
				"document:keydown": "onDocumentKeydown($event)",
				"document:focusin": "onDocumentFocusin($event)"
			},
			properties: {
				"attr.data-family": "family()",
				"attr.data-skin": "skin()",
				"attr.data-native": "isNative() ? '' : null"
			},
			classAttribute: "sn-chrome"
		},
		viewQueries: [{
			propertyName: "bar",
			first: true,
			predicate: CdkMenuBar,
			descendants: true,
			read: ElementRef,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @if (!isNative()) {
      <div cdkMenuBar data-slot="menubar" class="bar" [attr.aria-label]="ariaLabel()">
        @for (item of pageMenu(); track $index) {
          @if (item.submenu) {
            <button
              type="button"
              cdkMenuItem
              data-slot="menubar-trigger"
              class="trigger"
              [cdkMenuTriggerFor]="templates.menu()"
              [cdkMenuTriggerData]="{ $implicit: item.submenu }"
              [cdkMenuItemDisabled]="item.enabled === false"
            >
              {{ item.label }}
            </button>
          } @else if (item.type !== 'separator') {
            <button
              type="button"
              cdkMenuItem
              data-slot="menubar-trigger"
              class="trigger"
              [cdkMenuItemDisabled]="item.enabled === false"
              (cdkMenuItemTriggered)="item.action?.()"
            >
              {{ item.label }}
            </button>
          }
        }
      </div>
    }
    <sn-menu-templates #templates [family]="platform()" [beforeRun]="restoreFocus" />
  `,
		isInline: true,
		styles: [":host{display:block;flex:none}:host([data-native]){display:none}.bar{display:flex;align-items:center;gap:.125rem;min-block-size:0;padding:.125rem .25rem;border:0;border-radius:0;background:transparent;box-shadow:none;-webkit-user-select:none;user-select:none}@layer spartan-native.base{.trigger{display:inline-flex;align-items:center;margin:0;border:0;background:transparent;color:inherit;font:inherit;white-space:nowrap;cursor:default}}:host([data-family=chromeos]) .bar{padding-inline:.5rem}@media(forced-colors:active){.bar{border-bottom:1px solid CanvasText}.trigger:is(:hover,:focus-visible,[aria-expanded=true]){background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}}\n"],
		dependencies: [
			{
				kind: "directive",
				type: CdkMenuBar,
				selector: "[cdkMenuBar]",
				exportAs: ["cdkMenuBar"]
			},
			{
				kind: "directive",
				type: CdkMenuItem,
				selector: "[cdkMenuItem]",
				inputs: ["cdkMenuItemDisabled", "cdkMenuitemTypeaheadLabel"],
				outputs: ["cdkMenuItemTriggered"],
				exportAs: ["cdkMenuItem"]
			},
			{
				kind: "directive",
				type: CdkMenuTrigger,
				selector: "[cdkMenuTriggerFor]",
				inputs: [
					"cdkMenuTriggerFor",
					"cdkMenuPosition",
					"cdkMenuTriggerData",
					"cdkMenuTriggerTransformOriginOn"
				],
				outputs: ["cdkMenuOpened", "cdkMenuClosed"],
				exportAs: ["cdkMenuTriggerFor"]
			},
			{
				kind: "component",
				type: SnMenuTemplates,
				selector: "sn-menu-templates",
				inputs: ["family", "beforeRun"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnMenubar,
	decorators: [{
		type: Component,
		args: [{
			selector: "sn-menubar",
			imports: [
				CdkMenuBar,
				CdkMenuItem,
				CdkMenuTrigger,
				SnMenuTemplates
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"data-slot": "sn-menubar",
				class: "sn-chrome",
				"[attr.data-family]": "family()",
				"[attr.data-skin]": "skin()",
				"[attr.data-native]": "isNative() ? '' : null",
				"(document:keydown)": "onDocumentKeydown($event)",
				"(document:focusin)": "onDocumentFocusin($event)"
			},
			template: `
    @if (!isNative()) {
      <div cdkMenuBar data-slot="menubar" class="bar" [attr.aria-label]="ariaLabel()">
        @for (item of pageMenu(); track $index) {
          @if (item.submenu) {
            <button
              type="button"
              cdkMenuItem
              data-slot="menubar-trigger"
              class="trigger"
              [cdkMenuTriggerFor]="templates.menu()"
              [cdkMenuTriggerData]="{ $implicit: item.submenu }"
              [cdkMenuItemDisabled]="item.enabled === false"
            >
              {{ item.label }}
            </button>
          } @else if (item.type !== 'separator') {
            <button
              type="button"
              cdkMenuItem
              data-slot="menubar-trigger"
              class="trigger"
              [cdkMenuItemDisabled]="item.enabled === false"
              (cdkMenuItemTriggered)="item.action?.()"
            >
              {{ item.label }}
            </button>
          }
        }
      </div>
    }
    <sn-menu-templates #templates [family]="platform()" [beforeRun]="restoreFocus" />
  `,
			styles: [":host{display:block;flex:none}:host([data-native]){display:none}.bar{display:flex;align-items:center;gap:.125rem;min-block-size:0;padding:.125rem .25rem;border:0;border-radius:0;background:transparent;box-shadow:none;-webkit-user-select:none;user-select:none}@layer spartan-native.base{.trigger{display:inline-flex;align-items:center;margin:0;border:0;background:transparent;color:inherit;font:inherit;white-space:nowrap;cursor:default}}:host([data-family=chromeos]) .bar{padding-inline:.5rem}@media(forced-colors:active){.bar{border-bottom:1px solid CanvasText}.trigger:is(:hover,:focus-visible,[aria-expanded=true]){background:Highlight!important;color:HighlightText!important;forced-color-adjust:none}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		menu: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "menu",
				required: true
			}]
		}],
		native: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "native",
				required: false
			}]
		}],
		ariaLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		bar: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => CdkMenuBar), {
				read: ElementRef,
				isSignal: true
			}]
		}]
	}
});
var SnContextMenu = class SnContextMenu {
	items = input.required({
		...ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {},
		alias: "snContextMenu"
	});
	native = input("auto", {
		...ngDevMode ? { debugName: "native" } : /* istanbul ignore next */ {},
		alias: "snContextMenuNative"
	});
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		alias: "snContextMenuDisabled",
		transform: booleanAttribute
	});
	trigger = inject(CdkContextMenuTrigger);
	menus = inject(SnNativeMenus);
	hostWindow = inject(SpartanNativeTheme, { optional: true })?.window;
	element = inject(ElementRef).nativeElement;
	family = injectPlatformFamily();
	useNative = computed(() => this.native() !== "never" && this.menus.canShowContextMenu, ...ngDevMode ? [{ debugName: "useNative" }] : /* istanbul ignore next */ []);
	constructor() {
		const templates = createComponent(SnMenuTemplates, {
			environmentInjector: inject(EnvironmentInjector),
			elementInjector: inject(Injector)
		});
		const appRef = inject(ApplicationRef);
		appRef.attachView(templates.hostView);
		templates.changeDetectorRef.detectChanges();
		this.trigger.menuTemplateRef = templates.instance.menu();
		inject(DestroyRef).onDestroy(() => {
			appRef.detachView(templates.hostView);
			templates.destroy();
		});
		effect(() => {
			templates.setInput("family", this.family());
			this.trigger.disabled = this.disabled() || this.useNative();
			this.trigger.menuData = { $implicit: inPageMenu(this.items(), this.family(), {
				minimize: this.hostWindow?.minimize && (() => void this.hostWindow.minimize()),
				toggleMaximize: this.hostWindow?.toggleMaximize && (() => void this.hostWindow.toggleMaximize()),
				close: this.hostWindow?.close && (() => void this.hostWindow.close())
			}) };
		});
	}
	onContextMenu(event) {
		if (this.disabled() || !this.useNative()) return;
		event.preventDefault();
		event.stopPropagation();
		let { clientX: x, clientY: y } = event;
		if (event.button !== 2 && x === 0 && y === 0) {
			const rect = this.element.getBoundingClientRect();
			x = rect.left;
			y = rect.bottom;
		}
		this.menus.showContextMenu(this.items(), {
			x,
			y
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnContextMenu,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnContextMenu,
		isStandalone: true,
		selector: "[snContextMenu]",
		inputs: {
			items: {
				classPropertyName: "items",
				publicName: "snContextMenu",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			native: {
				classPropertyName: "native",
				publicName: "snContextMenuNative",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "snContextMenuDisabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "data-slot": "sn-context-menu-trigger" },
			listeners: { "contextmenu": "onContextMenu($event)" }
		},
		hostDirectives: [{ directive: i1.CdkContextMenuTrigger }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnContextMenu,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[snContextMenu]",
			hostDirectives: [CdkContextMenuTrigger],
			host: {
				"data-slot": "sn-context-menu-trigger",
				"(contextmenu)": "onContextMenu($event)"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "snContextMenu",
				required: true
			}]
		}],
		native: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "snContextMenuNative",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "snContextMenuDisabled",
				required: false
			}]
		}]
	}
});
var SnPlatformIf = class SnPlatformIf {
	platforms = input.required({
		...ngDevMode ? { debugName: "platforms" } : /* istanbul ignore next */ {},
		alias: "snPlatformIf"
	});
	elseTemplate = input(null, {
		...ngDevMode ? { debugName: "elseTemplate" } : /* istanbul ignore next */ {},
		alias: "snPlatformIfElse"
	});
	template = inject(TemplateRef);
	container = inject(ViewContainerRef);
	skin = injectSkin();
	shown = null;
	constructor() {
		effect(() => {
			const skin = this.skin();
			const wanted = [].concat(this.platforms());
			const next = wanted.includes(skin) || wanted.includes(skinFamily(skin)) ? this.template : this.elseTemplate();
			if (next === this.shown) return;
			this.container.clear();
			if (next) this.container.createEmbeddedView(next);
			this.shown = next;
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SnPlatformIf,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: SnPlatformIf,
		isStandalone: true,
		selector: "[snPlatformIf]",
		inputs: {
			platforms: {
				classPropertyName: "platforms",
				publicName: "snPlatformIf",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			elseTemplate: {
				classPropertyName: "elseTemplate",
				publicName: "snPlatformIfElse",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SnPlatformIf,
	decorators: [{
		type: Directive,
		args: [{ selector: "[snPlatformIf]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		platforms: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "snPlatformIf",
				required: true
			}]
		}],
		elseTemplate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "snPlatformIfElse",
				required: false
			}]
		}]
	}
});
const SnWindowImports = [
	SnTitleBar,
	SnWindowControls,
	...SnStatusBarImports
];
const SnControlsImports = [
	...SnSplitButtonImports,
	SnNumberBox,
	...SnTreeImports,
	SnTooltip
];
const SnMenuImports = [SnMenubar, SnContextMenu];
const SnSettingsImports = [SnSettingsGroup, SnSettingsRow];
const SnPlatformImports = [SnPlatformIf, SnShortcut];
const SnDesktopUiImports = [
	...SnWindowImports,
	...SnSettingsImports,
	SnStatusPage,
	...SnCommandBarImports,
	...SnCoachMarkImports,
	SnModalSheet,
	...SnInspectorImports,
	...SnSidebarNavImports,
	...SnAssistantImports,
	...SnChecklistImports,
	...SnControlsImports,
	...SnMenuImports,
	...SnPlatformImports
];
export { SnAssistant, SnAssistantImports, SnAssistantPage, SnChecklist, SnChecklistImports, SnChecklistItem, SnCoachMark, SnCoachMarkFor, SnCoachMarkImports, SnCommand, SnCommandBar, SnCommandBarImports, SnCommandGroup, SnCommandOverflow, SnContextMenu, SnControlsImports, SnDesktopUiImports, SnInspector, SnInspectorImports, SnInspectorLayout, SnInspectorProperty, SnInspectorSection, SnMenuImports, SnMenubar, SnModalSheet, SnNativeMenus, SnNumberBox, SnPlatformIf, SnPlatformImports, SnSettingsGroup, SnSettingsImports, SnSettingsRow, SnShortcut, SnSidebarItem, SnSidebarNav, SnSidebarNavImports, SnSidebarSection, SnSplitButton, SnSplitButtonImports, SnSplitButtonMenu, SnStatusBar, SnStatusBarImports, SnStatusItem, SnStatusPage, SnTitleBar, SnTooltip, SnTooltipPanel, SnTree, SnTreeImports, SnTreeItem, SnWindowControls, SnWindowImports, coachMarkPositions, coachMarkSide, evaluateNumberExpression, formatShortcut, inPageMenu, itemsWithAccelerators, matchesAccelerator, nextIndex, runEditCommand, tidyMenu, toHostMenu };

//# sourceMappingURL=spartan-native-desktop-ui.mjs.map