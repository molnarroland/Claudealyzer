import * as i0 from "@angular/core";
import { TemplateRef } from "@angular/core";
import { FocusableOption } from "@angular/cdk/a11y";
import { ConnectedPosition } from "@angular/cdk/overlay";
import { MenuItem, PlatformFamily, Skin } from "@spartan-native/theme";
import { ControlValueAccessor } from "@angular/forms";
import * as i1 from "@angular/cdk/menu";
export type WindowButton = 'minimize' | 'maximize' | 'close';
/**
 * The window's own buttons, drawn the way the OS draws them:
 *  - Windows 11 (`win`): minimize / maximize / close caption buttons on the right; close turns red
 *  - Windows 10 (`w10`): the same caption buttons with square glyphs and the Windows 10 red
 *  - macOS 26 (`mac`) and macOS 13–15 (`macc`): the traffic lights (close / minimize / zoom);
 *    glyphs appear on hover; grey when the window is inactive
 *  - GNOME (`gtk`): a round close button, the GNOME default button layout (`linuxAll` adds the other two)
 *  - KDE Plasma (`qt`): Breeze buttons: chevron minimize / maximize and a close cross;
 *    a circle appears on hover, red for close
 *  - ChromeOS (`cros`): Material 3 round caption buttons
 *
 * Use it inside <sn-title-bar>, or on its own wherever your layout puts it
 * (on macOS the lights often sit at the top of the sidebar).
 *
 * ```html
 * <sn-window-controls />   <!-- in Wails, Tauri, … the buttons act on the real window -->
 * <sn-window-controls [nativeActions]="false" (close)="confirmAndClose()" />
 * ```
 *
 * With a host that owns a window (wailsHost(), …) the buttons minimize, maximize and close
 * it, and the maximize glyph follows the real state. The outputs always fire too.
 */
export declare class SnWindowControls {
  /** Which buttons to show. Close is always shown. */
  readonly buttons: import("@angular/core").InputSignal<readonly WindowButton[]>;
  /** Show the restore glyph instead of maximize (all but macOS). */
  readonly maximized: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** GNOME shows only close by default; set to show minimize and maximize too. */
  readonly linuxAll: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Act on the host's real window (when it has one). Default: true. */
  readonly nativeActions: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly minimize: import("@angular/core").OutputEmitterRef<void>;
  readonly maximize: import("@angular/core").OutputEmitterRef<void>;
  readonly close: import("@angular/core").OutputEmitterRef<void>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  /** Which button set to draw: KDE and ChromeOS have their own, the web family shares GNOME's. */
  protected readonly look: import("@angular/core").Signal<"cros" | "windows" | "macos" | "kde" | "gnome">;
  private readonly hostWindow;
  private readonly hostMaximized;
  protected readonly isMaximized: import("@angular/core").Signal<boolean>;
  constructor();
  protected act(action: WindowButton): void;
  protected show(button: WindowButton): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnWindowControls, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnWindowControls, "sn-window-controls", never, {
    "buttons": {
      "alias": "buttons";
      "required": false;
      "isSignal": true;
    };
    "maximized": {
      "alias": "maximized";
      "required": false;
      "isSignal": true;
    };
    "linuxAll": {
      "alias": "linuxAll";
      "required": false;
      "isSignal": true;
    };
    "nativeActions": {
      "alias": "nativeActions";
      "required": false;
      "isSignal": true;
    };
  }, {
    "minimize": "minimize";
    "maximize": "maximize";
    "close": "close";
  }, never, never, true, never>;
}
/**
 * A complete title bar, laid out the way each OS does it:
 *  - Windows 11 (`win`) / Windows 10 (`w10`): app icon and title on the left, caption buttons on the right
 *  - macOS 26 (`mac`): traffic lights on the left, title centered, a 38px unified bar
 *  - macOS 13–15 (`macc`): the classic 28px title bar, lights inset 8px, title centered
 *  - GNOME (`gtk`): an AdwHeaderBar, bold title centered, close button on the right
 *  - KDE Plasma (`qt`): the Breeze title bar: app icon on the left, title centered,
 *    minimize / maximize / close on the right
 *  - ChromeOS (`cros`): the caption bar: app icon and title on the left, round M3 caption buttons on the right
 *
 * The bar is a window drag region for Electron/Chromium (`app-region`), Wails
 * (`--wails-draggable`) and Tauri (`data-tauri-drag-region`); buttons inside are not.
 * It carries `sn-chrome`, so the theme dims it when the window is inactive.
 *
 * ```html
 * <sn-title-bar title="Harbor Backup" (close)="host.close()">
 *   <img snTitleBarIcon src="icon.svg" alt="" />
 *   <button hlmBtn variant="ghost" snTitleBarEnd>…</button>
 * </sn-title-bar>
 * ```
 *
 * Set `windowControls="native"` when the OS draws its own buttons
 * (Electron titleBarOverlay, Window Controls Overlay, a macOS hidden-inset title bar): space is
 * left for them where the real OS puts them, so a Mac dressed as Windows keeps the room for its
 * traffic lights at the start, and the layout of the rest follows the skin.
 */
export declare class SnTitleBar {
  /** The window title. */
  readonly title: import("@angular/core").InputSignal<string>;
  /** A second, smaller line under the title. */
  readonly subtitle: import("@angular/core").InputSignal<string>;
  /** `custom`: draw the window buttons · `native`: the OS draws them (leave space). */
  readonly windowControls: import("@angular/core").InputSignal<"custom" | "native">;
  /** Which window buttons to draw. Close is always drawn. */
  readonly buttons: import("@angular/core").InputSignal<readonly WindowButton[]>;
  /** Show the restore glyph instead of maximize. */
  readonly maximized: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly minimize: import("@angular/core").OutputEmitterRef<void>;
  readonly maximize: import("@angular/core").OutputEmitterRef<void>;
  readonly close: import("@angular/core").OutputEmitterRef<void>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  /** The real OS's skin: where and how big its own window buttons are. */
  protected readonly nativeSkin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  /** Windows, KDE and ChromeOS show the app icon in the title bar; macOS and GNOME don't. */
  protected readonly showIcon: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnTitleBar, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnTitleBar, "sn-title-bar", never, {
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
    "subtitle": {
      "alias": "subtitle";
      "required": false;
      "isSignal": true;
    };
    "windowControls": {
      "alias": "windowControls";
      "required": false;
      "isSignal": true;
    };
    "buttons": {
      "alias": "buttons";
      "required": false;
      "isSignal": true;
    };
    "maximized": {
      "alias": "maximized";
      "required": false;
      "isSignal": true;
    };
  }, {
    "minimize": "minimize";
    "maximize": "maximize";
    "close": "close";
  }, never, ["[snTitleBarIcon]", "[snTitleBarStart]", "[snTitleBarEnd]"], true, never>;
}
/**
 * One piece of information in an `<sn-status-bar>`: "4 items", "1 selected · 48 KB",
 * "Last backup 09:12". The bar separates items the way the OS does (spacing on Windows 11,
 * vertical rules on Windows 10 and KDE, commas on macOS).
 *
 * `live` makes a screen reader announce changes to this item (e.g. a progress message);
 * leave it off for text that changes on every selection, so it doesn't interrupt.
 */
export declare class SnStatusItem {
  readonly live: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnStatusItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnStatusItem, "[snStatusItem]", never, {
    "live": {
      "alias": "live";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The window's status bar, along the bottom edge:
 *  - Windows 11: File Explorer's status bar, small text, items spaced apart, no rules
 *  - Windows 10: the classic status bar, items divided by vertical rules
 *  - macOS 26 / 13–15: Finder's status bar, small centered text, items joined by commas
 *  - GNOME: a GtkActionBar at the bottom of an AdwToolbarView (start · end)
 *  - KDE: Dolphin's status bar, items divided by rules, extra controls (zoom, free space) at the end
 *  - ChromeOS: a slim M3 footer, muted label-medium text
 *
 * ```html
 * <sn-status-bar>
 *   <span snStatusItem>4 items</span>
 *   <span snStatusItem>1 selected · 48 KB</span>
 *   <span snStatusItem snStatusBarEnd>1.2 TB free</span>
 * </sn-status-bar>
 * ```
 *
 * `[snStatusBarEnd]` items go to the trailing edge (on macOS they join the centered text).
 * It carries `sn-chrome`, so the theme dims it when the window is inactive.
 */
export declare class SnStatusBar {
  /** Accessible name of the bar. */
  readonly ariaLabel: import("@angular/core").InputSignal<string>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnStatusBar, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnStatusBar, "sn-status-bar", never, {
    "ariaLabel": {
      "alias": "ariaLabel";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*", "[snStatusBarEnd]"], true, never>;
}
export declare const SnStatusBarImports: readonly [typeof SnStatusBar, typeof SnStatusItem];
/**
 * A group of settings rows, drawn as each OS draws its settings:
 *  - Windows 11 (`win`): a stack of SettingsCards under a section title
 *  - Windows 10 (`w10`): the Settings app's plain list: a light heading, label above each control
 *  - macOS 26 (`mac`): a grouped Form section (small header above an inset rounded glass list)
 *  - macOS 13–15 (`macc`): the same section with the classic corner and vibrancy
 *  - GNOME (`gtk`): AdwPreferencesGroup (bold title above a boxed list)
 *  - KDE Plasma (`qt`): a Kirigami FormLayout (centered section title, "Label:" right-aligned
 *    in one column, controls in the next, help text under the control; icons hidden)
 *  - ChromeOS (`cros`): a Settings list (M3 list rows inside a tonal card)
 *
 * ```html
 * <sn-settings-group title="Backups" description="Choose when and how backups run.">
 *   <sn-settings-row title="Automatic backups" subtitle="Run in the background">
 *     <hlm-switch [checked]="true" aria-label="Automatic backups" />
 *   </sn-settings-row>
 * </sn-settings-group>
 * ```
 */
export declare class SnSettingsGroup {
  /** The group heading (labels the group for assistive tech). */
  readonly title: import("@angular/core").InputSignal<string>;
  /** A line of explanation under the heading. */
  readonly description: import("@angular/core").InputSignal<string>;
  protected readonly headingId: string;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnSettingsGroup, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnSettingsGroup, "sn-settings-group", never, {
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * One setting: title, optional subtitle, and its control on the trailing side
 * (Windows 10: below the label; KDE: in the FormLayout's control column).
 * Put an icon in front with `snSettingsIcon` (hidden on Windows 10 and KDE, which don't use them).
 */
export declare class SnSettingsRow {
  /** The setting's name (on KDE: the FormLayout label). */
  readonly title: import("@angular/core").InputSignal<string>;
  /** Help text (on KDE: shown under the control). */
  readonly subtitle: import("@angular/core").InputSignal<string>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnSettingsRow, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnSettingsRow, "sn-settings-row", never, {
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "subtitle": {
      "alias": "subtitle";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[snSettingsIcon]", "*"], true, never>;
}
/**
 * A full-page empty or status state:
 *  - Windows 11 (`win`) / Windows 10 (`w10`): a Fluent empty state (accent glyph in a tinted circle,
 *    subtitle-size title)
 *  - macOS 26 (`mac`) / macOS 13–15 (`macc`): ContentUnavailableView (medium grey icon, bold title)
 *  - GNOME (`gtk`): AdwStatusPage (128px faded icon, big heavy title, pill buttons)
 *  - KDE Plasma (`qt`): Kirigami PlaceholderMessage (faded 64px icon, muted level-2 heading)
 *  - ChromeOS (`cros`): the Material 3 empty state (icon in a primary-container circle, light headline)
 *
 * `icon` is an @ng-icons name the app has registered with provideIcons().
 * Buttons go in the content.
 *
 * ```html
 * <sn-status-page icon="lucideArchive" title="No backups yet" description="Add a destination to start protecting your files.">
 *   <button hlmBtn>Add destination</button>
 * </sn-status-page>
 * ```
 */
export declare class SnStatusPage {
  /** An @ng-icons name registered with provideIcons(). Leave empty for no icon. */
  readonly icon: import("@angular/core").InputSignal<string>;
  /** The headline. */
  readonly title: import("@angular/core").InputSignal<string>;
  /** A sentence that says what to do next. */
  readonly description: import("@angular/core").InputSignal<string>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnStatusPage, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnStatusPage, "sn-status-page", never, {
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * One entry of a desktop-ui menu: the host's plain `MenuItem`, plus the function to run.
 * The same data feeds a native menu (the macOS menu bar, an OS context menu) and the
 * in-page menu that stands in for it elsewhere.
 *
 * ```ts
 * const menu: SnMenuItem[] = [
 *   { role: 'appMenu' },
 *   { label: 'File', submenu: [
 *     { label: 'New backup…', accelerator: 'mod+n', action: () => this.create() },
 *     { type: 'separator' },
 *     { role: 'close' },
 *   ]},
 *   { role: 'editMenu' },
 * ];
 * ```
 */
export interface SnMenuItem extends Omit<MenuItem, 'submenu'> {
  /** Runs when the item is chosen (also from its accelerator in the in-page menubar). */
  readonly action?: () => void;
  readonly submenu?: readonly SnMenuItem[];
}
/** The window actions a role can fall back to in the page. */
export interface SnMenuWindowActions {
  minimize?(): void;
  toggleMaximize?(): void;
  close?(): void;
}
/**
 * Converts to the host's plain data: every item with an `action` gets an `id` (its own, or a
 * generated one), and `actions` maps the ids back to the items.
 */
export declare function toHostMenu(items: readonly SnMenuItem[], actions?: Map<string, SnMenuItem>): {
  menu: MenuItem[];
  actions: Map<string, SnMenuItem>;
};
/** Drops separators at the edges and next to each other, and submenus left empty. */
export declare function tidyMenu(items: readonly SnMenuItem[]): SnMenuItem[];
/**
 * Replaces roles with ordinary items for an in-page menu: Edit and Window submenus, edit
 * commands on the focused field, the window actions through the host. Roles that have no
 * meaning in a page (the macOS app menu, About without an action) are left out.
 */
export declare function inPageMenu(items: readonly SnMenuItem[], family: PlatformFamily, window?: SnMenuWindowActions, run?: (command: EditCommand) => void): SnMenuItem[];
export type EditCommand = 'undo' | 'redo' | 'cut' | 'copy' | 'paste' | 'selectAll';
/** Runs an edit command on the focused field, as the OS Edit menu would. */
export declare function runEditCommand(command: EditCommand): void;
/** Whether a key event is the accelerator (`mod` is ⌘ on macOS, Ctrl elsewhere). */
export declare function matchesAccelerator(event: KeyboardEvent, accelerator: string, family: PlatformFamily): boolean;
/** Every item with an action and an accelerator, at any depth (for the in-page key bindings). */
export declare function itemsWithAccelerators(items: readonly SnMenuItem[]): SnMenuItem[];
/** @internal The bubble. Styled by the theme, per skin, like hlmTooltip (data-slot="sn-tooltip"). */
export declare class SnTooltipPanel {
  readonly text: import("@angular/core").WritableSignal<string>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnTooltipPanel, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnTooltipPanel, "sn-tooltip-panel", never, {}, {}, never, never, true, never>;
}
/**
 * A short label that shows when the pointer rests on an element, or when it gets the keyboard
 * focus, drawn the way the active skin draws tooltips (a light card on Windows 11 and macOS, an
 * inverse bubble on GNOME, a framed surface on KDE, an M3 plain tooltip on ChromeOS).
 *
 * The text is a visual hint only (the bubble is `aria-hidden`): give the element its own
 * accessible name. Esc and a click hide it. An empty text shows nothing.
 *
 * ```html
 * <button hlmBtn size="icon" aria-label="Refresh" snTooltip="Refresh">…</button>
 * ```
 */
export declare class SnTooltip {
  /** The text. Empty: no tooltip. */
  readonly snTooltip: import("@angular/core").InputSignal<string>;
  readonly snTooltipDisabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Set by components that own the tooltip (e.g. snCommand); wins over the input. */
  readonly text: import("@angular/core").WritableSignal<string | null>;
  private readonly shown;
  private readonly element;
  private readonly injector;
  private readonly modality;
  private overlay;
  private panel;
  private timer;
  constructor();
  protected onPointerEnter(event: PointerEvent): void;
  /** Keyboard focus shows it at once; a click's focus doesn't. */
  protected onFocus(): void;
  private schedule;
  /** Shows the tooltip now (no delay). */
  show(): void;
  /** Hides the tooltip and cancels a pending one. */
  hide(): void;
  private clearTimer;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnTooltip, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnTooltip, "[snTooltip]", never, {
    "snTooltip": {
      "alias": "snTooltip";
      "required": false;
      "isSignal": true;
    };
    "snTooltipDisabled": {
      "alias": "snTooltipDisabled";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** Where the title sits: the skin's own place, or forced to the start or the center. */
export type SnCommandBarTitlePosition = 'auto' | 'start' | 'center';
/**
 * What the bar does when it is too narrow: `auto` first drops the labels (on skins that show
 * them), then moves commands into the overflow menu, lowest `priority` first; `none` does neither.
 */
export type SnCommandBarCollapse = 'auto' | 'none';
/**
 * The secondary commands as your own menu, shown by the bar's overflow button (Windows `…`,
 * macOS `…`, GNOME/KDE menu button, ChromeOS `⋮`). Put a stock menu inside, e.g. hlmDropdownMenu:
 *
 * ```html
 * <ng-template snCommandOverflow>
 *   <div hlmDropdownMenu>
 *     <button hlmDropdownMenuItem>Rename</button>
 *   </div>
 * </ng-template>
 * ```
 *
 * It is used while the bar has nothing of its own to put in the menu. Once commands collapse
 * into the overflow (or are `secondary`, or `overflowItems` is set), the bar draws the menu
 * itself: prefer `secondary` commands and `overflowItems` with a collapsing bar.
 */
export declare class SnCommandOverflow {
  readonly template: TemplateRef<any>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnCommandOverflow, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnCommandOverflow, "ng-template[snCommandOverflow]", never, {}, {}, never, never, true, never>;
}
/**
 * A group of commands that belong together: on macOS 26 each group is its own Liquid Glass
 * capsule, elsewhere groups are divided by a separator (Windows, GNOME, KDE) or a gap (ChromeOS).
 *
 * ```html
 * <sn-command-group label="History">
 *   <button snCommand icon="lucideUndo2" label="Undo"></button>
 *   <button snCommand icon="lucideRedo2" label="Redo"></button>
 * </sn-command-group>
 * ```
 */
export declare class SnCommandGroup {
  /** Accessible name of the group. */
  readonly label: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnCommandGroup, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnCommandGroup, "sn-command-group", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * One command in an `<sn-command-bar>`: an icon and a label.
 * The label is visible on Windows and KDE; on macOS, GNOME and ChromeOS the command is
 * icon-only, the label stays as its accessible name and shows as the skin's tooltip.
 * Without `icon`, project your own `<svg>`/`<ng-icon>`, or none (then the label always shows).
 *
 * When the bar runs out of room, commands move into its overflow menu, lowest `priority` first.
 * `secondary` commands always live there.
 */
export declare class SnCommand implements FocusableOption {
  readonly icon: import("@angular/core").InputSignal<string>;
  readonly label: import("@angular/core").InputSignal<string>;
  readonly isDisabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Show only the icon on every OS (the label stays as accessible name and tooltip). */
  readonly hideLabel: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** `accent`: the window's main action, filled with the accent color (Fluent accent, macOS prominent). */
  readonly variant: import("@angular/core").InputSignal<"default" | "accent">;
  /** Commands with a lower priority move into the overflow menu first. Default: 0. */
  readonly priority: import("@angular/core").InputSignalWithTransform<number, unknown>;
  /** Always in the overflow menu, never in the bar (WinUI secondary commands). */
  readonly secondary: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Set by the bar: the one command in the tab order (roving tabindex). */
  readonly tabbable: import("@angular/core").WritableSignal<boolean>;
  /** Set by the bar: in the overflow menu instead of the bar. */
  readonly collapsed: import("@angular/core").WritableSignal<boolean>;
  readonly element: HTMLButtonElement;
  private readonly bar;
  protected readonly iconOnly: import("@angular/core").Signal<boolean>;
  constructor();
  /** For the key manager: collapsed commands are skipped like disabled ones. */
  get disabled(): boolean;
  focus(): void;
  /** @internal Moves the command into (or out of) the overflow menu, right away in the DOM so the bar can measure. */
  setCollapsed(collapsed: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnCommand, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnCommand, "button[snCommand]", never, {
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "isDisabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "hideLabel": {
      "alias": "hideLabel";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "priority": {
      "alias": "priority";
      "required": false;
      "isSignal": true;
    };
    "secondary": {
      "alias": "secondary";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, [{
    directive: typeof SnTooltip;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * The window's command surface, with the same markup on every OS:
 *  - Windows 11: a CommandBar, title left, commands right with the label beside the icon, `…` overflow
 *  - Windows 10: the same, labels under the icons, square
 *  - macOS 26: a unified toolbar, title left, icon-only commands in Liquid Glass capsules (macOS 13–15: plain bezels)
 *  - GNOME: an AdwHeaderBar, commands at the start, title centered, menu button at the end
 *  - KDE: a KToolBar, title then commands with text beside the icon, menu button at the end
 *  - ChromeOS: an M3 top app bar, title left, round icon actions right, `⋮` overflow
 *
 * The title is a heading (`headingLevel`, default 1) and goes where the skin puts it, or where
 * `titlePosition` says. A centered title stays centered while it fits and moves aside instead
 * of running under the commands.
 *
 * The commands form one `role="toolbar"`: Tab enters it once, ← → Home End move between
 * commands (disabled ones are skipped), ↓ or Enter on the overflow button opens its menu.
 * When the bar is too narrow, labels drop first (Windows, KDE), then commands move into the
 * overflow menu by `priority`.
 *
 * ```html
 * <sn-command-bar title="Documents">
 *   <button snCommand icon="lucidePlus" label="New" variant="accent" (click)="create()"></button>
 *   <sn-command-group label="Selection">
 *     <button snCommand icon="lucideShare2" label="Share" priority="1"></button>
 *     <button snCommand icon="lucideTrash2" label="Delete" [disabled]="!selection()"></button>
 *   </sn-command-group>
 *   <button snCommand icon="lucidePencil" label="Rename" secondary></button>
 * </sn-command-bar>
 * ```
 *
 * Commands declared elsewhere (a page's commands shown by the shell's bar): pass them as a
 * template, `<sn-command-bar [commands]="page.commands()">`. Commands in it work exactly like
 * projected ones.
 *
 * Extra content: `[snCommandBarStart]` (e.g. a back button, or the window controls when the
 * bar is the title bar) and `[snCommandBarEnd]` (e.g. a search field). It carries `sn-chrome`,
 * so the theme dims it when the window is inactive.
 */
export declare class SnCommandBar {
  readonly title: import("@angular/core").InputSignal<string>;
  /** Where the title goes. `auto`: the skin's place (centered on GNOME, at the start elsewhere). */
  readonly titlePosition: import("@angular/core").InputSignal<SnCommandBarTitlePosition>;
  /** The title's heading level (`role="heading"`). 0: not a heading. Default: 1. */
  readonly headingLevel: import("@angular/core").InputSignalWithTransform<number, unknown>;
  /** Accessible name of the toolbar; defaults to `title`. */
  readonly ariaLabel: import("@angular/core").InputSignal<string>;
  /** Accessible name and tooltip of the overflow button. */
  readonly overflowLabel: import("@angular/core").InputSignal<string>;
  /** Commands declared somewhere else, e.g. by the current page. Rendered after the projected ones. */
  readonly commands: import("@angular/core").InputSignal<TemplateRef<unknown> | null>;
  /** More entries for the overflow menu, after the collapsed and secondary commands. */
  readonly overflowItems: import("@angular/core").InputSignal<readonly SnMenuItem[]>;
  /** What happens when the bar is too narrow. Default: `auto`. */
  readonly collapse: import("@angular/core").InputSignal<SnCommandBarCollapse>;
  protected readonly skin: import("@angular/core").Signal<Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  /** The real OS: how shortcuts in the overflow menu are written. */
  protected readonly platform: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  /** macOS, GNOME, ChromeOS: commands show only their icon. */
  readonly iconOnly: import("@angular/core").Signal<boolean>;
  /** The bar dropped the labels to make room. */
  readonly compact: import("@angular/core").WritableSignal<boolean>;
  protected readonly resolvedTitlePosition: import("@angular/core").Signal<"center" | "start">;
  /** GNOME puts the commands at the start of the header bar, before the title. */
  protected readonly commandsLead: import("@angular/core").Signal<boolean>;
  protected readonly moreGlyph: import("@angular/core").Signal<"menu" | "vertical" | "dots">;
  protected readonly overflow: import("@angular/core").Signal<SnCommandOverflow | undefined>;
  protected readonly menuPosition: ConnectedPosition[];
  protected readonly commandInjector: import("@angular/core").DestroyableInjector;
  private readonly host;
  private readonly titleEl;
  private readonly more;
  private readonly registered;
  /** The commands in document order (projected, grouped, and from `[commands]`). */
  private readonly ordered;
  /** The commands currently in the overflow menu, in document order. */
  private readonly collapsedCommands;
  /** The overflow menu the bar draws: collapsed and secondary commands, then `overflowItems`. */
  protected readonly menuItems: import("@angular/core").Signal<SnMenuItem[]>;
  /** Every command in document order, the overflow button included (it is a command too). */
  private readonly items;
  /** The view exists (fit() measures it). */
  private rendered;
  /** Bumped after each fit: which commands are hidden changed. */
  private readonly fitted;
  private readonly active;
  private readonly keys;
  constructor();
  /** @internal */
  register(command: SnCommand): void;
  /** @internal */
  unregister(command: SnCommand): void;
  /**
   * Makes the commands fit: shows them all, then, while the bar overflows or the title is cut,
   * drops the labels (labelled skins), then collapses commands into the overflow menu, lowest
   * priority first (the later one first on a tie). Works on the DOM directly, so every step is
   * measured before the next.
   */
  private fit;
  protected onKeydown(event: KeyboardEvent): void;
  protected onFocusin(event: FocusEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnCommandBar, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnCommandBar, "sn-command-bar", never, {
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
    "titlePosition": {
      "alias": "titlePosition";
      "required": false;
      "isSignal": true;
    };
    "headingLevel": {
      "alias": "headingLevel";
      "required": false;
      "isSignal": true;
    };
    "ariaLabel": {
      "alias": "ariaLabel";
      "required": false;
      "isSignal": true;
    };
    "overflowLabel": {
      "alias": "overflowLabel";
      "required": false;
      "isSignal": true;
    };
    "commands": {
      "alias": "commands";
      "required": false;
      "isSignal": true;
    };
    "overflowItems": {
      "alias": "overflowItems";
      "required": false;
      "isSignal": true;
    };
    "collapse": {
      "alias": "collapse";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["overflow"], ["[snCommandBarStart]", "[snCommandBarEnd]", "*"], true, never>;
}
export declare const SnCommandBarImports: readonly [typeof SnCommandBar, typeof SnCommand, typeof SnCommandGroup, typeof SnCommandOverflow];
/** The side of the anchor the coach mark prefers. It flips to the opposite side when there is no room. */
export type CoachMarkPlacement = 'top' | 'bottom' | 'start' | 'end';
/** The physical side of the anchor the coach mark ended up on (the beak points back at the anchor). */
export type CoachMarkSide = 'top' | 'bottom' | 'left' | 'right';
/**
 * Overlay positions for a placement: centered on the anchor first, then aligned to its start and end
 * edges, then the same three on the opposite side.
 */
export declare function coachMarkPositions(placement: CoachMarkPlacement): ConnectedPosition[];
type Box = Pick<DOMRect, 'top' | 'bottom' | 'left' | 'right'>;
/** Which side of the anchor the coach mark sits on, from the two rectangles. */
export declare function coachMarkSide(tip: Box, anchor: Box): CoachMarkSide;
/**
 * An anchored, non-modal teaching popup: title, body, an optional icon or hero image,
 * a close button and action buttons.
 *  - Windows 11 / 10: TeachingTip (native): acrylic card with a tail, stretched buttons, primary first
 *  - macOS 26 / 13–15: NSPopover: glass popover with an arrow, buttons right-aligned, primary last
 *  - GNOME: GtkPopover: opaque rounded popover with an arrow, buttons at the end
 *  - KDE Plasma: Kirigami popup: Breeze frame, no arrow, primary first
 *  - ChromeOS: Material 3 rich tooltip: tonal container, no arrow, text buttons at the start
 *
 * Anchor it with `[snCoachMarkFor]`. Write the actions secondary first, primary last
 * (the mockup order); Windows and KDE show them reversed. It doesn't take focus when it opens,
 * but it is placed right after the anchor in the tab order; Esc closes it and returns focus to the anchor.
 *
 * ```html
 * <button hlmBtn [snCoachMarkFor]="tip" (click)="tip.toggle()">Sync</button>
 * <sn-coach-mark #tip title="Sync across devices" [(open)]="showTip">
 *   Turn on sync to keep your backups available on every device you sign in to.
 *   <button snCoachMarkAction hlmBtn variant="secondary" (click)="tip.hide()">Not now</button>
 *   <button snCoachMarkAction hlmBtn (click)="turnOnSync()">Turn on</button>
 * </sn-coach-mark>
 * ```
 *
 * The host gets `data-placed` once the overlay has positioned it, and `data-side` with the side it landed on.
 */
export declare class SnCoachMark {
  readonly title: import("@angular/core").InputSignal<string>;
  /** An @ng-icons name the app has registered, shown before the title. */
  readonly icon: import("@angular/core").InputSignal<string>;
  readonly placement: import("@angular/core").InputSignal<CoachMarkPlacement>;
  readonly closeLabel: import("@angular/core").InputSignal<string>;
  readonly open: import("@angular/core").ModelSignal<boolean>;
  /** Set by `[snCoachMarkFor]`. */
  readonly anchor: import("@angular/core").WritableSignal<HTMLElement | null>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  protected readonly titleId: string;
  readonly bodyId: string;
  private readonly host;
  private readonly document;
  private readonly injector;
  private overlay?;
  private strategy?;
  private overlayAnchor?;
  constructor();
  show(): void;
  hide(): void;
  toggle(): void;
  protected onEscape(event: Event): void;
  private attach;
  private detach;
  /** After each positioning: which side it landed on and where the beak points. */
  private placed;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnCoachMark, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnCoachMark, "sn-coach-mark", never, {
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
    "closeLabel": {
      "alias": "closeLabel";
      "required": false;
      "isSignal": true;
    };
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
  }, never, ["[snCoachMarkHero]", "*", "[snCoachMarkAction]"], true, never>;
}
/**
 * Anchors a `<sn-coach-mark>` to this element. Esc on the anchor closes the open coach mark,
 * and the anchor is described by the coach mark while it is open.
 */
export declare class SnCoachMarkFor {
  readonly snCoachMarkFor: import("@angular/core").InputSignal<SnCoachMark>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<SnCoachMarkFor, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnCoachMarkFor, "[snCoachMarkFor]", never, {
    "snCoachMarkFor": {
      "alias": "snCoachMarkFor";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare const SnCoachMarkImports: readonly [typeof SnCoachMark, typeof SnCoachMarkFor];
/**
 * A modal form whose layout follows the OS:
 *  - macOS: a sheet that slides down from under the window's title bar, no title bar of its own,
 *    buttons bottom-right with the default button rightmost
 *  - Windows: a ContentDialog, centered over a smoke backdrop, title top-left, buttons in a footer
 *    band (primary first, buttons share the width)
 *  - GNOME: an AdwDialog, Cancel and the primary button in a header bar around a centered title, no footer
 *  - KDE: a window-modal QDialog with a frame and a title strip, buttons bottom-right (primary, then Cancel)
 *  - ChromeOS: a Material 3 dialog, large corners, headline, actions at the bottom end
 *
 * Mark the buttons with `snSheetCancel` and `snSheetPrimary` so they can be placed per OS.
 * Esc and the Cancel button close the sheet (`open` becomes false); the primary button is yours to handle.
 * A third button that doesn't close the sheet (Back, Don't Save, Help) goes in `snSheetSecondary`:
 * at the leading edge on macOS, KDE and ChromeOS, between primary and Cancel on Windows, and in
 * a row under the content on GNOME.
 * On macOS the sheet hangs from the title bar of the nearest ancestor marked `snSheetHost`
 * (the window frame); without one it hangs from the top of the viewport.
 *
 * ```html
 * <div class="sn-window" snSheetHost>
 *   <sn-title-bar title="Harbor Backup" />
 *   <sn-modal-sheet [(open)]="adding" title="New destination">
 *     <label hlmLabel>Name <input hlmInput /></label>
 *     <button hlmBtn variant="outline" snSheetCancel>Cancel</button>
 *     <button hlmBtn variant="outline" snSheetSecondary (click)="back()">Back</button>
 *     <button hlmBtn snSheetPrimary (click)="create()">Create</button>
 *   </sn-modal-sheet>
 * </div>
 * ```
 */
export declare class SnModalSheet {
  readonly open: import("@angular/core").ModelSignal<boolean>;
  readonly title: import("@angular/core").InputSignal<string>;
  /** Use `alertdialog` for confirmations (e.g. a destructive action). */
  readonly role: import("@angular/core").InputSignal<"dialog" | "alertdialog">;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  protected readonly titleId: string;
  private readonly panel;
  private readonly dialog;
  private readonly injector;
  private readonly host;
  private ref?;
  constructor();
  private show;
  /** The viewport y where a macOS sheet hangs from: the host window's title bar, else its top edge. */
  private sheetTop;
  private position;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnModalSheet, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnModalSheet, "sn-modal-sheet", never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "role": {
      "alias": "role";
      "required": false;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
  }, never, ["*", "[snSheetSecondary]", "[snSheetCancel]", "[snSheetPrimary]"], true, never>;
}
/**
 * Lays out the main content with an `<sn-inspector>` on the trailing side. Below 40rem of
 * width the inspector floats over the content instead of squeezing it (AdwOverlaySplitView).
 *
 * ```html
 * <sn-inspector-layout>
 *   <div snSelectable [(selection)]="selected">…</div>
 *   <sn-inspector [(open)]="infoOpen" [title]="file().name" icon="lucideFileText">…</sn-inspector>
 * </sn-inspector-layout>
 * ```
 */
export declare class SnInspectorLayout {
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnInspectorLayout, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnInspectorLayout, "sn-inspector-layout", never, {}, {}, never, ["*", "sn-inspector"], true, never>;
}
/**
 * The detail side panel for the current selection:
 *  - macOS: Inspector, a glass trailing column with section headers (floating on macOS 26)
 *  - Windows: SplitView pane on the trailing side with a stroke divider
 *  - GNOME: AdwOverlaySplitView sidebar (sidebar color, header-bar title; overlays on narrow widths)
 *  - KDE: Dolphin information panel, big preview icon on top, then the properties
 *  - ChromeOS: Material 3 side sheet with a headline and a close button
 *
 * `icon` is an @ng-icons name the app registered with provideIcons(). Hidden while `open` is false.
 *
 * ```html
 * <sn-inspector [(open)]="infoOpen" title="Q3 report.pdf" icon="lucideFileText">
 *   <sn-inspector-section title="General">
 *     <sn-inspector-property label="Kind">PDF document</sn-inspector-property>
 *     <sn-inspector-property label="Size">2.4 MB</sn-inspector-property>
 *   </sn-inspector-section>
 * </sn-inspector>
 * ```
 */
export declare class SnInspector {
  /** Shown or hidden. Two-way bindable; the ChromeOS close button sets it to false. */
  readonly open: import("@angular/core").ModelSignal<boolean>;
  /** The panel's heading, usually the selected item's name; also its accessible name. */
  readonly title: import("@angular/core").InputSignal<string>;
  /** Preview icon above (KDE) or next to the title. */
  readonly icon: import("@angular/core").InputSignal<string>;
  protected readonly headingId: string;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnInspector, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnInspector, "sn-inspector", never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
  }, never, ["*"], true, never>;
}
/** A titled group of properties or controls inside the inspector ("General", "Sharing", …). */
export declare class SnInspectorSection {
  readonly title: import("@angular/core").InputSignal<string>;
  protected readonly headingId: string;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnInspectorSection, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnInspectorSection, "sn-inspector-section", never, {
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * A label/value row. The value is the content. macOS and KDE align labels in a column
 * ("Kind: PDF document"); Windows, GNOME and ChromeOS stack a small label above the value.
 */
export declare class SnInspectorProperty {
  readonly label: import("@angular/core").InputSignal<string>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnInspectorProperty, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnInspectorProperty, "sn-inspector-property", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export declare const SnInspectorImports: readonly [typeof SnInspectorLayout, typeof SnInspector, typeof SnInspectorSection, typeof SnInspectorProperty];
/**
 * The app's sidebar navigation, with the platform's selection idiom on the current item:
 *  - Windows 11: NavigationView, hover fill plus the accent pill on the selected item
 *  - Windows 10: square items, `primary 30%` fill with a full-height accent bar
 *  - macOS: source list on the sidebar material, accent-tinted fill, grey while the window is inactive
 *  - GNOME: AdwNavigationSplitView sidebar, neutral rounded selection
 *  - KDE: Breeze places panel, accent outline on hover, accent-filled selection
 *  - ChromeOS: Material 3 navigation drawer, tonal pill
 *
 * The host carries the theme's `sn-sidebar` material. Items are plain links or buttons
 * (no Router needed); mark the current one with `[active]`. ↑ ↓ Home End move between items.
 *
 * ```html
 * <sn-sidebar-nav aria-label="Sections">
 *   <sn-sidebar-section title="Backups">
 *     <a snSidebarItem href="#" icon="lucideLayoutDashboard" [active]="page() === 'overview'">Overview</a>
 *     <button snSidebarItem icon="lucideHistory" badge="3" (click)="page.set('restore')">Restore files</button>
 *   </sn-sidebar-section>
 * </sn-sidebar-nav>
 * ```
 *
 * With the Router: `<a snSidebarItem routerLink="/x" routerLinkActive #rla="routerLinkActive" [active]="rla.isActive">`.
 */
export declare class SnSidebarNav {
  private readonly items;
  /** The item that keeps the single Tab stop: the last focused one, else the active one, else the first. */
  private readonly focused;
  readonly tabStop: import("@angular/core").Signal<any>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  /** @internal */
  setFocused(item: SnSidebarItem): void;
  protected onKeydown(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnSidebarNav, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnSidebarNav, "sn-sidebar-nav", never, {}, {}, ["items"], ["*"], true, never>;
}
/** Where ↑ ↓ Home End move the focus from `current` (-1: nothing focused); null for other keys. Doesn't wrap, like the native lists. */
export declare function nextIndex(key: string, current: number, count: number): number | null;
/**
 * A titled group of items: "Favorites", "Locations", … Leave `title` empty for an unlabeled group.
 */
export declare class SnSidebarSection {
  readonly title: import("@angular/core").InputSignal<string>;
  protected readonly headingId: string;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnSidebarSection, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnSidebarSection, "sn-sidebar-section", never, {
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * One navigation item, on an `<a>` or a `<button>`. `icon` is an @ng-icons name the app
 * registered with provideIcons(); `badge` is a short count or label on the trailing side.
 */
export declare class SnSidebarItem {
  readonly active: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly icon: import("@angular/core").InputSignal<string>;
  readonly badge: import("@angular/core").InputSignal<string | number>;
  readonly element: HTMLElement;
  protected readonly nav: SnSidebarNav | null;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnSidebarItem, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnSidebarItem, "a[snSidebarItem], button[snSidebarItem]", never, {
    "active": {
      "alias": "active";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "badge": {
      "alias": "badge";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export declare const SnSidebarNavImports: readonly [typeof SnSidebarNav, typeof SnSidebarSection, typeof SnSidebarItem];
/**
 * One page of an `<sn-assistant>`.
 *
 * ```html
 * <ng-template snAssistantPage title="Destination" [canContinue]="form.valid">…</ng-template>
 * ```
 */
export declare class SnAssistantPage {
  readonly template: TemplateRef<any>;
  /** The page's title, shown as its heading (and in the KDE step list). */
  readonly title: import("@angular/core").InputSignal<string>;
  /** False disables Next / Continue (e.g. while the page's form is invalid). Default: true. */
  readonly canContinue: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnAssistantPage, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnAssistantPage, "ng-template[snAssistantPage]", never, {
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "canContinue": {
      "alias": "canContinue";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A step-by-step setup flow, laid out the way each OS does it:
 *  - Windows: a wizard, "Step 2 of 4" over the page title, Back · Next · Cancel at the bottom right
 *  - macOS: a Setup Assistant page, large centered title, Go Back · Continue at the bottom right
 *  - GNOME: Back and Next in a header bar around the page title, page dots at the bottom
 *  - KDE: a QWizard with the list of steps at the side, Back · Next · Cancel at the bottom right
 *  - ChromeOS: an M3 flow, headline, page dots, Back · Next at the bottom end
 *
 * Pages are templates; only the current one is rendered. Next becomes Finish / Done on the last
 * page and emits `finish`; Cancel emits `cancel`. Bind `step` to keep or set the page. Put it in an
 * `<sn-modal-sheet>` (without sheet buttons) for a modal assistant, or in a window as a page.
 *
 * ```html
 * <sn-assistant [(step)]="step" (finish)="save()" (cancel)="open.set(false)">
 *   <ng-template snAssistantPage title="Welcome">…</ng-template>
 *   <ng-template snAssistantPage title="Destination" [canContinue]="destination() !== null">…</ng-template>
 *   <ng-template snAssistantPage title="Schedule">…</ng-template>
 * </sn-assistant>
 * ```
 *
 * The buttons carry spartan's button hooks (`data-slot="button"`), so the theme draws them as each
 * skin's standard and accent buttons. Their words follow the OS (Continue on macOS, Finish on
 * Windows…); set `backLabel`, `nextLabel`, `finishLabel`, `cancelLabel` to translate them.
 */
export declare class SnAssistant {
  /** The current page, from 0. */
  readonly step: import("@angular/core").ModelSignal<number>;
  /** Show a Cancel button. Default: true. */
  readonly cancelable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly backLabel: import("@angular/core").InputSignal<string>;
  readonly nextLabel: import("@angular/core").InputSignal<string>;
  readonly finishLabel: import("@angular/core").InputSignal<string>;
  readonly cancelLabel: import("@angular/core").InputSignal<string>;
  /** "Step {current} of {total}" on Windows; `{current}` and `{total}` are replaced. */
  readonly progressLabel: import("@angular/core").InputSignal<string>;
  /** Next on the last page. */
  readonly finish: import("@angular/core").OutputEmitterRef<void>;
  readonly cancel: import("@angular/core").OutputEmitterRef<void>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<PlatformFamily>;
  protected readonly words: import("@angular/core").Signal<{
    back: string;
    next: string;
    finish: string;
    cancel: string;
  }>;
  protected readonly pages: import("@angular/core").Signal<readonly SnAssistantPage[]>;
  protected readonly current: import("@angular/core").Signal<number>;
  protected readonly page: import("@angular/core").Signal<SnAssistantPage>;
  protected readonly last: import("@angular/core").Signal<boolean>;
  protected readonly showDots: import("@angular/core").Signal<boolean>;
  protected readonly progressText: import("@angular/core").Signal<string>;
  protected readonly headingId: string;
  private readonly heading;
  private readonly host;
  constructor();
  /** Goes to the next page, or emits `finish` on the last one. */
  next(): void;
  /** Goes to the previous page. */
  back(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnAssistant, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnAssistant, "sn-assistant", never, {
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "cancelable": {
      "alias": "cancelable";
      "required": false;
      "isSignal": true;
    };
    "backLabel": {
      "alias": "backLabel";
      "required": false;
      "isSignal": true;
    };
    "nextLabel": {
      "alias": "nextLabel";
      "required": false;
      "isSignal": true;
    };
    "finishLabel": {
      "alias": "finishLabel";
      "required": false;
      "isSignal": true;
    };
    "cancelLabel": {
      "alias": "cancelLabel";
      "required": false;
      "isSignal": true;
    };
    "progressLabel": {
      "alias": "progressLabel";
      "required": false;
      "isSignal": true;
    };
  }, {
    "step": "stepChange";
    "finish": "finish";
    "cancel": "cancel";
  }, ["pages"], never, true, never>;
}
export declare const SnAssistantImports: readonly [typeof SnAssistant, typeof SnAssistantPage];
/**
 * A list of setup tasks: numbered rows that tick off as they are done, each with an action.
 *
 * ```html
 * <sn-checklist aria-label="Get started">
 *   <sn-checklist-item title="Add a destination" [done]="hasDestination()">
 *     Where your backups go: a disk, a NAS or the cloud.
 *     <button hlmBtn size="sm" snChecklistAction (click)="add()">Add…</button>
 *   </sn-checklist-item>
 *   <sn-checklist-item title="Choose what to back up">…</sn-checklist-item>
 * </sn-checklist>
 * ```
 */
export declare class SnChecklist {
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnChecklist, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnChecklist, "sn-checklist", never, {}, {}, never, ["*"], true, never>;
}
/**
 * One task of an `<sn-checklist>`: a number (a tick once `done`), the title, a description
 * (the content) and an action (`[snChecklistAction]`, hidden once done unless `keepAction`).
 */
export declare class SnChecklistItem {
  readonly title: import("@angular/core").InputSignal<string>;
  readonly done: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Keep the action visible once the task is done (e.g. "Change…"). */
  readonly keepAction: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Read by screen readers after the title. */
  readonly doneLabel: import("@angular/core").InputSignal<string>;
  readonly todoLabel: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnChecklistItem, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnChecklistItem, "sn-checklist-item", never, {
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "done": {
      "alias": "done";
      "required": false;
      "isSignal": true;
    };
    "keepAction": {
      "alias": "keepAction";
      "required": false;
      "isSignal": true;
    };
    "doneLabel": {
      "alias": "doneLabel";
      "required": false;
      "isSignal": true;
    };
    "todoLabel": {
      "alias": "todoLabel";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*", "[snChecklistAction]"], true, never>;
}
export declare const SnChecklistImports: readonly [typeof SnChecklist, typeof SnChecklistItem];
/**
 * The menu of an `<sn-split-button>`: the other choices for the action. Put a stock menu
 * inside, e.g. hlmDropdownMenu:
 *
 * ```html
 * <ng-template snSplitButtonMenu>
 *   <div hlmDropdownMenu>
 *     <button hlmDropdownMenuItem>Back up Documents only</button>
 *   </div>
 * </ng-template>
 * ```
 */
export declare class SnSplitButtonMenu {
  readonly template: TemplateRef<any>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnSplitButtonMenu, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnSplitButtonMenu, "ng-template[snSplitButtonMenu]", never, {}, {}, never, never, true, never>;
}
/** standard: the platform's normal button · accent: the suggested / default action */
export type SnSplitButtonVariant = 'standard' | 'accent';
/**
 * A button that runs its main action, joined to a second button that opens a menu of
 * alternatives. Each part is drawn as the skin's own button, so it matches the buttons next to it:
 *  - Windows 11 / 10: Fluent SplitButton, one control with a divider before the chevron
 *  - macOS 26 / 13–15: NSComboButton (split style), a capsule (26) or bezel (13–15) with a divider
 *  - GNOME: AdwSplitButton, two linked buttons
 *  - KDE: a QToolButton with a MenuButtonPopup arrow
 *  - ChromeOS: the Material 3 split button, two segments with a 2px gap and tight inner corners
 *
 * Two Tab stops: the action, then the menu button. On the action, ↓ (Alt+↓ on Windows)
 * opens the menu too.
 *
 * ```html
 * <sn-split-button label="Back up now" icon="lucideCloudUpload" variant="accent" (triggered)="backUp()">
 *   <ng-template snSplitButtonMenu>
 *     <div hlmDropdownMenu>
 *       <button hlmDropdownMenuItem (triggered)="backUp('documents')">Documents only</button>
 *       <button hlmDropdownMenuItem (triggered)="verify()">Verify last backup</button>
 *     </div>
 *   </ng-template>
 * </sn-split-button>
 * ```
 */
export declare class SnSplitButton {
  /** The main action's text (also the group's accessible name). */
  readonly label: import("@angular/core").InputSignal<string>;
  /** An @ng-icons name registered with provideIcons(), shown before the label. */
  readonly icon: import("@angular/core").InputSignal<string>;
  readonly variant: import("@angular/core").InputSignal<SnSplitButtonVariant>;
  /** The compact size (the theme's small button height). */
  readonly small: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Accessible name and tooltip of the menu button. */
  readonly menuLabel: import("@angular/core").InputSignal<string>;
  /** The main action was clicked (or Enter / Space). */
  readonly triggered: import("@angular/core").OutputEmitterRef<void>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  protected readonly menu: import("@angular/core").Signal<SnSplitButtonMenu | undefined>;
  private readonly trigger;
  protected readonly partClass: import("@angular/core").Signal<string>;
  protected readonly menuPosition: ConnectedPosition[];
  /** Opens the menu, e.g. from a keyboard shortcut. */
  open(): void;
  protected onActionKeydown(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnSplitButton, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnSplitButton, "sn-split-button", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "small": {
      "alias": "small";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "menuLabel": {
      "alias": "menuLabel";
      "required": false;
      "isSignal": true;
    };
  }, {
    "triggered": "triggered";
  }, ["menu"], never, true, never>;
}
export declare const SnSplitButtonImports: readonly [typeof SnSplitButton, typeof SnSplitButtonMenu];
/**
 * Evaluates the simple arithmetic a Fluent NumberBox accepts: numbers, + − * /, parentheses
 * and unary minus. A comma works as the decimal separator too. Returns null for anything else
 * (no variables, no functions, nothing is executed).
 *
 * ```ts
 * evaluateNumberExpression('1.5 * (2 + 2)') // 6
 * evaluateNumberExpression('12,5')          // 12.5
 * ```
 */
export declare function evaluateNumberExpression(text: string): number | null;
/**
 * A number field with step buttons, in the OS's own layout:
 *  - Windows 11 / 10: Fluent NumberBox, ∧ ∨ buttons inside the field (SpinButtonPlacementMode.Inline)
 *  - macOS 26 / 13–15: a text field with an NSStepper beside it (stacked arrows)
 *  - GNOME: GtkSpinButton, − and + buttons inside the entry's end, divided by lines
 *  - KDE: QSpinBox (Breeze), small stacked arrows inside the field
 *  - ChromeOS: an M3 text field with round − / + icon buttons at the end
 *
 * The field is drawn by the skin's text field, so it has the OS's border, focus and hover.
 * Keyboard: ↑ ↓ step, PgUp PgDn take a large step, Home End go to min / max, Enter commits,
 * Esc reverts what you typed. Typing `2*15` or `100/4` works (Fluent NumberBox math).
 * The step buttons repeat while held; they aren't Tab stops (the arrow keys do the same).
 *
 * Bind with `[(value)]`, or as a form control (`formControlName`, `[(ngModel)]`):
 *
 * ```html
 * <label hlmLabel for="keep">Keep versions</label>
 * <sn-number-box inputId="keep" [(value)]="versions" [min]="1" [max]="100" />
 * ```
 */
export declare class SnNumberBox implements ControlValueAccessor {
  /** The number; null when the field is empty. Two-way bindable. */
  readonly value: import("@angular/core").ModelSignal<number | null>;
  readonly min: import("@angular/core").InputSignalWithTransform<number | null, unknown>;
  readonly max: import("@angular/core").InputSignalWithTransform<number | null, unknown>;
  /** What ↑ ↓ and the buttons add or subtract. */
  readonly step: import("@angular/core").InputSignalWithTransform<number, unknown>;
  /** What PgUp / PgDn add or subtract; defaults to 10 steps. */
  readonly largeStep: import("@angular/core").InputSignalWithTransform<number | null, unknown>;
  /** Round to this many decimal places (and always show them). Default: as typed. */
  readonly decimals: import("@angular/core").InputSignalWithTransform<number | null, unknown>;
  /** Show the step buttons. */
  readonly spinButtons: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Accept arithmetic such as `2*15` (Fluent NumberBox). */
  readonly acceptsExpression: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  /** The input's id, for `<label for>`. */
  readonly inputId: import("@angular/core").InputSignal<string>;
  /** Accessible name when there's no `<label for>`. */
  readonly ariaLabel: import("@angular/core").InputSignal<string>;
  protected readonly skin: import("@angular/core").Signal<Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  protected readonly glyphs: import("@angular/core").Signal<"plus-minus" | "chevrons">;
  private readonly formDisabled;
  protected readonly isDisabled: import("@angular/core").Signal<boolean>;
  /** The text in the field: the formatted value, or what the user is typing. */
  protected readonly draft: import("@angular/core").WritableSignal<string>;
  /** The text doesn't parse; shown until it's committed or reverted. */
  protected readonly invalid: import("@angular/core").Signal<boolean>;
  protected readonly atMin: import("@angular/core").Signal<boolean>;
  protected readonly atMax: import("@angular/core").Signal<boolean>;
  private readonly field;
  private repeatTimer;
  private onChange;
  protected onTouched: () => void;
  constructor();
  /** Adds `steps` × step (negative to subtract) and commits. */
  stepBy(steps: number, size?: number): void;
  /** Parses the text in the field and makes it the value; reverts text that doesn't parse. */
  commit(): void;
  focus(): void;
  protected onInput(event: Event): void;
  protected onKeydown(event: KeyboardEvent): void;
  protected onWheel(event: WheelEvent): void;
  protected press(event: PointerEvent, steps: number): void;
  protected release(): void;
  writeValue(value: unknown): void;
  registerOnChange(fn: (value: number | null) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(disabled: boolean): void;
  private set;
  /**
   * Puts `text` in the field. Written to the element too: when the value didn't change, the
   * `[value]` binding sees the same string as last time and wouldn't replace what was typed.
   */
  private show;
  private parse;
  private format;
  private bound;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnNumberBox, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnNumberBox, "sn-number-box", never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "largeStep": {
      "alias": "largeStep";
      "required": false;
      "isSignal": true;
    };
    "decimals": {
      "alias": "decimals";
      "required": false;
      "isSignal": true;
    };
    "spinButtons": {
      "alias": "spinButtons";
      "required": false;
      "isSignal": true;
    };
    "acceptsExpression": {
      "alias": "acceptsExpression";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "inputId": {
      "alias": "inputId";
      "required": false;
      "isSignal": true;
    };
    "ariaLabel": {
      "alias": "ariaLabel";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, never, never, true, never>;
}
/**
 * A hierarchical list (folders, sections, a document outline) with the desktop selection model:
 *  - Windows 11: WinUI TreeView, chevrons, the accent pill on the selected row
 *  - Windows 10: square rows, chevrons, accent-tinted selection
 *  - macOS 26 / 13–15: NSOutlineView, disclosure triangles, accent selection that turns grey
 *    when the tree loses focus
 *  - GNOME: a GtkListView with GtkTreeExpander, triangles, neutral rounded selection
 *  - KDE: a Breeze QTreeView, chevrons, accent-filled selection (muted without focus)
 *  - ChromeOS: the Files app tree, chevrons, tonal pill selection
 *
 * Items nest in markup; any depth, `@for` and `@if` work. Values must be unique in the tree.
 *
 * ```html
 * <sn-tree aria-label="Folders" [(selection)]="folder" (activated)="open($event)">
 *   <sn-tree-item value="docs" label="Documents" icon="lucideFolder" [(expanded)]="docsOpen">
 *     <sn-tree-item value="docs/taxes" label="Taxes" icon="lucideFolder" />
 *     <sn-tree-item value="docs/work" label="Work" icon="lucideFolder" />
 *   </sn-tree-item>
 *   <sn-tree-item value="photos" label="Photos" icon="lucideFolder" />
 * </sn-tree>
 * ```
 *
 * Mouse: click selects, Ctrl/⌘-click and Shift-click with `multiple`, the expander or a
 * double-click on a parent opens and closes it, double-click on a leaf activates.
 * Keyboard: ↑ ↓ Home End PgUp PgDn move (Shift extends, Ctrl/⌘ moves focus only with `multiple`),
 * → opens or goes to the first child, ← closes or goes to the parent, `*` opens all siblings,
 * Enter activates, Space selects (Ctrl+Space toggles), Ctrl/⌘+A selects all, type to jump.
 */
export declare class SnTree<K = unknown> {
  /** Allow more than one selected item. */
  readonly multiple: import("@angular/core").InputSignal<boolean>;
  /** The selected values, in visible order. Two-way bindable. */
  readonly selection: import("@angular/core").ModelSignal<readonly K[]>;
  /** Enter, or a double-click on an item without children. */
  readonly activated: import("@angular/core").OutputEmitterRef<K>;
  protected readonly skin: import("@angular/core").Signal<Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  /** @internal */
  readonly triangle: import("@angular/core").Signal<boolean>;
  private readonly dir;
  private readonly injector;
  private readonly registered;
  /** Bumped after items render or move, so the document order is read again. */
  private readonly orderVersion;
  private orderPending;
  /** Every item, in document order. */
  private readonly ordered;
  /** The items whose ancestors are all open: what the keyboard and Shift ranges walk. */
  private readonly visible;
  private readonly visibleKeys;
  private readonly cursor;
  private readonly selectedSet;
  /** The item that holds the single Tab stop. */
  readonly tabStop: import("@angular/core").Signal<SnTreeItem<K>>;
  private typeahead;
  private typeaheadTimer;
  constructor();
  /** @internal */
  register(item: SnTreeItem<K>): void;
  /** @internal */
  unregister(item: SnTreeItem<K>): void;
  /** @internal The direct children of `parent` (null: the top level), in document order. */
  childrenOf(parent: SnTreeItem<K> | null): SnTreeItem<K>[];
  /** @internal */
  isSelected(key: K): boolean;
  /** @internal Focus landed on an item (Tab, click): it becomes the cursor. */
  focused(item: SnTreeItem<K>): void;
  /** @internal */
  click(item: SnTreeItem<K>, event: MouseEvent): void;
  /** @internal */
  activate(item: SnTreeItem<K>): void;
  /** @internal An item closed: if the cursor or a selection was inside it, it moves to the item. */
  collapsed(item: SnTreeItem<K>): void;
  protected onKeydown(event: KeyboardEvent): void;
  private onTypeahead;
  private state;
  private apply;
  /** ⌘ toggles on macOS, Ctrl everywhere else (Ctrl-click is the context menu on macOS). */
  private modifiers;
  /** Reads the document order again once the newly registered items are in place. */
  private reorder;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnTree<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnTree<any>, "sn-tree", never, {
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "selection": {
      "alias": "selection";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selection": "selectionChange";
    "activated": "activated";
  }, never, ["*"], true, never>;
}
/**
 * One item of an `<sn-tree>`; nest items inside it for its children. `label` is its text (and
 * the type-ahead text); `icon` an @ng-icons name registered with provideIcons().
 * Extra trailing content (a count, a badge) goes in `[snTreeItemEnd]`.
 *
 * `expandable` shows the expander before the children exist, for lazy loading: listen to
 * `(expandedChange)` and add the children then.
 */
export declare class SnTreeItem<K = unknown> {
  /** The key this item stands for; unique in the tree. Declared optional because the tree reads its items while Angular is still binding them. */
  readonly value: import("@angular/core").InputSignal<K>;
  readonly label: import("@angular/core").InputSignal<string>;
  readonly icon: import("@angular/core").InputSignal<string>;
  /** Open, showing its children. Two-way bindable. */
  readonly expanded: import("@angular/core").ModelSignal<boolean>;
  /** Show the expander even without children (they load when it opens). */
  readonly expandable: import("@angular/core").InputSignal<boolean>;
  readonly element: HTMLElement;
  protected readonly tree: SnTree<K>;
  /** The item this one is nested in; null at the top level. */
  readonly parent: SnTreeItem<K> | null;
  readonly level: () => number;
  readonly children: import("@angular/core").Signal<SnTreeItem<K>[]>;
  readonly hasChildren: import("@angular/core").Signal<boolean>;
  readonly selected: import("@angular/core").Signal<boolean>;
  /** Every ancestor is open. */
  readonly isVisible: () => boolean;
  constructor();
  /** Every item nested below this one, at any depth. */
  descendants(): SnTreeItem<K>[];
  setExpanded(open: boolean): void;
  protected onMouseDown(event: MouseEvent): void;
  protected onExpanderClick(event: MouseEvent): void;
  protected onDoubleClick(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnTreeItem<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnTreeItem<any>, "sn-tree-item", never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "expanded": {
      "alias": "expanded";
      "required": false;
      "isSignal": true;
    };
    "expandable": {
      "alias": "expandable";
      "required": false;
      "isSignal": true;
    };
  }, {
    "expanded": "expandedChange";
  }, never, ["[snTreeItemEnd]", "*"], true, never>;
}
export declare const SnTreeImports: readonly [typeof SnTree, typeof SnTreeItem];
/**
 * The bridge to the host's native menus (`NativeHost.menus`). It converts desktop-ui menus to
 * the host's plain data and runs an item's `action` when the host reports it was chosen.
 * `<sn-menubar>` and `[snContextMenu]` use it; call it directly for menus built in code.
 */
export declare class SnNativeMenus {
  private readonly theme;
  private readonly host;
  private readonly appActions;
  private readonly contextActions;
  private off;
  constructor();
  /** The host can set the application menu (the macOS global menu bar, a window menu). */
  get canSetApplicationMenu(): boolean;
  /** The host can show OS context menus. */
  get canShowContextMenu(): boolean;
  /** Sets (or, with `[]`, removes) the application menu. */
  setApplicationMenu(items: readonly SnMenuItem[]): Promise<void>;
  /** Shows an OS context menu at `x`, `y` (CSS pixels from the window's content corner). */
  showContextMenu(items: readonly SnMenuItem[], position: {
    x: number;
    y: number;
  }): Promise<void>;
  private listen;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnNativeMenus, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** auto: native on macOS when the host can · always: native whenever the host can · never: in the page */
export type SnMenubarNative = 'auto' | 'always' | 'never';
/**
 * The application menu, from one menu definition:
 *  - macOS with a host that has native menus (Wails): the global menu bar at the top of the
 *    screen. Nothing is drawn in the window, and the OS handles the shortcuts.
 *  - Everywhere else (Windows, Linux, ChromeOS, and macOS in a browser): an in-window menu bar,
 *    drawn by the skin's menubar and menu styles, with the shortcuts bound in the page.
 *
 * Roles become the OS's own items natively (`appMenu`, `editMenu`, `windowMenu`, `quit`, …); in
 * the page `editMenu` and `windowMenu` become Edit and Window menus that act on the focused field
 * and the host's window, and the macOS-only roles are left out.
 *
 * ```ts
 * readonly menu = computed<SnMenuItem[]>(() => [
 *   { role: 'appMenu' },
 *   { label: 'File', submenu: [
 *     { label: 'New backup…', accelerator: 'mod+n', action: () => this.create() },
 *     { label: 'Pause backups', type: 'checkbox', checked: this.paused(), action: () => this.togglePause() },
 *     { type: 'separator' },
 *     { role: 'close' },
 *   ]},
 *   { role: 'editMenu' },
 *   { role: 'windowMenu' },
 * ]);
 * ```
 * ```html
 * <sn-menubar [menu]="menu()" />
 * ```
 *
 * Pass a new array to update it (a `computed` is the easy way): the native menu is sent again.
 * In the page: F10 focuses the bar (Windows, Linux), ← → move between menus, ↓ or Enter opens one.
 */
export declare class SnMenubar {
  /** The menus: top-level items with a `submenu` (or a role such as `editMenu`). */
  readonly menu: import("@angular/core").InputSignal<readonly SnMenuItem[]>;
  /** When to use the host's native menu bar. Default: `auto` (macOS only). */
  readonly native: import("@angular/core").InputSignal<SnMenubarNative>;
  /** Accessible name of the in-page bar. */
  readonly ariaLabel: import("@angular/core").InputSignal<string>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  /** The real OS: what the keyboard, the shortcut notation and the macOS menu bar follow. */
  protected readonly platform: import("@angular/core").Signal<import("@spartan-native/theme").PlatformFamily>;
  private readonly menus;
  private readonly hostWindow;
  private readonly element;
  private readonly bar;
  /** The menu bar is the host's native one. */
  readonly isNative: import("@angular/core").Signal<boolean>;
  /** The menu as drawn in the page: roles replaced by ordinary items. */
  protected readonly pageMenu: import("@angular/core").Signal<SnMenuItem[]>;
  private readonly accelerated;
  /** The field that had the focus before the menu bar took it (Edit commands act on it). */
  private lastFocus;
  protected readonly restoreFocus: () => false | void | undefined;
  constructor();
  protected onDocumentKeydown(event: KeyboardEvent): void;
  protected onDocumentFocusin(event: FocusEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnMenubar, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SnMenubar, "sn-menubar", never, {
    "menu": {
      "alias": "menu";
      "required": true;
      "isSignal": true;
    };
    "native": {
      "alias": "native";
      "required": false;
      "isSignal": true;
    };
    "ariaLabel": {
      "alias": "ariaLabel";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A context menu on an element, from the same menu data as `<sn-menubar>`:
 *  - with a host that has native menus (Wails): the OS's own context menu
 *  - otherwise: an in-page menu at the pointer, drawn by the skin's menu styles
 *
 * Right-click, the Menu key and Shift+F10 open it. Roles such as `cut`, `copy`, `paste` and
 * `selectAll` are the OS's items natively, and act on the focused field in the page.
 *
 * ```html
 * <li [snContextMenu]="fileMenu(file)">{{ file.name }}</li>
 * ```
 * ```ts
 * fileMenu(file: File): SnMenuItem[] {
 *   return [
 *     { label: 'Restore', action: () => this.restore(file) },
 *     { label: 'Rename', accelerator: 'f2', action: () => this.rename(file) },
 *     { type: 'separator' },
 *     { label: 'Delete', accelerator: 'delete', action: () => this.remove(file) },
 *   ];
 * }
 * ```
 *
 * The accelerators are shown, not bound: bind them where the selection lives.
 */
export declare class SnContextMenu {
  /** The menu. */
  readonly items: import("@angular/core").InputSignal<readonly SnMenuItem[]>;
  /** `never` keeps the in-page menu even when the host has native menus. */
  readonly native: import("@angular/core").InputSignal<"auto" | "never">;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  private readonly trigger;
  private readonly menus;
  private readonly hostWindow;
  private readonly element;
  /** The real OS: shortcut notation and the Edit roles' keys follow the keyboard, not the skin. */
  private readonly family;
  /** The OS shows the menu. */
  private readonly useNative;
  constructor();
  protected onContextMenu(event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnContextMenu, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnContextMenu, "[snContextMenu]", never, {
    "items": {
      "alias": "snContextMenu";
      "required": true;
      "isSignal": true;
    };
    "native": {
      "alias": "snContextMenuNative";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "snContextMenuDisabled";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.CdkContextMenuTrigger;
    inputs: {};
    outputs: {};
  }]>;
}
export declare function formatShortcut(shortcut: string, family: PlatformFamily): string;
/**
 * Shows a shortcut in the notation of the keyboard the user really has: the real OS
 * (`injectPlatformFamily()`), not the skin, so a Mac dressed as Windows still shows ⌘.
 *  - macOS: symbols in Apple's order, no separators (⇧⌘S)
 *  - Windows, Linux, ChromeOS, web: words joined with `+` (Ctrl+Shift+S)
 *
 * The text is also the element's aria-label, so screen readers read the same thing.
 *
 * ```html
 * <kbd snShortcut="mod+shift+s"></kbd>   <!-- ⇧⌘S on macOS, Ctrl+Shift+S elsewhere -->
 * ```
 */
export declare class SnShortcut {
  /** The shortcut in the portable notation, e.g. `mod+shift+s`. */
  readonly shortcut: import("@angular/core").InputSignal<string>;
  protected readonly skin: import("@angular/core").Signal<import("@spartan-native/theme").Skin>;
  protected readonly family: import("@angular/core").Signal<PlatformFamily>;
  protected readonly text: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SnShortcut, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnShortcut, "[snShortcut]", never, {
    "shortcut": {
      "alias": "snShortcut";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A skin or a whole family.
 * Skins: 'win' (Windows 11), 'w10' (Windows 10), 'mac' (macOS 26), 'macc' (macOS 13–15),
 * 'gtk' (GNOME), 'qt' (KDE Plasma), 'cros' (ChromeOS).
 * Families: 'windows' (win, w10), 'macos' (mac, macc), 'linux' (gtk, qt), 'chromeos' (cros), 'web'.
 */
export type PlatformMatch = Skin | PlatformFamily;
/**
 * Renders its template only on the given platforms: a skin, a family, or a list of either
 * (see PlatformMatch). Follows the skin live. With `else`, renders that template instead.
 *
 * ```html
 * <p *snPlatformIf="'macos'; else other">Use the menu bar.</p>
 * <ng-template #other><p>Use the ☰ menu.</p></ng-template>
 *
 * <button *snPlatformIf="['windows', 'linux']">Exit</button>
 * <p *snPlatformIf="'qt'">Plasma only: also in System Settings.</p>
 * ```
 */
export declare class SnPlatformIf {
  /** The skins and families to render on. */
  readonly platforms: import("@angular/core").InputSignal<PlatformMatch | readonly PlatformMatch[]>;
  /** Rendered on every other platform. */
  readonly elseTemplate: import("@angular/core").InputSignal<TemplateRef<unknown> | null>;
  private readonly template;
  private readonly container;
  private readonly skin;
  private shown;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<SnPlatformIf, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SnPlatformIf, "[snPlatformIf]", never, {
    "platforms": {
      "alias": "snPlatformIf";
      "required": true;
      "isSignal": true;
    };
    "elseTemplate": {
      "alias": "snPlatformIfElse";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare const SnWindowImports: readonly [typeof SnTitleBar, typeof SnWindowControls, typeof import("@spartan-native/desktop-ui").SnStatusBar, typeof import("@spartan-native/desktop-ui").SnStatusItem];
export declare const SnControlsImports: readonly [typeof import("@spartan-native/desktop-ui").SnSplitButton, typeof import("@spartan-native/desktop-ui").SnSplitButtonMenu, typeof SnNumberBox, typeof import("@spartan-native/desktop-ui").SnTree, typeof import("@spartan-native/desktop-ui").SnTreeItem, typeof SnTooltip];
export declare const SnMenuImports: readonly [typeof SnMenubar, typeof SnContextMenu];
export declare const SnSettingsImports: readonly [typeof SnSettingsGroup, typeof SnSettingsRow];
export declare const SnPlatformImports: readonly [typeof SnPlatformIf, typeof SnShortcut];
export declare const SnDesktopUiImports: readonly [typeof SnTitleBar, typeof SnWindowControls, typeof import("@spartan-native/desktop-ui").SnStatusBar, typeof import("@spartan-native/desktop-ui").SnStatusItem, typeof SnSettingsGroup, typeof SnSettingsRow, typeof SnStatusPage, typeof import("@spartan-native/desktop-ui").SnCommandBar, typeof import("@spartan-native/desktop-ui").SnCommand, typeof import("@spartan-native/desktop-ui").SnCommandGroup, typeof import("@spartan-native/desktop-ui").SnCommandOverflow, typeof import("@spartan-native/desktop-ui").SnCoachMark, typeof import("@spartan-native/desktop-ui").SnCoachMarkFor, typeof SnModalSheet, typeof import("@spartan-native/desktop-ui").SnInspectorLayout, typeof import("@spartan-native/desktop-ui").SnInspector, typeof import("@spartan-native/desktop-ui").SnInspectorSection, typeof import("@spartan-native/desktop-ui").SnInspectorProperty, typeof import("@spartan-native/desktop-ui").SnSidebarNav, typeof import("@spartan-native/desktop-ui").SnSidebarSection, typeof import("@spartan-native/desktop-ui").SnSidebarItem, typeof import("@spartan-native/desktop-ui").SnAssistant, typeof import("@spartan-native/desktop-ui").SnAssistantPage, typeof import("@spartan-native/desktop-ui").SnChecklist, typeof import("@spartan-native/desktop-ui").SnChecklistItem, typeof import("@spartan-native/desktop-ui").SnSplitButton, typeof import("@spartan-native/desktop-ui").SnSplitButtonMenu, typeof SnNumberBox, typeof import("@spartan-native/desktop-ui").SnTree, typeof import("@spartan-native/desktop-ui").SnTreeItem, typeof SnTooltip, typeof SnMenubar, typeof SnContextMenu, typeof SnPlatformIf, typeof SnShortcut];
export {};