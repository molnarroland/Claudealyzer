const SPARTAN_NATIVE_HOST_ELECTRON_SCAFFOLD = true;
export { SPARTAN_NATIVE_HOST_ELECTRON_SCAFFOLD };

//# sourceMappingURL=spartan-native-host-electron.mjs.map