import { withThemeByClassName } from "@storybook/addon-themes";
import { DEFAULT_ACCENT, applySpartanNative } from "@spartan-native/theme";
const STORYBOOK_SKINS = [
	{
		value: "win",
		title: "Windows 11",
		family: "windows"
	},
	{
		value: "w10",
		title: "Windows 10",
		family: "windows"
	},
	{
		value: "mac",
		title: "macOS 26",
		family: "apple"
	},
	{
		value: "macc",
		title: "macOS 13–15",
		family: "apple"
	},
	{
		value: "gtk",
		title: "GNOME · GTK 4",
		family: "linux"
	},
	{
		value: "qt",
		title: "KDE Plasma",
		family: "linux"
	},
	{
		value: "cros",
		title: "ChromeOS",
		family: "chrome"
	}
];
const ACCENT_PRESETS = [
	{
		value: "#0078d4",
		title: "Windows blue"
	},
	{
		value: "#007aff",
		title: "macOS blue"
	},
	{
		value: "#3584e4",
		title: "GNOME blue"
	},
	{
		value: "#9141ac",
		title: "Purple"
	},
	{
		value: "#e66100",
		title: "Orange"
	},
	{
		value: "#26a269",
		title: "Green"
	},
	{
		value: "#d56199",
		title: "Pink"
	}
];
const withSpartanNative = (story, context) => {
	const g = context.globals;
	applySpartanNative(document.documentElement, {
		skin: g["skin"] ?? "win",
		scheme: g["theme"] === "dark" ? "dark" : "light",
		accent: g["accent"] || DEFAULT_ACCENT,
		reduceTransparency: g["transparency"] === "reduced",
		textScale: Number(g["textScale"] ?? 1),
		focused: g["window"] !== "inactive",
		contrast: g["contrast"] === "more" ? "more" : "normal",
		reduceMotion: false
	});
	document.body.style.background = "var(--sn-color-wall)";
	document.body.style.margin = "0";
	document.body.style.minHeight = "100vh";
	return story();
};
function spartanNativePreview(options = {}) {
	const globalTypes = {
		skin: { description: "Operating system" },
		transparency: { description: "Reduce transparency (OS accessibility setting): normal | reduced" },
		contrast: { description: "Increase contrast (OS accessibility setting): normal | more" },
		accent: { description: "The accent color the OS reports. Every theme color is derived from it." }
	};
	const initialGlobals = {
		skin: "win",
		transparency: "normal",
		contrast: "normal",
		accent: DEFAULT_ACCENT
	};
	if (options.textSize) {
		globalTypes["textScale"] = {
			description: "OS text size",
			toolbar: {
				title: "Text size",
				icon: "zoom",
				items: [
					"1",
					"1.25",
					"1.5",
					"1.75",
					"2"
				].map((v) => ({
					value: v,
					title: `${Number(v) * 100}%`
				})),
				dynamicTitle: true
			}
		};
		initialGlobals["textScale"] = "1";
	}
	if (options.windowFocus) {
		globalTypes["window"] = { description: "Window focus: focused | inactive" };
		initialGlobals["window"] = "focused";
	}
	return {
		globalTypes,
		initialGlobals,
		decorators: [withSpartanNative, withThemeByClassName({
			themes: {
				light: "light",
				dark: "dark"
			},
			defaultTheme: "light"
		})],
		parameters: {
			layout: "fullscreen",
			controls: { expanded: true },
			a11y: { test: "todo" }
		}
	};
}
export { ACCENT_PRESETS, STORYBOOK_SKINS, spartanNativePreview, withSpartanNative };

//# sourceMappingURL=spartan-native-theme-storybook.mjs.map