import { DOCUMENT } from "@angular/common";
import * as i0 from "@angular/core";
import { DestroyRef, Injectable, InjectionToken, computed, effect, inject, makeEnvironmentProviders, provideAppInitializer, signal } from "@angular/core";
const STYLED_SKINS = [
	"win",
	"w10",
	"mac",
	"macc",
	"gtk",
	"qt",
	"cros"
];
const CAPABILITIES = [
	"systemAccent",
	"colorScheme",
	"highContrast",
	"reduceTransparency",
	"textScale",
	"windowFocus",
	"windowMaterial",
	"customTitleBar",
	"nativeMenus",
	"notifications",
	"taskbarProgress",
	"fileDialogs",
	"osVersion",
	"linuxDesktop"
];
const MENU_ROLES = [
	"appMenu",
	"editMenu",
	"windowMenu",
	"about",
	"hide",
	"hideOthers",
	"showAll",
	"quit",
	"undo",
	"redo",
	"cut",
	"copy",
	"paste",
	"selectAll",
	"minimize",
	"zoom",
	"close",
	"toggleFullscreen"
];
const TEXT_SCALES = [
	1,
	1.25,
	1.5,
	1.75,
	2
];
const DEFAULT_ACCENT = "#0078d4";
const DEFAULT_APPEARANCE = {
	skin: "win",
	accent: DEFAULT_ACCENT,
	scheme: "light",
	contrast: "normal",
	reduceTransparency: false,
	reduceMotion: false,
	textScale: 1
};
function staticHost(initial = {}) {
	let state = {
		...DEFAULT_APPEARANCE,
		...initial
	};
	let focused = true;
	const appearanceListeners = /* @__PURE__ */ new Set();
	const focusListeners = /* @__PURE__ */ new Set();
	const subscribe = (set, cb) => {
		set.add(cb);
		return () => set.delete(cb);
	};
	return {
		runtime: "static",
		capabilities: Object.fromEntries(CAPABILITIES.map((c) => [c, "none"])),
		platform: async () => ({
			os: "unknown",
			version: null,
			build: null,
			desktop: null,
			skin: state.skin,
			confidence: "unknown"
		}),
		appearance: async () => state,
		onAppearanceChange: (cb) => subscribe(appearanceListeners, cb),
		window: {
			isFocused: async () => focused,
			onFocusChange: (cb) => subscribe(focusListeners, cb)
		},
		set(patch) {
			state = {
				...state,
				...patch
			};
			appearanceListeners.forEach((cb) => cb(state));
		},
		setFocused(value) {
			focused = value;
			focusListeners.forEach((cb) => cb(value));
		}
	};
}
function hexToRgb(hex) {
	let h = String(hex || "").replace("#", "");
	if (h.length === 3) h = h.split("").map((x) => x + x).join("");
	if (!/^[0-9a-fA-F]{6}$/.test(h)) h = DEFAULT_ACCENT.slice(1);
	const n = parseInt(h, 16);
	return [
		n >> 16 & 255,
		n >> 8 & 255,
		n & 255
	];
}
function rgbToHex(rgb) {
	return "#" + rgb.map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("");
}
function normalizeHex(hex) {
	return rgbToHex(hexToRgb(hex));
}
function mix(a, b, t) {
	const A = hexToRgb(a), B = hexToRgb(b);
	return rgbToHex(A.map((v, i) => v + (B[i] - v) * t));
}
function rgba(hex, alpha) {
	const [r, g, b] = hexToRgb(hex);
	return `rgba(${r},${g},${b},${alpha})`;
}
function toHsl(hex) {
	const [R, G, B] = hexToRgb(hex);
	const r = R / 255, g = G / 255, b = B / 255;
	const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
	const l = (mx + mn) / 2;
	let h = 0, s = 0;
	if (mx !== mn) {
		const d = mx - mn;
		s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
		if (mx === r) h = (g - b) / d + (g < b ? 6 : 0);
		else if (mx === g) h = (b - r) / d + 2;
		else h = (r - g) / d + 4;
		h *= 60;
	}
	return [
		h,
		s,
		l
	];
}
function fromHsl(h, s, l) {
	h = (h % 360 + 360) % 360;
	const c = (1 - Math.abs(2 * l - 1)) * s;
	const x = c * (1 - Math.abs(h / 60 % 2 - 1));
	const m = l - c / 2;
	let r = 0, g = 0, b = 0;
	if (h < 60) [r, g] = [c, x];
	else if (h < 120) [r, g] = [x, c];
	else if (h < 180) [g, b] = [c, x];
	else if (h < 240) [g, b] = [x, c];
	else if (h < 300) [r, b] = [x, c];
	else [r, b] = [c, x];
	return rgbToHex([
		(r + m) * 255,
		(g + m) * 255,
		(b + m) * 255
	]);
}
function adjustLightness(hex, delta) {
	const [h, s, l] = toHsl(hex);
	return fromHsl(h, s, Math.max(0, Math.min(1, l + delta)));
}
function relativeLuminance(hex) {
	const w = [
		.2126,
		.7152,
		.0722
	];
	return hexToRgb(hex).reduce((acc, v, i) => {
		const c = v / 255;
		return acc + w[i] * (c <= .03928 ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4));
	}, 0);
}
function contrastRatio(a, b) {
	const x = relativeLuminance(a), y = relativeLuminance(b);
	return (Math.max(x, y) + .05) / (Math.min(x, y) + .05);
}
function ensureContrast(fg, bg, ratio, lighten) {
	let c = fg;
	for (let i = 0; i < 40 && contrastRatio(c, bg) < ratio; i++) c = adjustLightness(c, lighten ? .03 : -.03);
	return c;
}
function readableOn(bg) {
	return contrastRatio("#ffffff", bg) >= 3 ? "#ffffff" : "#111111";
}
const NEUTRALS = {
	win: {
		light: [
			"#f3f3f3",
			"#fbfbfb",
			"#1a1a1a"
		],
		dark: [
			"#202020",
			"#2b2b2b",
			"#ffffff"
		]
	},
	mac: {
		light: [
			"#f2f2f4",
			"#ffffff",
			"#1d1d1f"
		],
		dark: [
			"#1e1e21",
			"#2c2c2f",
			"#f5f5f7"
		]
	},
	gtk: {
		light: [
			"#fafafb",
			"#ffffff",
			"#2e2e32"
		],
		dark: [
			"#222226",
			"#36363a",
			"#ffffff"
		]
	},
	qt: {
		light: [
			"#eff0f1",
			"#ffffff",
			"#232629"
		],
		dark: [
			"#202326",
			"#141618",
			"#fcfcfc"
		]
	}
};
const BASE_OF = {
	win: "win",
	w10: "win",
	mac: "mac",
	macc: "mac",
	gtk: "gtk",
	cros: "gtk",
	qt: "qt",
	web: "gtk"
};
function semantic(accent, hue, dark) {
	const [, s0, l0] = toHsl(accent);
	return fromHsl(hue, Math.max(.55, Math.min(.85, s0)), Math.max(.42, Math.min(.52, l0)) + (dark ? .08 : 0));
}
function baseTokens(p, acc, dark) {
	const [n0, n1, fg] = NEUTRALS[p][dark ? "dark" : "light"];
	const [h, s, l] = toHsl(acc);
	const bg = mix(n0, acc, p === "win" ? .05 : .03);
	const surface = mix(n1, acc, dark ? .04 : .015);
	let primary = acc;
	if (p === "win") primary = dark ? fromHsl(h, s, Math.min(.8, Math.max(l + .2, .68))) : adjustLightness(acc, -.06);
	if (p === "mac" && dark) primary = adjustLightness(acc, .04);
	const accentText = ensureContrast(acc, bg, 4.5, dark);
	const secondary = mix(surface, acc, dark ? .22 : .12);
	const danger = semantic(acc, 356, dark);
	const success = semantic(acc, 145, dark);
	const warning = semantic(acc, 38, dark);
	let wall = bg;
	if (p === "mac") wall = `radial-gradient(60% 90% at 10% 10%, ${rgba(fromHsl(h + 35, Math.max(s, .5), dark ? .4 : .7), dark ? .5 : .45)}, transparent 70%), radial-gradient(55% 80% at 92% 95%, ${rgba(acc, dark ? .45 : .32)}, transparent 70%), ${bg}`;
	else if (p === "win") wall = `linear-gradient(135deg, ${mix(bg, acc, dark ? .1 : .08)}, ${bg} 60%)`;
	return {
		wall,
		bg,
		surface: p === "mac" ? rgba(surface, .6) : surface,
		surfaceSolid: surface,
		fg,
		fgMuted: ensureContrast(mix(mix(fg, acc, .12), bg, .38), bg, 4.5, dark),
		accent: acc,
		primary,
		primaryFg: readableOn(primary),
		primaryEdge: adjustLightness(primary, -.12),
		secondary,
		secondaryFg: ensureContrast(accentText, secondary, 4.5, dark),
		accentText,
		muted: mix(bg, acc, dark ? .08 : .06),
		border: mix(mix(bg, fg, dark ? .18 : .14), acc, .12),
		ring: rgba(acc, .5),
		danger,
		dangerFg: readableOn(danger),
		success,
		successFg: readableOn(success),
		warning,
		warningFg: readableOn(warning),
		stroke: rgba(fg, dark ? .08 : .07),
		strokeBottom: rgba(fg, dark ? .05 : .16),
		controlStrong: mix(bg, fg, p === "win" ? .55 : .3),
		track: mix(mix(bg, fg, dark ? .22 : .16), acc, .08),
		control: mix(mix(bg, fg, dark ? .1 : .08), acc, .05),
		hover: mix(surface, fg, .06),
		acrylic: rgba(surface, .9),
		glass: rgba(mix(surface, acc, .05), dark ? .42 : .5),
		glassBorder: dark ? "rgba(255,255,255,.12)" : "rgba(255,255,255,.65)",
		glassHighlight: dark ? "rgba(255,255,255,.14)" : "rgba(255,255,255,.9)",
		segmentOn: dark ? mix(bg, "#ffffff", .16) : "#ffffff",
		scrim: p === "mac" ? "rgba(0,0,0,.18)" : "rgba(0,0,0,.32)",
		toast: dark ? "#48484d" : "#2f2f33",
		inputStroke: rgba(fg, dark ? .55 : .45),
		sidebar: mix(bg, fg, dark ? .06 : .04)
	};
}
function solid(t) {
	return {
		...t,
		wall: t.bg,
		surface: t.surfaceSolid,
		acrylic: t.surfaceSolid,
		glass: t.surfaceSolid,
		glassBorder: t.stroke,
		glassHighlight: "transparent"
	};
}
function material3(t, acc, dark) {
	const [h, s] = toHsl(acc);
	const sc = Math.max(.35, Math.min(.8, s));
	const T = (sat, l) => fromHsl(h, sat, l);
	const c = dark ? {
		primary: T(sc, .8),
		pfg: T(sc, .2),
		pc: T(sc, .3),
		opc: T(sc, .9),
		scn: T(.2, .3),
		osc: T(.25, .88),
		surface: T(.12, .07),
		low: T(.1, .1),
		cont: T(.1, .12),
		high: T(.1, .15),
		highest: T(.1, .18),
		on: T(.08, .9),
		onv: T(.08, .8),
		outline: T(.06, .58),
		ov: T(.08, .3),
		inv: T(.06, .9),
		invP: T(sc, .4),
		err: "#f2b8b5",
		onErr: "#601410"
	} : {
		primary: T(sc, .4),
		pfg: "#ffffff",
		pc: T(sc * .9, .9),
		opc: T(sc, .15),
		scn: T(.25, .88),
		osc: T(.3, .18),
		surface: T(.15, .985),
		low: T(.12, .96),
		cont: T(.12, .945),
		high: T(.12, .925),
		highest: T(.1, .9),
		on: T(.08, .11),
		onv: T(.08, .3),
		outline: T(.06, .47),
		ov: T(.08, .79),
		inv: T(.06, .19),
		invP: T(sc, .8),
		err: "#b3261e",
		onErr: "#ffffff"
	};
	return {
		...t,
		wall: c.surface,
		bg: c.surface,
		surface: c.low,
		surfaceSolid: c.low,
		sidebar: c.low,
		fg: c.on,
		fgMuted: ensureContrast(c.onv, c.surface, 4.5, dark),
		primary: c.primary,
		primaryFg: c.pfg,
		primaryEdge: c.invP,
		secondary: c.scn,
		secondaryFg: c.osc,
		segmentOn: c.scn,
		accentText: ensureContrast(c.primary, c.surface, 4.5, dark),
		border: c.outline,
		inputStroke: c.outline,
		stroke: c.ov,
		controlStrong: c.onv,
		track: c.highest,
		control: c.high,
		hover: c.cont,
		acrylic: c.high,
		glass: c.cont,
		glassBorder: c.pc,
		glassHighlight: c.opc,
		toast: c.inv,
		ring: rgba(c.primary, .5),
		danger: c.err,
		dangerFg: c.onErr
	};
}
function derivePalette({ skin, accent, scheme, reduceTransparency = false }) {
	const acc = normalizeHex(accent);
	const dark = scheme === "dark";
	let t = baseTokens(BASE_OF[skin], acc, dark);
	if (skin === "qt") t = {
		...t,
		control: mix(dark ? "#292c30" : "#fcfcfc", acc, .02),
		controlStrong: mix(t.bg, t.fg, dark ? .5 : .45),
		border: mix(mix(t.bg, t.fg, dark ? .25 : .2), acc, .08),
		hover: mix(t.surfaceSolid, acc, dark ? .25 : .15)
	};
	if (skin === "w10") t = {
		...t,
		wall: t.bg,
		acrylic: t.surfaceSolid,
		primary: acc,
		primaryFg: readableOn(acc),
		primaryEdge: adjustLightness(acc, -.12)
	};
	if (skin === "macc") t = {
		...t,
		wall: t.bg,
		glass: rgba(t.surfaceSolid, dark ? .72 : .8),
		glassBorder: t.stroke,
		glassHighlight: "transparent"
	};
	if (reduceTransparency) t = solid(t);
	if (skin === "cros") t = material3(t, acc, dark);
	return t;
}
const kebab = (key) => key.replace(/[A-Z]/g, (c) => "-" + c.toLowerCase());
function paletteVarName(key) {
	return `--sn-color-${kebab(key)}`;
}
function paletteToCssVars(palette) {
	const out = {};
	for (const key of Object.keys(palette)) out[paletteVarName(key)] = palette[key];
	return out;
}
function resolveSkin(info) {
	switch (info.os) {
		case "windows": return info.build !== null && info.build < 22e3 ? "w10" : "win";
		case "macos": {
			const major = info.version ? parseInt(info.version, 10) : NaN;
			return Number.isFinite(major) && major < 26 ? "macc" : "mac";
		}
		case "linux": return info.desktop === "kde" ? "qt" : "gtk";
		case "chromeos": return "cros";
		default: return "web";
	}
}
function skinClasses(skin) {
	switch (skin) {
		case "w10": return ["t-win", "t-w10"];
		case "macc": return ["t-mac", "t-macc"];
		default: return [`t-${skin}`];
	}
}
const SKIN_LABELS = {
	win: "Windows 11",
	w10: "Windows 10",
	mac: "macOS 26",
	macc: "macOS 13–15",
	gtk: "GNOME",
	qt: "KDE Plasma",
	cros: "ChromeOS",
	web: "Web"
};
const SCHEME_LABELS = {
	light: "Light",
	dark: "Dark"
};
const CONTRAST_LABELS = {
	normal: "Standard",
	more: "Increased",
	forced: "Contrast theme"
};
const SKIN_OPTIONS = STYLED_SKINS.map((value) => ({
	value,
	label: SKIN_LABELS[value]
}));
const TEXT_SCALE_OPTIONS = TEXT_SCALES.map((value) => ({
	value,
	label: `${Math.round(value * 100)} %`
}));
const OWNED = /^(t-[a-z0-9]+|dark|rt|inactive|hc|reduce-motion)$/;
function applySpartanNative(root, a) {
	const classes = [
		...skinClasses(a.skin),
		...a.scheme === "dark" ? ["dark"] : [],
		...a.reduceTransparency ? ["rt"] : [],
		...a.focused ? [] : ["inactive"],
		...a.contrast !== "normal" ? ["hc"] : [],
		...a.reduceMotion ? ["reduce-motion"] : []
	];
	const stale = Array.from(root.classList).filter((c) => OWNED.test(c) && !classes.includes(c));
	root.classList.remove(...stale);
	root.classList.add(...classes);
	root.dataset["snSkin"] = a.skin;
	const vars = paletteToCssVars(derivePalette({
		skin: a.skin,
		accent: a.accent,
		scheme: a.scheme,
		reduceTransparency: a.reduceTransparency
	}));
	for (const [name, value] of Object.entries(vars)) root.style.setProperty(name, value);
	root.style.setProperty("--sn-text-scale", String(a.textScale));
	root.style.colorScheme = a.scheme;
}
function skinFamily(skin) {
	switch (skin) {
		case "win":
		case "w10": return "windows";
		case "mac":
		case "macc": return "macos";
		case "gtk":
		case "qt": return "linux";
		case "cros": return "chromeos";
		default: return "web";
	}
}
const NATIVE_HOST = new InjectionToken("NATIVE_HOST");
const DEFAULT_PERSIST_KEY = "spartan-native:overrides";
const APPEARANCE_KEYS = [
	"skin",
	"accent",
	"scheme",
	"contrast",
	"reduceTransparency",
	"reduceMotion",
	"textScale"
];
function persistence(option) {
	if (!option) return null;
	const config = option === true ? {} : option;
	let storage = config.storage;
	if (!storage) try {
		storage = globalThis.localStorage;
	} catch {
		storage = void 0;
	}
	return storage ? {
		key: config.key ?? "spartan-native:overrides",
		storage
	} : null;
}
function readStoredOverrides(storage, key = DEFAULT_PERSIST_KEY) {
	try {
		const raw = storage.getItem(key);
		const parsed = raw ? JSON.parse(raw) : null;
		if (!parsed || typeof parsed !== "object") return {};
		const out = {};
		for (const k of APPEARANCE_KEYS) {
			const v = parsed[k];
			if (v !== void 0 && typeof v === typeof DEFAULT_APPEARANCE[k]) out[k] = v;
		}
		return out;
	} catch {
		return {};
	}
}
const SPARTAN_NATIVE_OPTIONS = new InjectionToken("SPARTAN_NATIVE_OPTIONS");
var SpartanNativeTheme = class SpartanNativeTheme {
	host = inject(NATIVE_HOST);
	doc = inject(DOCUMENT);
	options = inject(SPARTAN_NATIVE_OPTIONS);
	fromHost = signal(DEFAULT_APPEARANCE, ...ngDevMode ? [{ debugName: "fromHost" }] : /* istanbul ignore next */ []);
	store = persistence(this.options.persist);
	userOverrides = signal({
		...this.options.overrides,
		...this.store ? readStoredOverrides(this.store.storage, this.store.key) : {}
	}, ...ngDevMode ? [{ debugName: "userOverrides" }] : /* istanbul ignore next */ []);
	platform = signal(null, ...ngDevMode ? [{ debugName: "platform" }] : /* istanbul ignore next */ []);
	focused = signal(true, ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	overrides = this.userOverrides.asReadonly();
	followsSystem = computed(() => Object.keys(this.userOverrides()).length === 0, ...ngDevMode ? [{ debugName: "followsSystem" }] : /* istanbul ignore next */ []);
	appearance = computed(() => ({
		...this.fromHost(),
		...this.userOverrides()
	}), ...ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []);
	skin = computed(() => this.appearance().skin, ...ngDevMode ? [{ debugName: "skin" }] : /* istanbul ignore next */ []);
	scheme = computed(() => this.appearance().scheme, ...ngDevMode ? [{ debugName: "scheme" }] : /* istanbul ignore next */ []);
	textScale = computed(() => this.appearance().textScale, ...ngDevMode ? [{ debugName: "textScale" }] : /* istanbul ignore next */ []);
	nativeSkin = computed(() => this.platform()?.skin ?? this.skin(), ...ngDevMode ? [{ debugName: "nativeSkin" }] : /* istanbul ignore next */ []);
	platformFamily = computed(() => skinFamily(this.nativeSkin()), ...ngDevMode ? [{ debugName: "platformFamily" }] : /* istanbul ignore next */ []);
	runtime = this.host.runtime;
	window = this.host.window;
	menus = this.host.menus;
	capabilities = this.host.capabilities;
	constructor() {
		effect(() => {
			const resolved = {
				...this.appearance(),
				focused: this.focused()
			};
			applySpartanNative(this.doc.documentElement, resolved);
			this.doc.documentElement.dataset["snPlatform"] = this.nativeSkin();
		});
		if (this.store) {
			const { key, storage } = this.store;
			effect(() => {
				const overrides = this.userOverrides();
				try {
					if (Object.keys(overrides).length) storage.setItem(key, JSON.stringify(overrides));
					else storage.removeItem(key);
				} catch {}
			});
		}
		const destroyRef = inject(DestroyRef);
		destroyRef.onDestroy(this.host.onAppearanceChange((s) => this.fromHost.set(s)));
		destroyRef.onDestroy(this.host.window.onFocusChange((f) => this.focused.set(f)));
	}
	async init() {
		const [platform, appearance, focused] = await Promise.all([
			this.host.platform(),
			this.host.appearance(),
			this.host.window.isFocused()
		]);
		this.platform.set(platform);
		this.fromHost.set({
			...appearance,
			skin: appearance.skin ?? platform.skin
		});
		this.focused.set(focused);
	}
	override(patch) {
		this.userOverrides.update((o) => ({
			...o,
			...patch
		}));
	}
	followSystem() {
		this.userOverrides.set({});
	}
	capability(name) {
		return this.host.capabilities[name];
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SpartanNativeTheme,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: SpartanNativeTheme
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: SpartanNativeTheme,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function provideSpartanNative(options) {
	return makeEnvironmentProviders([
		{
			provide: SPARTAN_NATIVE_OPTIONS,
			useValue: options
		},
		{
			provide: NATIVE_HOST,
			useValue: options.host
		},
		SpartanNativeTheme,
		provideAppInitializer(() => inject(SpartanNativeTheme).init())
	]);
}
function injectSkin() {
	const theme = inject(SpartanNativeTheme, { optional: true });
	if (theme) return theme.skin;
	const root = inject(DOCUMENT).documentElement;
	const read = () => root.dataset["snSkin"] ?? "web";
	const skin = signal(read(), ...ngDevMode ? [{ debugName: "skin" }] : /* istanbul ignore next */ []);
	if (typeof MutationObserver !== "undefined") {
		const observer = new MutationObserver(() => skin.set(read()));
		observer.observe(root, {
			attributes: true,
			attributeFilter: ["data-sn-skin"]
		});
		inject(DestroyRef).onDestroy(() => observer.disconnect());
	}
	return skin.asReadonly();
}
function injectNativeSkin() {
	const theme = inject(SpartanNativeTheme, { optional: true });
	if (theme) return theme.nativeSkin;
	const skin = injectSkin();
	const root = inject(DOCUMENT).documentElement;
	const read = () => root.dataset["snPlatform"];
	const platform = signal(read(), ...ngDevMode ? [{ debugName: "platform" }] : /* istanbul ignore next */ []);
	if (typeof MutationObserver !== "undefined") {
		const observer = new MutationObserver(() => platform.set(read()));
		observer.observe(root, {
			attributes: true,
			attributeFilter: ["data-sn-platform"]
		});
		inject(DestroyRef).onDestroy(() => observer.disconnect());
	}
	return computed(() => platform() ?? skin());
}
function injectPlatformFamily() {
	const theme = inject(SpartanNativeTheme, { optional: true });
	if (theme) return theme.platformFamily;
	const native = injectNativeSkin();
	return computed(() => skinFamily(native()));
}
export { CAPABILITIES, CONTRAST_LABELS, DEFAULT_ACCENT, DEFAULT_APPEARANCE, DEFAULT_PERSIST_KEY, MENU_ROLES, NATIVE_HOST, SCHEME_LABELS, SKIN_LABELS, SKIN_OPTIONS, SPARTAN_NATIVE_OPTIONS, STYLED_SKINS, SpartanNativeTheme, TEXT_SCALES, TEXT_SCALE_OPTIONS, adjustLightness, applySpartanNative, contrastRatio, derivePalette, ensureContrast, fromHsl, hexToRgb, injectNativeSkin, injectPlatformFamily, injectSkin, mix, normalizeHex, paletteToCssVars, paletteVarName, provideSpartanNative, readStoredOverrides, readableOn, relativeLuminance, resolveSkin, rgbToHex, rgba, skinClasses, skinFamily, staticHost, toHsl };

//# sourceMappingURL=spartan-native-theme.mjs.map