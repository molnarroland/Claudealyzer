// packages/theme/storybook/manager/index.tsx
import React from "react";
import { Select, Separator, ToggleButton } from "storybook/internal/components";
import { addons, types, useGlobals, useGlobalTypes } from "storybook/manager-api";
import { AppleIcon, ChromeIcon, ContrastIcon, EyeCloseIcon, LinuxIcon, MirrorIcon, WindowsIcon } from "@storybook/icons";

// packages/theme/storybook/src/toolbar-options.ts
var STORYBOOK_SKINS = [
  { value: "win", title: "Windows 11", family: "windows" },
  { value: "w10", title: "Windows 10", family: "windows" },
  { value: "mac", title: "macOS 26", family: "apple" },
  { value: "macc", title: "macOS 13\u201315", family: "apple" },
  { value: "gtk", title: "GNOME \xB7 GTK 4", family: "linux" },
  { value: "qt", title: "KDE Plasma", family: "linux" },
  { value: "cros", title: "ChromeOS", family: "chrome" }
];
var ACCENT_PRESETS = [
  { value: "#0078d4", title: "Windows blue" },
  { value: "#007aff", title: "macOS blue" },
  { value: "#3584e4", title: "GNOME blue" },
  { value: "#9141ac", title: "Purple" },
  { value: "#e66100", title: "Orange" },
  { value: "#26a269", title: "Green" },
  { value: "#d56199", title: "Pink" }
];

// packages/theme/storybook/manager/index.tsx
var ADDON_ID = "spartan-native/toolbar";
var OS_ICONS = {
  windows: /* @__PURE__ */ React.createElement(WindowsIcon, null),
  apple: /* @__PURE__ */ React.createElement(AppleIcon, null),
  linux: /* @__PURE__ */ React.createElement(LinuxIcon, null),
  chrome: /* @__PURE__ */ React.createElement(ChromeIcon, null)
};
var Swatch = ({ color }) => /* @__PURE__ */ React.createElement(
  "span",
  {
    "aria-hidden": "true",
    style: {
      display: "inline-block",
      width: 14,
      height: 14,
      borderRadius: "50%",
      background: color,
      boxShadow: "inset 0 0 0 1px rgb(0 0 0 / 0.2)",
      flex: "none"
    }
  }
);
function Switch(props) {
  const [globals, updateGlobals] = useGlobals();
  const pressed = globals[props.global] === props.on;
  return /* @__PURE__ */ React.createElement(
    ToggleButton,
    {
      variant: "ghost",
      padding: "small",
      pressed,
      ariaLabel: props.label,
      tooltip: `${props.label}: ${pressed ? "on" : "off"}`,
      onClick: () => updateGlobals({ [props.global]: pressed ? props.off : props.on })
    },
    props.icon
  );
}
var Toolbar = React.memo(function Toolbar2() {
  const [globals, updateGlobals] = useGlobals();
  const declared = useGlobalTypes();
  const has = (key) => key in declared;
  const skin = STORYBOOK_SKINS.find((s) => s.value === globals["skin"]) ?? STORYBOOK_SKINS[0];
  const accent = String(globals["accent"] ?? ACCENT_PRESETS[0].value).toLowerCase();
  const preset = ACCENT_PRESETS.find((p) => p.value === accent);
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Separator, null), has("skin") && /* @__PURE__ */ React.createElement(
    Select,
    {
      key: `skin-${skin.value}`,
      ariaLabel: "Operating system",
      icon: OS_ICONS[skin.family],
      defaultOptions: skin.value,
      options: STORYBOOK_SKINS.map((s) => ({ value: s.value, title: s.title, icon: OS_ICONS[s.family] })),
      onSelect: (value) => updateGlobals({ skin: value })
    },
    skin.title
  ), has("transparency") && /* @__PURE__ */ React.createElement(Switch, { global: "transparency", on: "reduced", off: "normal", label: "Reduce transparency", icon: /* @__PURE__ */ React.createElement(MirrorIcon, null) }), has("contrast") && /* @__PURE__ */ React.createElement(Switch, { global: "contrast", on: "more", off: "normal", label: "Increase contrast", icon: /* @__PURE__ */ React.createElement(ContrastIcon, null) }), has("window") && /* @__PURE__ */ React.createElement(Switch, { global: "window", on: "inactive", off: "focused", label: "Inactive window", icon: /* @__PURE__ */ React.createElement(EyeCloseIcon, null) }), has("accent") && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(
    Select,
    {
      key: `accent-${accent}`,
      ariaLabel: "Accent color",
      icon: /* @__PURE__ */ React.createElement(Swatch, { color: accent }),
      defaultOptions: preset?.value,
      options: ACCENT_PRESETS.map((p) => ({
        value: p.value,
        title: p.title,
        icon: /* @__PURE__ */ React.createElement(Swatch, { color: p.value }),
        aside: p.value
      })),
      onSelect: (value) => updateGlobals({ accent: value })
    },
    preset?.title ?? accent
  ), /* @__PURE__ */ React.createElement("label", { title: "Custom accent color", style: { display: "inline-flex", alignItems: "center", cursor: "pointer" } }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "color",
      "aria-label": "Custom accent color",
      value: accent,
      onChange: (e) => updateGlobals({ accent: e.currentTarget.value }),
      style: { width: 22, height: 22, padding: 0, border: 0, background: "none", cursor: "pointer" }
    }
  ))));
});
addons.register(ADDON_ID, () => {
  addons.add(ADDON_ID, {
    title: "Spartan Native",
    type: types.TOOL,
    match: ({ viewMode, tabId }) => !!viewMode?.match(/^(story|docs)$/) && !tabId,
    render: () => /* @__PURE__ */ React.createElement(Toolbar, null)
  });
});
//# sourceMappingURL=manager.mjs.map
