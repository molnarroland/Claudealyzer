import * as i0 from "@angular/core";
import { EnvironmentProviders, InjectionToken, Signal } from "@angular/core";
/**
 * The host contract (docs/07-host-adapters.md).
 * Every @spartan-native/host-* adapter implements NativeHost; the theme and the
 * components only ever talk to this interface.
 */
/** Platform skin. `web` is the generic fallback when the OS is unknown. */
export type Skin = 'win' | 'w10' | 'mac' | 'macc' | 'gtk' | 'qt' | 'cros' | 'web';
/** The skins with a full style sheet in this release. */
export declare const STYLED_SKINS: readonly ["win", "w10", "mac", "macc", "gtk", "qt", "cros"];
export type StyledSkin = (typeof STYLED_SKINS)[number];
export type ColorScheme = 'light' | 'dark';
export type ContrastPreference = 'normal' | 'more' | 'forced';
/** The settings the user already chose in the OS. */
export interface AppearanceState {
  /** From PlatformInfo; the user can override it. */
  skin: Skin;
  /** `#rrggbb` */
  accent: string;
  scheme: ColorScheme;
  contrast: ContrastPreference;
  reduceTransparency: boolean;
  reduceMotion: boolean;
  /** 1 = 100 %. Supported steps: 1, 1.25, 1.5, 1.75, 2. */
  textScale: number;
}
export interface PlatformInfo {
  os: 'windows' | 'macos' | 'linux' | 'chromeos' | 'unknown';
  /** '10.0.22631', '26.1', '15.6' … */
  version: string | null;
  /** Windows: ≥ 22000 means Windows 11. */
  build: number | null;
  desktop: 'gnome' | 'kde' | 'cinnamon' | 'xfce' | 'other' | null;
  /** Resolved with resolveSkin(). */
  skin: Skin;
  confidence: 'exact' | 'hint' | 'unknown';
}
/** One key per row of the capability matrix. */
export type Capability = 'systemAccent' | 'colorScheme' | 'highContrast' | 'reduceTransparency' | 'textScale' | 'windowFocus' | 'windowMaterial' | 'customTitleBar' | 'nativeMenus' | 'notifications' | 'taskbarProgress' | 'fileDialogs' | 'osVersion' | 'linuxDesktop';
/** Every capability, in matrix order. Adapters and the conformance suite iterate this. */
export declare const CAPABILITIES: readonly Capability[];
export type CapabilityLevel = 'native' | 'partial' | 'none';
export type HostCapabilities = Record<Capability, CapabilityLevel>;
export type Unsubscribe = () => void;
/**
 * Window services. Focus is required; the window actions are optional: hosts that
 * own a real window (Wails, Tauri, Electron, Photino) implement them, and
 * desktop-ui's window controls call them automatically.
 */
export interface WindowHost {
  isFocused(): Promise<boolean>;
  onFocusChange(cb: (focused: boolean) => void): Unsubscribe;
  minimize?(): Promise<void>;
  toggleMaximize?(): Promise<void>;
  close?(): Promise<void>;
  isMaximized?(): Promise<boolean>;
  onMaximizedChange?(cb: (maximized: boolean) => void): Unsubscribe;
}
/**
 * Standard OS menu items the runtime builds itself, with the OS's own label, shortcut and action.
 * The `…Menu` roles are whole submenus (macOS app menu, Edit, Window). Roles the OS doesn't have
 * (the app menu, Hide, Services outside macOS) are left out by the adapter.
 */
export type MenuRole = 'appMenu' | 'editMenu' | 'windowMenu' | 'about' | 'hide' | 'hideOthers' | 'showAll' | 'quit' | 'undo' | 'redo' | 'cut' | 'copy' | 'paste' | 'selectAll' | 'minimize' | 'zoom' | 'close' | 'toggleFullscreen';
export declare const MENU_ROLES: readonly MenuRole[];
/**
 * One entry of a native menu: plain data, so it can cross into Go, Rust, Node or .NET.
 * An item with `submenu` opens a submenu; `type: 'separator'` is a divider (other fields ignored).
 */
export interface MenuItem {
  /** Reported to `MenuHost.onAction` when the item is chosen. Unique within the menu. */
  readonly id?: string;
  readonly label?: string;
  /** Default: `'normal'`. Radio items between two separators form one group. */
  readonly type?: 'normal' | 'checkbox' | 'radio' | 'separator';
  /** A shortcut in the portable notation of desktop-ui's `formatShortcut()`: `mod+shift+s`, `delete`, `f2`. */
  readonly accelerator?: string;
  /** Default: true. */
  readonly enabled?: boolean;
  readonly checked?: boolean;
  /** A standard OS item; label and action come from the OS (a `label` overrides the text). */
  readonly role?: MenuRole;
  readonly submenu?: readonly MenuItem[];
}
/**
 * Native app & context menus. Optional on NativeHost; a host lists only what its runtime
 * can do (capability `nativeMenus`). Chosen items come back through `onAction` by id, from
 * both kinds of menu; roles are handled by the OS and not reported.
 */
export interface MenuHost {
  /**
   * Sets the application menu: the global menu bar on macOS, the window's menu bar elsewhere.
   * Call it again with the whole menu to update labels, `enabled` or `checked`. An empty array
   * removes it.
   */
  setApplicationMenu?(menu: readonly MenuItem[]): Promise<void>;
  /** Shows a native context menu at `x`, `y` (CSS pixels, relative to the window's content). */
  showContextMenu?(menu: readonly MenuItem[], position: {
    x: number;
    y: number;
  }): Promise<void>;
  /** An item with an `id` was chosen in either kind of menu. */
  onAction(cb: (id: string) => void): Unsubscribe;
}
/** One entry of a file dialog's type list. */
export interface FileFilter {
  /** Shown in the dialog: `'Images'`. */
  readonly name: string;
  /** Without the dot: `['png', 'jpg']`. `['*']` matches every file. */
  readonly extensions: readonly string[];
}
interface FileDialogOptions {
  /** The dialog's title (not shown by every OS). */
  readonly title?: string;
  /** The text of the confirm button. Default: the OS's own ("Open", "Save", …). */
  readonly buttonLabel?: string;
  /** Native hosts: the folder to start in. Browsers ignore it. */
  readonly directory?: string;
}
export interface OpenFileOptions extends FileDialogOptions {
  readonly filters?: readonly FileFilter[];
  /** Default: false. */
  readonly multiple?: boolean;
}
export interface SaveFileOptions extends FileDialogOptions {
  readonly filters?: readonly FileFilter[];
  /** The suggested file name: `'Report.pdf'`. */
  readonly fileName?: string;
}
export type PickFolderOptions = FileDialogOptions;
/**
 * A file or folder the user chose. Native hosts give a `path`; the browser has no paths
 * and gives a File System Access `handle` instead. `name` is always set.
 */
export interface PickedFile {
  readonly name: string;
  readonly path?: string;
  readonly handle?: FileSystemHandle;
}
/** The OS's own alert. Buttons are listed in reading order; the OS places them its own way. */
export interface MessageOptions {
  /** Default: `'info'`. Picks the icon. */
  readonly kind?: 'info' | 'question' | 'warning' | 'error';
  readonly title?: string;
  readonly message: string;
  /** Default: one "OK" button with id `'ok'`. */
  readonly buttons?: readonly {
    readonly id: string;
    readonly label: string;
  }[];
  /** Enter presses this one. */
  readonly defaultId?: string;
  /** Esc (and closing the alert) presses this one. */
  readonly cancelId?: string;
}
/**
 * Native file dialogs and alerts. Optional on NativeHost; present exactly when the
 * `fileDialogs` capability isn't `none`. A cancelled dialog resolves to `[]` or `null`, never rejects.
 */
export interface DialogHost {
  /** Resolves the chosen files, or `[]` when cancelled. */
  openFile(options?: OpenFileOptions): Promise<PickedFile[]>;
  /** Resolves where to save, or `null` when cancelled. */
  saveFile(options?: SaveFileOptions): Promise<PickedFile | null>;
  /** Resolves the chosen folder, or `null` when cancelled. */
  pickFolder(options?: PickFolderOptions): Promise<PickedFile | null>;
  /**
   * Shows the OS's alert and resolves the id of the pressed button (`cancelId` when it was
   * dismissed). Absent where the OS has none (the browser): draw an hlm-alert-dialog instead.
   */
  message?(options: MessageOptions): Promise<string | null>;
}
/** OS notifications. Specified in phase 05 (docs/10-open-questions.md, Q2). */
export type NotificationHost = Record<string, never>;
export interface NativeHost {
  readonly runtime: 'web' | 'wails' | 'tauri' | 'electron' | 'dotnet' | 'static';
  readonly capabilities: HostCapabilities;
  platform(): Promise<PlatformInfo>;
  appearance(): Promise<AppearanceState>;
  onAppearanceChange(cb: (state: AppearanceState) => void): Unsubscribe;
  readonly window: WindowHost;
  /** Native menus; absent when the runtime has none (then desktop-ui draws them in the page). */
  readonly menus?: MenuHost;
  /** File dialogs and alerts; absent when the runtime has none (capability `fileDialogs`). */
  readonly dialogs?: DialogHost;
  readonly notifications?: NotificationHost;
}
export declare const TEXT_SCALES: readonly [1, 1.25, 1.5, 1.75, 2];
export declare const DEFAULT_ACCENT = "#0078d4";
export declare const DEFAULT_APPEARANCE: AppearanceState;
/** A host whose values are set by code, not read from the OS. */
export interface StaticHost extends NativeHost {
  /** Change the appearance; subscribers are notified like an OS change. */
  set(patch: Partial<AppearanceState>): void;
  /** Simulate the window gaining or losing focus. */
  setFocused(focused: boolean): void;
}
/**
 * A NativeHost with fixed, code-controlled values. Every capability is `'none'`.
 * Use it for Storybook, tests, demos and apps that let the user pick the look themselves.
 */
export declare function staticHost(initial?: Partial<AppearanceState>): StaticHost;
export type Rgb = [number, number, number];
export type Hsl = [h: number, s: number, l: number];
export declare function hexToRgb(hex: string): Rgb;
export declare function rgbToHex(rgb: readonly number[]): string;
/** Normalises any accepted input to lower-case `#rrggbb`. */
export declare function normalizeHex(hex: string): string;
/** Linear RGB interpolation from `a` (t = 0) to `b` (t = 1). */
export declare function mix(a: string, b: string, t: number): string;
export declare function rgba(hex: string, alpha: number): string;
export declare function toHsl(hex: string): Hsl;
export declare function fromHsl(h: number, s: number, l: number): string;
/** Shift HSL lightness by `delta`, clamped to 0–1. */
export declare function adjustLightness(hex: string, delta: number): string;
export declare function relativeLuminance(hex: string): number;
/** WCAG 2 contrast ratio between two colors. */
export declare function contrastRatio(a: string, b: string): number;
/**
 * Step `fg` lightness by ±0.03 (max 40 steps) until it reaches `ratio` against `bg`.
 * `lighten` = true in dark mode, false in light mode.
 */
export declare function ensureContrast(fg: string, bg: string, ratio: number, lighten: boolean): string;
/** White text when it reaches 3:1 on `bg`, otherwise near-black. */
export declare function readableOn(bg: string): string;
/** Every color token. Keys map 1:1 to `--sn-color-<kebab-key>` (see palette-css-vars.ts). */
export interface Palette {
  /** Backdrop behind materials: a gradient on Windows 11 and macOS 26, `bg` elsewhere. */
  wall: string;
  bg: string;
  /** Surface; translucent on macOS 26. */
  surface: string;
  surfaceSolid: string;
  fg: string;
  fgMuted: string;
  accent: string;
  primary: string;
  primaryFg: string;
  /** Primary darkened by 12 % lightness (Fluent bottom edge). */
  primaryEdge: string;
  secondary: string;
  secondaryFg: string;
  /** The accent as text, ≥ 4.5:1 on `bg`. */
  accentText: string;
  muted: string;
  border: string;
  ring: string;
  danger: string;
  dangerFg: string;
  success: string;
  successFg: string;
  warning: string;
  warningFg: string;
  /** Hairline control borders. */
  stroke: string;
  /** Bottom edge of Fluent controls. */
  strokeBottom: string;
  /** Unchecked checkbox / radio / switch outline. */
  controlStrong: string;
  /** Switch and slider track. */
  track: string;
  /** Neutral control fill (GTK buttons and entries). */
  control: string;
  hover: string;
  acrylic: string;
  glass: string;
  glassBorder: string;
  glassHighlight: string;
  segmentOn: string;
  scrim: string;
  toast: string;
  inputStroke: string;
  sidebar: string;
}
export interface DeriveOptions {
  skin: Skin;
  accent: string;
  scheme: ColorScheme;
  reduceTransparency?: boolean;
}
/** Derive every color token for one skin, scheme and accent. Deterministic. */
export declare function derivePalette({ skin, accent, scheme, reduceTransparency }: DeriveOptions): Palette;
/** `fgMuted` → `--sn-color-fg-muted`. The names match styles/contract/_tokens.scss. */
export declare function paletteVarName(key: keyof Palette): string;
/** The palette as CSS custom properties. */
export declare function paletteToCssVars(palette: Palette): Record<string, string>;
/**
 * The fallback table from docs/07-host-adapters.md: detected OS → skin.
 * Cinnamon, XFCE and unknown Linux desktops use GTK (docs/10-open-questions.md, Q7).
 */
export declare function resolveSkin(info: Pick<PlatformInfo, 'os' | 'version' | 'build' | 'desktop'>): Skin;
/**
 * Root classes per skin. Variants inherit their parent family:
 * `w10` also gets `t-win`, `macc` also gets `t-mac`.
 */
export declare function skinClasses(skin: Skin): string[];
/** The display name of each skin, for settings screens ("Look like: Windows 11"). */
export declare const SKIN_LABELS: Readonly<Record<Skin, string>>;
/** The display name of each color scheme. */
export declare const SCHEME_LABELS: Readonly<Record<ColorScheme, string>>;
/** The display name of each contrast preference. */
export declare const CONTRAST_LABELS: Readonly<Record<ContrastPreference, string>>;
/** One choice of a settings control: a value and its label. */
export interface SnOption<T> {
  readonly value: T;
  readonly label: string;
}
/** The skins a user can pick from (every styled skin), labelled. */
export declare const SKIN_OPTIONS: readonly SnOption<StyledSkin>[];
/** The supported text sizes, labelled as percentages ("125 %"). */
export declare const TEXT_SCALE_OPTIONS: readonly SnOption<number>[];
/** Everything applySpartanNative() needs: the OS appearance plus window focus. */
export interface ResolvedAppearance extends AppearanceState {
  focused: boolean;
}
/**
 * Writes an appearance onto a root element (usually `<html>`):
 *  - classes: `t-<skin>`, `dark`, `rt` (reduce transparency), `inactive` (window not focused),
 *    `hc` (more/forced contrast), `reduce-motion`
 *  - variables: every `--sn-color-*` from derivePalette(), plus `--sn-text-scale`
 *  - `color-scheme`, so native form controls and scrollbars follow light/dark
 *
 * Pure DOM: used by the SpartanNativeTheme service, Storybook and tests.
 */
export declare function applySpartanNative(root: HTMLElement, a: ResolvedAppearance): void;
/** The OS family a skin belongs to: what window chrome and shortcuts follow. */
type PlatformFamily = 'windows' | 'macos' | 'linux' | 'chromeos' | 'web';
export declare function skinFamily(skin: Skin): PlatformFamily;
export declare const NATIVE_HOST: InjectionToken<NativeHost>;
export interface SpartanNativeOptions {
  /** The runtime adapter, e.g. `webHost()`, `wailsHost()`, or `staticHost()`. */
  host: NativeHost;
  /** Values that win over the host, e.g. a skin the user picked in settings. */
  overrides?: Partial<AppearanceState>;
  /**
   * Keep the user's overrides between launches. `true` stores them in `localStorage` under
   * `spartan-native:overrides`; pass `{ key, storage }` for another key or store (anything with
   * `getItem` / `setItem` / `removeItem`). Stored overrides win over `overrides`, and are read
   * before the first render, so the window opens in the user's look.
   */
  persist?: boolean | SpartanNativePersistence;
}
/** Where `persist` keeps the overrides. */
export interface SpartanNativePersistence {
  /** Default: `spartan-native:overrides`. */
  key?: string;
  /** Default: `localStorage`. */
  storage?: Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;
}
export declare const DEFAULT_PERSIST_KEY = "spartan-native:overrides";
/** Reads stored overrides, keeping only appearance fields of the right type. */
export declare function readStoredOverrides(storage: Pick<Storage, 'getItem'>, key?: string): Partial<AppearanceState>;
export declare const SPARTAN_NATIVE_OPTIONS: InjectionToken<SpartanNativeOptions>;
/**
 * The live appearance of the app, as signals.
 * It reads the host, applies the user's overrides, and keeps `<html>` in sync.
 */
export declare class SpartanNativeTheme {
  private readonly host;
  private readonly doc;
  private readonly options;
  private readonly fromHost;
  private readonly store;
  private readonly userOverrides;
  /** What the host reported about the platform (null until init). */
  readonly platform: import("@angular/core").WritableSignal<PlatformInfo | null>;
  readonly focused: import("@angular/core").WritableSignal<boolean>;
  /** What the user overrode (empty when following the system). */
  readonly overrides: import("@angular/core").Signal<Partial<AppearanceState>>;
  /** True when nothing is overridden: every value comes from the OS. */
  readonly followsSystem: import("@angular/core").Signal<boolean>;
  /** Host values with the user's overrides applied. */
  readonly appearance: import("@angular/core").Signal<AppearanceState>;
  readonly skin: import("@angular/core").Signal<Skin>;
  readonly scheme: import("@angular/core").Signal<import("@spartan-native/theme").ColorScheme>;
  readonly textScale: import("@angular/core").Signal<number>;
  /**
   * The skin the OS itself would have (the host's platform), whatever skin the user picked.
   * Before init, and on hosts that don't know the OS, it is the active skin.
   */
  readonly nativeSkin: import("@angular/core").Signal<Skin>;
  /**
   * The real OS family, for behavior that follows the keyboard and the window manager rather
   * than the look: shortcut notation (⌘ vs Ctrl), where the OS draws the window buttons,
   * the macOS menu bar. A Mac dressed as Windows is still `macos` here.
   */
  readonly platformFamily: import("@angular/core").Signal<PlatformFamily>;
  readonly runtime: "web" | "wails" | "tauri" | "electron" | "dotnet" | "static";
  /** The host's window services (focus, and minimize / maximize / close where the host owns a window). */
  readonly window: import("@spartan-native/theme").WindowHost;
  /** The host's native menus, when its runtime has them. */
  readonly menus: import("@spartan-native/theme").MenuHost | undefined;
  /** What the host's runtime can do natively. */
  readonly capabilities: import("@spartan-native/theme").HostCapabilities;
  constructor();
  /** Reads the initial values from the host. Called by provideSpartanNative() before first render. */
  init(): Promise<void>;
  /** Override part of the appearance (e.g. from an in-app settings screen). */
  override(patch: Partial<AppearanceState>): void;
  /** Drop the overrides and follow the OS again. */
  followSystem(): void;
  capability(name: Capability): CapabilityLevel;
  static ɵfac: i0.ɵɵFactoryDeclaration<SpartanNativeTheme, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Wires Spartan Native into an Angular app.
 *
 * ```ts
 * // app.config.ts: the only line that changes per runtime is the host
 * export const appConfig: ApplicationConfig = {
 *   providers: [provideSpartanNative({ host: wailsHost() })],
 * };
 * ```
 *
 * The initial appearance is read before the first render, so the app never flashes the wrong skin.
 */
export declare function provideSpartanNative(options: SpartanNativeOptions): EnvironmentProviders;
/**
 * The active skin as a signal, for components that render differently per OS.
 *
 * With provideSpartanNative() it is the theme service's signal. Without it
 * (Storybook, plain applySpartanNative(), a micro-frontend) it follows the
 * `data-sn-skin` attribute on <html>.
 */
export declare function injectSkin(): Signal<Skin>;
/**
 * The skin the real OS has (see `SpartanNativeTheme.nativeSkin`), whatever skin the user picked.
 * Use it where the OS itself draws something, e.g. the space its window buttons take.
 *
 * Without provideSpartanNative() it follows the `data-sn-platform` attribute on <html>, and
 * falls back to the active skin.
 */
export declare function injectNativeSkin(): Signal<Skin>;
/**
 * The real OS family as a signal (see `SpartanNativeTheme.platformFamily`): what the keyboard
 * and the window manager follow, whatever skin the user picked. Use it for behavior (shortcut
 * notation, the macOS menu bar); use `injectSkin()` for the look.
 */
export declare function injectPlatformFamily(): Signal<PlatformFamily>;
export type { PlatformFamily };