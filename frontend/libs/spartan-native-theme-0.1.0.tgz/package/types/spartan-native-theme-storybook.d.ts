import { Decorator, Preview } from "@storybook/angular";
import { Skin } from "@spartan-native/theme";
/** The OS family, which picks the icon in the toolbar. */
type OsFamily = 'windows' | 'apple' | 'linux' | 'chrome';
/** The skins offered in the OS toolbar. */
export declare const STORYBOOK_SKINS: {
  value: Skin;
  title: string;
  family: OsFamily;
}[];
/** Preset accent colors: the platforms' default accents plus a few common picks. */
export declare const ACCENT_PRESETS: {
  value: string;
  title: string;
}[];
export interface SpartanNativePreviewOptions {
  /** Add a text-size toolbar (100–200 %). Default: false. */
  textSize?: boolean;
  /** Add a window-focus toggle (focused / inactive). Default: false. */
  windowFocus?: boolean;
}
/**
 * Applies the toolbar globals and the light/dark switcher to <html>,
 * exactly like provideSpartanNative() does in an app.
 */
export declare const withSpartanNative: Decorator;
/**
 * A complete Storybook preview for Spartan Native.
 *
 * ```ts
 * // .storybook/preview.ts
 * import { spartanNativePreview } from '@spartan-native/theme/storybook';
 * export default spartanNativePreview();
 *
 * // .storybook/manager.tsx: the toolbar (OS with icons, switches, accent swatches)
 * import '@spartan-native/theme/storybook/manager';
 * ```
 *
 * The OS, transparency, contrast, window-focus and accent globals have no `toolbar`
 * entry here: the manager addon draws them as an OS select, toggle buttons and an
 * accent picker. Only the text size uses Storybook's own toolbar dropdown.
 */
export declare function spartanNativePreview(options?: SpartanNativePreviewOptions): Preview;
export type { OsFamily };